<?php
// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.


defined('MOODLE_INTERNAL') || die();

/**
 * Una classe di rendering personalizzata che estende plugin_renderer_base.
 *
 * @package mod_teacherassistant
 * @copyright 2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_teacherassistant_renderer extends plugin_renderer_base {



    /**
     * Restituisce l'intestazione per il modulo
     *
     * @param mod $instance
     * @param string $currenttab scheda corrente che viene visualizzata.
     * @param int    $item ID di tutto ciò che deve essere visualizzato.
     * @param string $extrapagetitle Stringa da aggiungere al titolo della pagina.
     * @return string
     */
    public function header($moduleinstance, $cm, $currenttab = '', $itemid = null, $extrapagetitle = null) {
        global $CFG;

        $activityname = format_string($moduleinstance->name, true, $moduleinstance->course);
        if (empty($extrapagetitle)) {
            $title = $this->page->course->shortname.": ".$activityname;
        } else {
            $title = $this->page->course->shortname.": ".$activityname.": ".$extrapagetitle;
        }

        // Costruisci i pulsanti
        $context = context_module::instance($cm->id);

    /// Configurazione dell'intestazione
        $this->page->set_title($title);
        $this->page->set_heading($this->page->course->fullname);
        $output = $this->output->header();

        if (has_capability('mod/teacherassistant:manage', $context)) {
         //   $output .= $this->output->heading_with_help($activityname, 'overview', MOD_TEACHERASSISTANT_LANG);

            if (!empty($currenttab)) {
                ob_start();
                include($CFG->dirroot.'/mod/teacherassistant/tabs.php');
                $output .= ob_get_contents();
                ob_end_clean();
            }
        } else {
            $output .= $this->output->heading($activityname);
        }
    

        return $output;
    }
    
    /**
     * Restituisce HTML per visualizzare un'intestazione limitata
     */
      public function notabsheader(){
        return $this->output->header();
      }


    /**
     *
     */
    public function show_something($showtext) {
        $ret = $this->output->box_start();
        $ret .= $this->output->heading($showtext, 4, 'main');
        $ret .= $this->output->box_end();
        return $ret;
    }

     /**
     *
     */
    public function show_intro($teacherassistant,$cm){
        $ret = "";
        if (trim(strip_tags($teacherassistant->intro))) {
            $ret .= $this->output->box_start('mod_introbox');
            $ret .= format_module_intro('teacherassistant', $teacherassistant, $cm->id);
            $ret .= $this->output->box_end();
        }
        return $ret;
    }
  
}

class mod_teacherassistant_report_renderer extends plugin_renderer_base {


    public function render_reportmenu($moduleinstance,$cm) {
        
        $basic = new single_button(
            new moodle_url(MOD_TEACHERASSISTANT_URL . '/reports.php',array('report'=>'basic','id'=>$cm->id,'n'=>$moduleinstance->id)), 
            get_string('basicreport',MOD_TEACHERASSISTANT_LANG), 'get');

        $ret = html_writer::div($this->render($basic) .'<br />'  ,MOD_TEACHERASSISTANT_CLASS  . '_listbuttons');

        return $ret;
    }

    public function render_delete_allattempts($cm){
        $deleteallbutton = new single_button(
                new moodle_url(MOD_TEACHERASSISTANT_URL . '/manageattempts.php',array('id'=>$cm->id,'action'=>'confirmdeleteall')), 
                get_string('deleteallattempts',MOD_TEACHERASSISTANT_LANG), 'get');
        $ret =  html_writer::div( $this->render($deleteallbutton) ,MOD_TEACHERASSISTANT_CLASS  . '_actionbuttons');
        return $ret;
    }

    public function render_reporttitle_html($course,$username) {
        $ret = $this->output->heading(format_string($course->fullname),2);
        $ret .= $this->output->heading(get_string('reporttitle',MOD_TEACHERASSISTANT_LANG,$username),3);
        return $ret;
    }

    public function render_empty_section_html($sectiontitle) {
        global $CFG;
        return $this->output->heading(get_string('nodataavailable',MOD_TEACHERASSISTANT_LANG),3);
    }
    
    public function render_exportbuttons_html($cm,$formdata,$showreport){
        //converti formdata in array
        $formdata = (array) $formdata;
        $formdata['id']=$cm->id;
        $formdata['report']=$showreport;
        /*
        $formdata['format']='pdf';
        $pdf = new single_button(
            new moodle_url(MOD_TEACHERASSISTANT_URL . '/reports.php',$formdata),
            get_string('exportpdf',MOD_TEACHERASSISTANT_LANG), 'get');
        */
        $formdata['format']='csv';
        $excel = new single_button(
            new moodle_url(MOD_TEACHERASSISTANT_URL . '/reports.php',$formdata), 
            get_string('exportexcel',MOD_TEACHERASSISTANT_LANG), 'get');

        return html_writer::div( $this->render($excel),MOD_TEACHERASSISTANT_CLASS  . '_actionbuttons');
    }
    

    
    public function render_section_csv($sectiontitle, $report, $head, $rows, $fields) {

        // Use the sectiontitle as the file name. Clean it and change any non-filename characters to '_'.
        $name = clean_param($sectiontitle, PARAM_FILE);
        $name = preg_replace("/[^A-Z0-9]+/i", "_", trim($name));
        $quote = '"';
        $delim= ",";//"\t";
        $newline = "\r\n";

        header("Content-Disposition: attachment; filename=$name.csv");
        header("Content-Type: text/comma-separated-values");

        //echo header
        $heading="";    
        foreach($head as $headfield){
            $heading .= $quote . $headfield . $quote . $delim ;
        }
        echo $heading. $newline;
        
        //echo data rows
        foreach ($rows as $row) {
            $datarow = "";
            foreach($fields as $field){
                $datarow .= $quote . $row->{$field} . $quote . $delim ;
            }
             echo $datarow . $newline;
        }
        exit();
    }

    public function render_section_html($sectiontitle, $report, $head, $rows, $fields) {
        global $CFG;
        if(empty($rows)){
            return $this->render_empty_section_html($sectiontitle);
        }
        
        //imposta i nostri attributi table e head
        $tableattributes = array('class'=>'generaltable '. MOD_TEACHERASSISTANT_CLASS .'_table');
        $headrow_attributes = array('class'=>MOD_TEACHERASSISTANT_CLASS . '_headrow');
        
        $htmltable = new html_table();
        $htmltable->attributes = $tableattributes;
        
        
        $htr = new html_table_row();
        $htr->attributes = $headrow_attributes;
        foreach($head as $headcell){
            $htr->cells[]=new html_table_cell($headcell);
        }
        $htmltable->data[]=$htr;
        
        foreach($rows as $row){
            $htr = new html_table_row();
            //set up descrption cell
            $cells = array();
            foreach($fields as $field){
                $cell = new html_table_cell($row->{$field});
                $cell->attributes= array('class'=>MOD_TEACHERASSISTANT_CLASS . '_cell_' . $report . '_' . $field);
                $htr->cells[] = $cell;
            }

            $htmltable->data[]=$htr;
        }
        $html = $this->output->heading($sectiontitle, 4);
        $html .= html_writer::table($htmltable);
        return $html;
        
    }
    
      /**
       * Restituisce HTML per visualizzare una singola barra di paging per fornire accesso ad altre pagine (di solito in una ricerca)
       * @param int $totalcount Il numero totale di voci disponibili da sfogliare
       * @param stdclass $paging un oggetto contenente i campi sort / per page / page no. Creato in reports.php e grading.php
       * @param string|moodle_url $baseurl url della pagina corrente, viene aggiunto il parametro $ pagevar
       * @return string l'HTML per l'output.
       */
    function show_paging_bar($totalcount,$paging,$baseurl){
        $pagevar="pageno";
        //aggiungi parametri di paging all'URL (NON pageno)
        $baseurl->params(array('perpage'=>$paging->perpage,'sort'=>$paging->sort));
        return $this->output->paging_bar($totalcount,$paging->pageno,$paging->perpage,$baseurl,$pagevar);
    }
    
    function show_reports_footer($moduleinstance,$cm,$formdata,$showreport){
        // stampa è un collegamento popup alla tua pagina personalizzata
        $link = new moodle_url(MOD_TEACHERASSISTANT_URL . '/reports.php',array('report'=>'menu','id'=>$cm->id,'n'=>$moduleinstance->id));
        $ret =  html_writer::link($link, get_string('returntoreports',MOD_TEACHERASSISTANT_LANG));
        $ret .= $this->render_exportbuttons_html($cm,$formdata,$showreport);
        return $ret;
    }

}
// Non ci sono tag di chiusura php in questo file,
// è intenzionale perché previene problemi di spazi vuoti finali!