<?php
// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Stampa un'istanza particolare di insegnante
 *
 * Puoi anche avere una descrizione più lunga del file,
 * se vuoi, e può estendersi su più righe.
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require('../../config.php');

global $DB, $CFG, $GLOBALS, $PAGE, $USER;

//moodleform è definito in formslib.php
require_once("$CFG->libdir/formslib.php");

require_once("$CFG->dirroot/mod/teacherassistant/lib.php");

require_once($CFG->dirroot.'/course/moodleform_mod.php');
//È necessario aggiungere quanto segue a tutti i file che accedono alle funzioni profilo_:
require_once("$CFG->dirroot/user/profile/lib.php");
require_once 'e65metadato.php';
   
$mysqli = mysqli_connect($CFG->dbhost,$CFG->dbuser,$CFG->dbpass,$CFG->dbname);
if($mysqli->connect_error){
    die($mysqli->connect_error);
}else{
    echo '';
}
/* require('cmd_sql.php'); */
$sql4 = 'CREATE TABLE if not exists mdl_teacherassistant_tempo (';
$sql4 .= 'id BIGINT(4) NOT NULL auto_increment,';
$sql4 .= 'metadato_cors_identif BIGINT(3) NOT NULL,';
$sql4 .= 'metadato_cors_nom VARCHAR(128) COLLATE utf8_general_ci,';
$sql4 .= 'metadato_cors_sect_identif BIGINT(3) NOT NULL,';
$sql4 .= 'metadato_prerequisiti VARCHAR(2048) NOT NULL COLLATE utf8_general_ci,';
$sql4 .= 'metadato_conosc_acquisite VARCHAR(516) NOT NULL COLLATE utf8_general_ci,';
$sql4 .= 'metadato_name VARCHAR(1024) NOT NULL COLLATE utf8_general_ci,';
$sql4 .= 'metadato_learning_style_1 NUMERIC(2) NOT NULL,';
$sql4 .= 'metadato_learning_style_2 NUMERIC(2) NOT NULL,';
$sql4 .= 'metadato_learning_style_3 NUMERIC(2) NOT NULL,';
$sql4 .= 'metadato_learning_style_4 NUMERIC(2) NOT NULL,';
$sql4 .= 'metadato_tem_conc NUMERIC(2) NOT NULL,';
$sql4 .= 'metadato_tempo VARCHAR(255) NOT NULL COLLATE utf8_general_ci,';
$sql4 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql4 .= ')';
$sql4 .= 'ENGINE = InnoDB ';
$sql4 .= 'DEFAULT COLLATE = utf8_general_ci ROW_FORMAT=Compressed;';

$res=$mysqli->query($sql4);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '';
}

$sql2 = 'CREATE TABLE if not exists mdl_teacherassistant_metadato (';
$sql2 .= 'id BIGINT(4) NOT NULL auto_increment,';
$sql2 .= 'metadato_cors_sect_identif BIGINT(3) NOT NULL,';
$sql2 .= 'metadato_conosc_acquisite VARCHAR(256) UNIQUE NOT NULL COLLATE utf8_general_ci,';
$sql2 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql2 .= ')';
$sql2 .= 'ENGINE = InnoDB ';
$sql2 .= 'DEFAULT COLLATE = utf8_general_ci ROW_FORMAT=Compressed;';

$res=$mysqli->query($sql2);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '';
}

$sql3 = 'CREATE TABLE if not exists mdl_teacherassistant_concatena (';
$sql3 .= 'id BIGINT(4) NOT NULL auto_increment,';
$sql3 .= 'meta_concat VARCHAR(1020) UNIQUE NOT NULL COLLATE utf8_general_ci,';
$sql3 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql3 .= ')';
$sql3 .= 'ENGINE = InnoDB ';
$sql3 .= 'DEFAULT COLLATE = utf8_general_ci ROW_FORMAT=Compressed;';

$res=$mysqli->query($sql3);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '';
}



/*  end cmd_sql */


$id = optional_param('id', 0, PARAM_INT); // course_module ID, or

$n  = optional_param('n', 0, PARAM_INT);  // teacherassistant ID istanza: dovrebbe essere nominato come primo carattere del modulo

if ($id) {
    $cm         = get_coursemodule_from_id('teacherassistant', $id, 0, false, MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $moduleinstance  = $DB->get_record('teacherassistant', array('id' => $cm->instance), '*', MUST_EXIST);
} elseif ($n) {
    $moduleinstance  = $DB->get_record('teacherassistant', array('id' => $n), '*', MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $moduleinstance->course), '*', MUST_EXIST);
    $cm         = get_coursemodule_from_instance('teacherassistant', $moduleinstance->id, $course->id, false, MUST_EXIST);
} else {
    print_error(get_string('missingidandcmid',MOD_TEACHERASSISTANT_LANG));
}

$metadato_cors_nom=$GLOBALS['course']->fullname;

$metadato_cors_identif=$GLOBALS['course']->id;

if ($id) {
//invia la richiesta alla funzione get_field_sql()
$metadato_cors_sect_identif = $id;
} elseif ($n) {
    $metadato_cors_sect_identif = $n;
}else {
    print_error(get_string('missingidandcmid',MOD_TEACHERASSISTANT_LANG));
}

$PAGE->set_url('/mod/teacherassistant/view.php', array('id' => $cm->id));
require_login($course, true, $cm);
$modulecontext = context_module::instance($cm->id);

//Deviare la logica di registrazione a Moodle 2.7
if($CFG->version<2014051200){
    add_to_log($course->id, 'teacherassistant', 'view', "view.php?id={$cm->id}", $moduleinstance->name, $cm->id);
}else{
    // Evento visualizzato modulo trigger..
    $event = \mod_teacherassistant\event\course_module_viewed::create(array(
        'objectid' => $moduleinstance->id,
        'context' => $modulecontext
    ));
    $event->add_record_snapshot('course_modules', $cm);
    $event->add_record_snapshot('course', $course);
    $event->add_record_snapshot('teacherassistant', $moduleinstance);
    $event->trigger();
}

// se siamo arrivati così lontano, possiamo considerare l'attività "vista"
$completion = new completion_info($course);
$completion->set_module_viewed($cm);

//siamo un insegnante o uno studente?
$mode= "view";

// Imposta l'intestazione della pagina
$PAGE->set_title(format_string($moduleinstance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($modulecontext);
$PAGE->set_pagelayout('course');

//Ottieni le impostazioni di amministrazione
$config = get_config(MOD_TEACHERASSISTANT_FRANKY);
$someadminsetting = $config->someadminsetting;

//Ottieni un'impostazione dell'istanza
$someinstancesetting = $moduleinstance->someinstancesetting;


// Prepara il nostro JavaScript pronto per partire
// Possiamo omettere il modulo $ js, ma è bello averlo qui,
// se per esempio dobbiamo includere alcune cose YUI funky
$jsmodule = array(
    'name'     => 'mod_teacherassistant',
    'fullpath' => '/mod/teacherassistant/module.js',
    'requires' => array()
);
//qui impostiamo tutte le informazioni necessarie per passare a JavaScript
$opts =Array();
$opts['someinstancesetting'] = $someinstancesetting;


//questo entra nel M.mod_teacherassistant cosa, dopo che la pagina è stata caricata.
$PAGE->requires->js_init_call('M.mod_teacherassistant.helper.init', array($opts),false,$jsmodule);

//questo carica tutte le librerie JS esterne che dobbiamo chiamare
//$PAGE->requires->js("/mod/teacherassistant/js/somejs.js");
//$PAGE->requires->js(new moodle_url('http://www.somewhere.com/some.js'),true);

//Questo mette tutta la nostra logica di visualizzazione nel file renderer.php in questo plugin
//gli sviluppatori di temi possono sovrascrivere le classi lì, quindi lo rendono personalizzabile per gli altri
//per farlo in questo modo.
$renderer = $PAGE->get_renderer('mod_teacherassistant');

//Da qui visualizziamo effettivamente la pagina.
// questa è roba di rendering di base

//se siamo insegnanti vediamo le schede. Se studente vediamo solo il quiz
if(has_capability('mod/teacherassistant:preview',$modulecontext)){
    echo $renderer->header($moduleinstance, $cm, $mode, null, get_string('view', MOD_TEACHERASSISTANT_LANG));
}else{
    echo $renderer->notabsheader();
}

echo $renderer->show_intro($moduleinstance,$cm);

/* require('mod_dati.php'); */

?>
    <html lan="it">
    <head>
        <title>Teacherassistant</title>
        <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <style type="text/css">

            #JS { display:none; }

        </style>

        <script>
            function checkJS() {

                document.getElementById('JS').style.display = "inline";

            }
        </script>

    </head>

<body onload="checkJS();">

<h1>Teacherassistant</h1>

<div id="JS">
    <form method="post" name="invio" action="e65metadato_interface.php">
        <br /><h5><b>Mappa didattica</b></h5><br />
        <p>mostra la mappa didattica del corso</p>
        <?php
        /*
        echo '<br> identificativo del corso = ';
        $metadato_cors_identif2=$GLOBALS['course']->id;
        echo "$metadato_cors_identif2";
        echo '<br> nome del corso = ';
        $metadato_cors_nom2=$GLOBALS['course']->fullname;
        echo "$metadato_cors_nom2";
        echo '<br> identificativo della sezione= ';
        echo "$id";
       
        echo '<br> Prerequisiti : <br>';
        $conoscen_acquisit_1= $DB->get_records_select('teacherassistant_tempo','metadato_conosc_acquisite!=?',array(0));
        foreach($conoscen_acquisit_1 as $show_prerequisiti_1) {
            $a = $show_prerequisiti_1->metadato_conosc_acquisite;
        echo "$a <br>";
        }
        echo '<br> Conoscenze acquisite : <br>';
        $conoscen_acquisit2 = $DB->get_records_select('teacherassistant_tempo','metadato_conosc_acquisite!=?',array(0));

        foreach($conoscen_acquisit2 as $show_conoscen_acquisit2) {
            $b = $show_conoscen_acquisit2->metadato_conosc_acquisite;
            echo "$b <br>";
        }
         */
        ?>
        <br /><br /><h5><b>Prerequisiti</b></h5><br />

        <div>
            <p>Seleziona uno o piu' prerequisiti :</p>
        <?php
        $conoscen_acquisit_3= $DB->get_records_select('teacherassistant_metadato','metadato_cors_sect_identif=?',array($id));
        if(empty($conoscen_acquisit_3)){
         echo 'nessun metadato presente'.'<br>';  
               $a = "nessun metadato presente";
         ?>
        <input type="hidden" id="metadato_prerequisiti" name="metadato_prerequisiti" value="<?=$a?>" />
        <?php
        }
        else {
            
        foreach($conoscen_acquisit_3 as $show_prerequisiti_3) {
            $b = $show_prerequisiti_3->metadato_conosc_acquisite;
        ?>
            <div>

                             <input type="checkbox" id="metadato_prerequisiti" name="metadato_prerequisiti[]" value="<?=$b?>" />
                            <label class="form-check-label" for="metadato_prerequisiti">&emsp;<?=$b?></label><br>
            </div>
            
        <?php
        }
    }
        //$metadato_tempo = date("M,d,Y h:i:s A");

        ?>
        </div>
        <br /><br />
<SCRIPT LANGUAGE="JavaScript">
function showData1() {
	var tableData = ""
		tableData += "<br /><p>Scegli una conoscenza acquisita presente:</p>"
        tableData += "<input type='radio' id='metadato_conosc_acquisite' name='metadato_conosc_acquisite[]' value='nessuna scelta' checked>"
        tableData += "<label for='metadato_conosc_acquisite[]'>&emsp;nessuna scelta</label><br>"
        <?php
        $conoscen_acquisit3 = $DB->get_records_select('teacherassistant_metadato','metadato_cors_sect_identif=?',array($id));

        foreach($conoscen_acquisit3 as $show_conoscen_acquisit3) :
            $b = $show_conoscen_acquisit3->metadato_conosc_acquisite;
            ?>
        tableData += "<input type='radio' id='metadato_conosc_acquisite' name='metadato_conosc_acquisite[]' value='<?=$b?>'>"
        tableData += "<label for='metadato_conosc_acquisite[]'>&emsp;<?=$b?></label><br>"
        tableData += "<input type='hidden' name='metadato_name' id='metadato_name' />"
        <?php endforeach ?>
    document.getElementById("display").innerHTML = tableData
}
function showData2() {
	var tableData = ""
        tableData += "<input type='hidden' id='metadato_conosc_acquisite' name='metadato_conosc_acquisite[]' value='nessuna scelta'>"
		tableData += "<br /><p>Aggiungi una nuova conoscenza acquisita:</p>"
        tableData += "<input type='text' name='metadato_name' id='metadato_name' />"
	document.getElementById("display").innerHTML = tableData
}
</SCRIPT>

<P><INPUT TYPE="button" VALUE="Scegli una conoscenza acquisita presente" onClick="showData1()">
<INPUT TYPE="button" VALUE="Aggiungi una nuova conoscenza acquisita" onClick="showData2()"></P>
<DIV ID="display"></DIV>

        <br />
        <br />
<style>
    .noborder {
        border: none;
    }
</style>
<table class="noborder">

<thead class="noborder">
  <tr class="noborder">
    <th class="noborder"></th>
    <th class="noborder"></th>
  </tr>
</thead>

  
<tbody class="noborder">
    <tr class="noborder">
        <td class="noborder" colspan="2"><h5><b>Learning styles </b></h5></td>
    </tr>
  <tr class="noborder">
    <td class="noborder"><label for="metadato_learning_style_1">attivo-riflessivo </label></td>
    <td class="noborder"><input type="number" value="0" min="-11" max="11" name="metadato_learning_style_1" id="metadato_learning_style_1" required /></td>
  </tr>
  <tr class="noborder">
    <td class="noborder"><label for="metadato_learning_style_2">rilevamento-intuitivo</label></td>
    <td class="noborder"><input type="number" value="0" min="-11" max="11" name="metadato_learning_style_2" id="metadato_learning_style_2" required /></td>
  </tr>
  <tr class="noborder">
    <td class="noborder"><label for="metadato_learning_style_3">visivo-verbale</label></td>
    <td class="noborder"><input type="number" value="0" min="-11" max="11" name="metadato_learning_style_3" id="metadato_learning_style_3" required /></td>
  </tr>
<tr class="noborder">
    <td class="noborder"><label for="metadato_learning_style_4">sequenziale-globale</td>
    <td class="noborder"><input type="number" value="0" min="-11" max="11" name="metadato_learning_style_4" id="metadato_learning_style_4" required /></td>
  </tr>
</tbody>
  
</table>
<br />
        <br />
        <label for="metadato_tem_conc"><h5>tempo a disposizione (minuti)&ensp; </h5></label><input type="number" value="0" min="1" max="60" name="metadato_tem_conc" id="metadato_tem_conc" required />
        <br />
        <input type="hidden" name="metadato_app" id="metadato_app" value="metadato" />
        <input type="hidden" name="metadato_cors_identif" id="metadato_cors_identif" value="<?=$metadato_cors_identif?>" />
        <input type="hidden" name="metadato_cors_nom" id="metadato_cors_nom" value="<?=$metadato_cors_nom?>" />
        <input type="hidden" name="metadato_cors_sect_identif" id="metadato_cors_sect_identif" value="<?=$id?>" />
        <input type="hidden" name="metadato_tempo" id="metadato_tempo" value="<?=date("M,d,Y h:i:s A")?>" /><br />
        <script>
            AjaxRequest('e65metadato_interface.php');
        </script>
         <br />
        <br />
        <input type="submit" id="submit" name="submit" value="Salva il metadato" />
        <input type="reset" id="reset" name="reset" value="Resetta il modulo" /><br />
        <br />
    </form>
    
</div>

<noscript>
    <div id="noJS">
    <form method="post" action="e65metadato_interface.php">
            <h2>Per favore completa tutti i campi. Si prega di notare il formato delle informazioni richiesto.</h2>
            <br /><br /><h5><b>Prerequisiti</b></h5><br />
        <p>Seleziona uno o piu' prerequisiti :</p>
        <?php
        $conoscen_acquisit_5= $DB->get_records_select('teacherassistant_metadato','metadato_cors_sect_identif=?',array($id));
        if(empty($conoscen_acquisit_5)){
         echo 'nessun metadato presente'.'<br>';    
               $d = "nessun metadato presente";
         ?>
        <input type="hidden" id="metadato_prerequisiti" name="metadato_prerequisiti" value="<?=$d?>" />
        <?php
        }
        else {
            ?>
             <input type="checkbox" id="metadato_prerequisiti" name="metadato_prerequisiti[]" value="nessuna scelta" checked/>
                            <label class="form-check-label" for="metadato_prerequisiti[]">nessuna scelta</label><br>
            <?php
        foreach($conoscen_acquisit_5 as $show_prerequisiti_5) {
            $e = $show_prerequisiti_5->metadato_conosc_acquisite;
        ?>
            <div>

                             <input type="checkbox" id="metadato_prerequisiti" name="metadato_prerequisiti[]" value="<?=$e?>" />
                            <label class="form-check-label" for="metadato_prerequisiti"><?=$e?></label><br>
            </div>
        <?php
        }
        }
        ?>
        <br /><h5><b>Conoscenze acquisite </b></h5>
        <br /><p>Scegli una conoscenza acquisita presente:</p>
        <input type="radio" id="metadato_conosc_acquisite" name="metadato_conosc_acquisite[]" value="nessuna scelta" checked>
        <label for="metadato_conosc_acquisite[]">nessuna scelta</label><br>

        <?php
        $conoscen_acquisit6 = $DB->get_records_select('teacherassistant_metadato','metadato_cors_sect_identif=?',array($id));

        foreach($conoscen_acquisit6 as $show_conoscen_acquisit6) {
            $f = $show_conoscen_acquisit6->metadato_conosc_acquisite;
            ?>
            <input type="radio" id="metadato_conosc_acquisite" name="metadato_conosc_acquisite[]" value="<?=$f?>">
             <label for="metadato_conosc_acquisite[]"><?=$f?></label><br>
        <?php
        }
        ?>

        <br /><p>Aggiungi una nuova conoscenza acquisita :</p>
        <input type="text" name="metadato_name" id="metadato_name" />

            <b>Learning styles</b><br /><br />
            attivo-riflessivo  <input type="number" min="-11" max="11" name="metadato_learning_style_1" id="metadato_learning_style_1" required /><br />
            rilevamento-intuitivo  <input type="number" min="-11" max="11" name="metadato_learning_style_2" id="metadato_learning_style_2" required /><br />
            visivo-verbale  <input type="number" min="-11" max="11" name="metadato_learning_style_3" id="metadato_learning_style_3" required /><br />
            sequenziale-globale  <input type="number" min="-11" max="11" name="metadato_learning_style_4" id="metadato_learning_style_4" required /><br /><br />
            <br />
            tempo  a disposizione  <input type="number" value="0" min="1" max="60" name="metadato_tem_conc" id="metadato_tem_conc" required /><br /><br />
            <br />
            <input type="hidden" name="metadato_app" id="metadato_app" value="metadato" />
            <input type="hidden" name="metadato_cors_identif" id="metadato_cors_identif" value="<?=$metadato_cors_identif?>" /><br />
            <input type="hidden" name="metadato_cors_nom" id="metadato_cors_nom" value="<?=$metadato_cors_nom?>" /><br />
            <input type="hidden" name="metadato_cors_sect_identif" id="metadato_cors_sect_identif" value="<?=$id?>" /><br />
            <input type="hidden" name="metadato_tempo" id="metadato_tempo" value="<?=date("M,d,Y h:i:s A")?>" /><br />
             <input type="submit" id="submit" name="submit" value="Salva il metadato" /><br />
        </form>
    </div>
</noscript>    

<!--/* require('tabella_aggiorna.php'); */ -->
<?php

//invia la richiesta alla funzione get_field_sql()
//$metadato_cors_sect_identif = $id;

// mysqli_field_name restituisce il nome del campo di una tabella,ma e' una funzione che ho introdotto
// in quanto devo passare per una altra funzione che e' mysqli_fetch_field_direct;
// mysqli_fetch_field_direct restituisce un oggetto che contiene le informazioni sulla definizione del campo
// dal set di risultati specificato. Se restituisce un oggetto allora posso risalire al nome del campo della tabella.
function mysqli_field_name($result, $field_offset)
{
       $properties = mysqli_fetch_field_direct($result, $field_offset);
       return is_object($properties) ? $properties->name : null;
}
// con il comando sql AS rinomino tutti i nomi delle colonne
$sql="SELECT m.metadato_cors_identif AS 'id corso',m.metadato_cors_nom AS 'nome del corso',m.metadato_cors_sect_identif AS 'id sez',m.metadato_prerequisiti AS prerequisiti,m.metadato_conosc_acquisite AS 'conoscenze acquisite',m.metadato_name AS 'nuova conoscenza acquisita',m.metadato_learning_style_1 AS 'learning style 1',m.metadato_learning_style_2 AS 'learning style 2',m.metadato_learning_style_3 AS 'learning style 3',m.metadato_learning_style_4 AS 'learning style 4',m.metadato_tem_conc AS 'tempo a disposizione',m.metadato_tempo as 'orario dell\' aggiornamento' from mdl_teacherassistant_tempo as m WHERE m.metadato_cors_sect_identif=$id";
	$res=$mysqli->query($sql);
	if(!$res){
		echo $mysqli->error.'<br>';
	}else{
	// se siamo in questo punto allora la connessione al db e' avvenuta
//questa funzione mi da' il numero di campi della tabella
	$numcampi = mysqli_num_fields ($res);

// questo campo style di html attribuisce uno stile alla riga a seconda che sia una riga pari(even) o dispari(odd) della tabella.
    echo "<style>.sorgente tr:nth-child(even) { background-color: #FFFFFF;border:1px solid;padding:5px; } .sorgente tr:nth-child(odd) { background-color: #F0F0F0;border:1px solid;padding:5px; } td{border:1px solid;padding:5px;}</style>";
	echo "<br><table class='sorgente' style='border:1px solid;text-align:center;'><tr style='padding:5px'>";

	for ($i=0; $i < $numcampi; $i++)

  	{
/*
C'e' un modo per avere il nome di un campo della tabella:
non posso usare mysql_field_name perche' e' stato deprecato, e quindi devo usare una funzione mysqli:
*/
  	 echo "<th style='border:1px solid;padding:5px'>".mysqli_field_name($res, $i).'</th>';

  	 }

  	 echo "</tr>";

   
// mysqli_fetch_row ottiene una riga dei risultati come matrice enumerata
   	while ($row = mysqli_fetch_row($res))

  	{

  	 echo "<tr style='border:1px solid;padding:5px'><td style='border:1px solid;padding:5px'>".implode($row,'</td><td>')."</td></tr>";

  }

echo "</table>";
echo "<br>";
}



/* end  tabella_aggiorna.php */
echo '<br>Pulsante per aggiornare la tabella &emsp;';
?>
<input type="button" value="Ricarica la pagina" onclick="window.location.reload()">
<?php
//se abbiamo troppi tentativi, segnaliamolo.
if($moduleinstance->maxattempts > 0){
    $attempts =  $DB->get_records(MOD_TEACHERASSISTANT_USERTABLE,array('userid'=>$USER->id, MOD_TEACHERASSISTANT_MODNAME.'id'=>$moduleinstance->id));
    if($attempts && count($attempts)<$moduleinstance->maxattempts){
        echo get_string("exceededattempts",MOD_TEACHERASSISTANT_LANG,$moduleinstance->maxattempts);
    }
}

//Questo è specifico per il nostro renderer
//echo $renderer->show_something($someadminsetting);
//echo $renderer->show_something($someinstancesetting);

// Termina la pagina
echo $renderer->footer();
// Non ci sono tag di chiusura php in questo file,
// è intenzionale perché previene problemi di spazi vuoti finali!