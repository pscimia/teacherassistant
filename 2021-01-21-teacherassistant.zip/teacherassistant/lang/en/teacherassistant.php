<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.


/**
 * Stringhe inglesi per teacherassistant
 *
 * Puoi anche avere una descrizione più lunga del file,
 * se vuoi, e può estendersi su più righe.
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'teacherassistant';
$string['modulenameplural'] = 'teacherassistants';
$string['modulename_help'] = 'teacherassistant help';
$string['teacherassistantfieldset'] = 'Custom example fieldset';
$string['teacherassistantname'] = 'teacherassistant name';
$string['teacherassistantname_help'] = 'This is the content of the help tooltip associated with the teacherassistantname field. Markdown syntax is supported.';
$string['teacherassistant'] = 'teacherassistant';
$string['pluginadministration'] = 'teacherassistant Administration';
$string['pluginname'] = 'teacherassistant Activity';
$string['someadminsetting'] = 'Some Admin Setting';
$string['someadminsetting_details'] = 'More info about Some Admin Setting';
$string['someinstancesetting'] = 'Some Instance Setting';
$string['someinstancesetting_details'] = 'More infor about Some Instance Setting';
$string['teacherassistantsettings'] = 'teacherassistant settings';
$string['teacherassistant:addinstance'] = 'Add a new teacherassistant';
$string['teacherassistant:view'] = 'View teacherassistant';
$string['teacherassistant:preview'] = 'Preview teacherassistant';
$string['teacherassistant:itemview'] = 'View items';
$string['teacherassistant:itemedit'] = 'Edit items';
$string['id']='ID';
$string['name']='Name';
$string['timecreated']='Time Created';
$string['basicheading']='Basic Report';
$string['overview']='Overview';
$string['overview_help']='Overview Help';
$string['view']='View';
$string['preview']='Preview';
$string['viewreports']='View Reports';
$string['reports']='Reports';
$string['basicreport']='Basic Report';
$string['returntoreports']='Return to Reports';
$string['exportexcel']='Export to CSV';
$string['mingradedetails'] = 'The minimum grade required to "complete" this activity.';
$string['mingrade'] = 'Minimum Grade';
$string['deletealluserdata'] = 'Delete all user data';
$string['maxattempts'] ='Max. Attempts';
$string['unlimited'] ='unlimited';
$string['gradeoptions'] ='Grade Options';
$string['gradenone'] ='No grade';
$string['gradelowest'] ='lowest scoring attempt';
$string['gradehighest'] ='highest scoring attempt';
$string['gradelatest'] ='score of latest attempt';
$string['gradeaverage'] ='average score of all attempts';
$string['defaultsettings'] ='Default Settings';
$string['exceededattempts'] ='You have completed the maximum {$a} attempts.';
$string['teacherassistanttask'] ='teacherassistant Task';
$string['missingidandcmid']='You must specify a course_module ID or an instance ID';
