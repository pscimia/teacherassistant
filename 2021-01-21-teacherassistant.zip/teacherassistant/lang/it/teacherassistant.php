<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.


/**
 * Stringhe italiane per teacherassistant
 *
 * Puoi anche avere una descrizione più lunga del file,
 * se vuoi, e può estendersi su più righe.
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'teacherassistant';
$string['modulenameplural'] = 'teacherassistants';
$string['modulename_help'] = 'teacherassistant aiuto';
$string['teacherassistantfieldset'] = 'Campi di esempio personalizzato';
$string['teacherassistantname'] = 'teacherassistant nome';
$string['teacherassistantname_help'] = 'Questo è il contenuto della descrizione comandi della guida associata al campo nome teacherassistant. La sintassi Markdown è supportata.';
$string['teacherassistant'] = 'teacherassistant';
$string['pluginadministration'] = 'Amministrazione teacherassistant';
$string['pluginname'] = 'Attività teacherassistant';
$string['someadminsetting'] = 'Alcune impostazioni amministratore ';
$string['someadminsetting_details'] = 'Ulteriori informazioni su alcune impostazioni amministratore';
$string['someinstancesetting'] = 'Alcune impostazioni dell\'istanza';
$string['someinstancesetting_details'] = 'Maggiori informazioni su alcune impostazioni dell\'istanza';
$string['teacherassistantsettings'] = 'impostazioni teacherassistant';
$string['teacherassistant:addinstance'] = 'Aggiungi un nuovo teacherassistant';
$string['teacherassistant:view'] = 'Visualizza teacherassistant';
$string['teacherassistant:preview'] = 'Anteprima teacherassistant';
$string['teacherassistant:itemview'] = 'Visualizza articoli';
$string['teacherassistant:itemedit'] = 'Modifica articoli';
$string['id']='ID';
$string['name']='Nome';
$string['timecreated']='Tempo creato';
$string['basicheading']='Rapporto di base';
$string['overview']='Panoramica';
$string['overview_help']='Panoramica Guida';
$string['view']='Visualizza';
$string['preview']='Anteprima';
$string['viewreports']='Visualizza rapporti';
$string['reports']='Rapporti';
$string['basicreport']='Rapporto di base';
$string['returntoreports']='Torna ai rapporti';
$string['exportexcel']='Esporta in CSV';
$string['mingradedetails'] = 'Il voto minimo richiesto per "completare" questa attività.';
$string['mingrade'] = 'Grado minimo';
$string['deletealluserdata'] = 'Eliminare tutti i dati utente';
$string['maxattempts'] ='Max. tentativi';
$string['unlimited'] ='illimitato';
$string['gradeoptions'] ='Opzioni di voto';
$string['gradenone'] ='Nessun voto';
$string['gradelowest'] ='tentativo di punteggio più basso';
$string['gradehighest'] ='punteggio più alto';
$string['gradelatest'] ='punteggio dell\'ultimo tentativo';
$string['gradeaverage'] ='punteggio medio di tutti i tentativi';
$string['defaultsettings'] ='Impostazioni predefinite';
$string['exceededattempts'] ='Hai completato il massimo {$ a} tentativi.';
$string['teacherassistanttask'] ='Compito teacherassistant';
$string['missingidandcmid']='È necessario specificare un ID course_module o un ID istanza';
