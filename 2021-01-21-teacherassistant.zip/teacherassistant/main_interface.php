<?php
//----------------Main Section-------------------------------------
try {
	if ( file_exists("e65metadato_container.php"))
	{
		Require_once("e65metadato_container.php");
	}
	else
	{
		throw new Exception("File contenitore metadato mancante o danneggiato");
	}

	if (isset($_POST['metadato_app']))
	{
	// isset($_POST['metadato_prerequisiti'] e' un array che precedentemente trasformo in una stringa con il metodo implode
	// pero' se non e' settato, cioe' non viene scelto alcun prerequisito, allora lo devo settare ad uns stringa o mi restituirebbe un errore
		if ((isset($_POST['metadato_cors_identif'])) && (isset($_POST['metadato_cors_nom'])) && (isset($_POST['metadato_cors_sect_identif'])) && (isset($_POST['metadato_prerequisiti']) ? isset($_POST['metadato_prerequisiti']) : $_POST['metadato_prerequisiti'] = "nessuna scelta") && (isset($_POST['metadato_conosc_acquisite'])) && (isset($_POST['metadato_name'])) && (isset($_POST['metadato_learning_style_1'])) && (isset($_POST['metadato_learning_style_2'])) && (isset($_POST['metadato_learning_style_3'])) && (isset($_POST['metadato_learning_style_4'])) && (isset($_POST['metadato_tem_conc'])) && (isset($_POST['metadato_tempo'])))
		{

			$container = new metadato_container(clean_input($_POST['metadato_app']));

			$metadato_cors_identif = clean_input($_POST['metadato_cors_identif']);
			$metadato_cors_nom = clean_input($_POST['metadato_cors_nom']);
			$metadato_cors_sect_identif = clean_input($_POST['metadato_cors_sect_identif']);
			$metadato_prerequisiti = clean_input($_POST['metadato_prerequisiti']);
			$metadato_conosc_acquisite = clean_input($_POST['metadato_conosc_acquisite']);
			$metadato_name = clean_input(filter_input(INPUT_POST, "metadato_name"));
			$metadato_learning_style_1 = clean_input($_POST['metadato_learning_style_1']);
			$metadato_learning_style_2 = clean_input($_POST['metadato_learning_style_2']);
			$metadato_learning_style_3 = clean_input($_POST['metadato_learning_style_3']);
			$metadato_learning_style_4 = clean_input($_POST['metadato_learning_style_4']);
			$metadato_tem_conc = clean_input($_POST['metadato_tem_conc']);
			$metadato_tempo = clean_input($_POST['metadato_tempo']);
			
			// $meta_concat e' una variabile stringa di valori inseriti nel form  
			$meta_concat = $metadato_prerequisiti . ',' . $metadato_conosc_acquisite . ',' . $metadato_name . ',' . $metadato_learning_style_1;
			$meta_concat .= ',' . $metadato_learning_style_2 . ',' . $metadato_learning_style_3 . ',' . $metadato_learning_style_4;
			
			//$tempo = date("M,d,Y h:i:s A");

			// mdl_teacherassistant_concatena e' una tabella di appoggio che mi serve per non avere due o piu' righe uguali nella tabella mdl_teacherassistant_modulo 
			$sql2 = 'INSERT INTO mdl_teacherassistant_concatena(meta_concat) VALUES';
			$sql2 .= "('$meta_concat');";
			$res = $mysqli->query($sql2);
				if (!$res) {
					echo $mysqli->error . '<br>';
				} else {
			// l'if seguente assegna alla variabile metadato_name il valore di una stringa in caso sia stato settato a NULL che mi restituirebbe un errore	
			if($metadato_name === "")($metadato_name = "nessuna scelta");


			$sql5 = 'INSERT INTO mdl_teacherassistant_tempo(metadato_cors_identif,metadato_cors_nom,metadato_cors_sect_identif,metadato_prerequisiti,metadato_conosc_acquisite,metadato_name,metadato_learning_style_1,metadato_learning_style_2,metadato_learning_style_3,metadato_learning_style_4,metadato_tem_conc,metadato_tempo) VALUES';
			$sql5 .= "($metadato_cors_identif,'$metadato_cors_nom',$metadato_cors_sect_identif,'$metadato_prerequisiti','$metadato_conosc_acquisite','$metadato_name',$metadato_learning_style_1,$metadato_learning_style_2,$metadato_learning_style_3,$metadato_learning_style_4,$metadato_tem_conc,'$metadato_tempo');";
			$res = $mysqli->query($sql5);
				if (!$res) {
					echo $mysqli->error . '<br>';
				} else {
                    echo '';
                }
			// mdl_teacherassistant_metadato mi serve per avere valori non ripetuti nel form alla voce prerequisiti e conoscenze acquisite
			// quindi se non inserisco nella casella di testo del form una nuova conoscenza acquisita non devo aggiornare la tabella
			if(($metadato_name == null)||($metadato_name == "nessuna scelta")) {
				echo '';
			}else {
				// aggiorno la tabella con una nuova conoscenza acquisita
				$sql1 = 'INSERT INTO mdl_teacherassistant_metadato(metadato_conosc_acquisite) VALUES';
				$sql1 .= "('$metadato_name');";
				echo '<br>';
				$res = $mysqli->query($sql1);
				if (!$res) {
					echo $mysqli->error . '<br>';
				} else {
					echo '';
				}
			}
		}
		$properties_array = array($metadato_cors_identif,$metadato_cors_nom,$metadato_cors_sect_identif,$metadato_prerequisiti,$metadato_conosc_acquisite,$metadato_name,$metadato_learning_style_1,$metadato_learning_style_2,$metadato_learning_style_3,$metadato_learning_style_4,$metadato_tem_conc,$metadato_tempo);
			$lab = $container->create_object($properties_array);

			print "Aggiornamenti riusciti<br />";
			get_metadato_app_properties($lab);
		}

		else
		{

			print "<p>Parametri mancanti o non validi. Torna alla pagina metadato.html per inserire informazioni valide.<br />";

			print "<a href='view.php'>pagina di creazione metadato</a>";

		}
	}
}
catch(setException $e)
{
	echo $e->errorMessage(); // viene visualizzato all'utente

	$date = date('m.d.Y h:i:s');
	$errormessage = $e->errorMessage();
	$eMessage =  $date . " | User Error | " . $errormessage . "\n";
	error_log($eMessage,3,USER_ERROR_LOG); // scrive il messaggio nel file di registro degli errori dell'utente

}
catch(Exception $e)
{

	echo "Il sistema non è attualmente disponibile. Per favore riprova più tardi."; // visualizza un messaggio per l'utente

	$date = date('m.d.Y h:i:s');
	$eMessage =  $date . " | System Error | " . $e->getMessage() . " | " . $e->getFile() . " | ". $e->getLine() . "\n";
	error_log($eMessage,3,ERROR_LOG); // scrive il messaggio nel file di registro degli errori
	error_log("Data/Orario: $date - Gravi problemi di sistema con l'applicazione metadato. Controlla il registro degli errori per i dettagli", 1, "p.scimia@gmail.com", "Oggetto: Errore dell'applicazione metadato \nDa: Registro di sistema <p.scimia@gmail.com>". "\r\n");
	// invia un'e-mail al personale per avvisarlo di un problema di sistema

}
// Non ci sono tag di chiusura php in questo file,
// è intenzionale perché previene problemi di spazi vuoti finali!