<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Questa è una breve descrizione di una riga del file
 *
 * Puoi anche avere una descrizione più lunga del file,
 * se vuoi, e può estendersi su più righe.
 *
 * @package    mod_teacherassistant
 * @copyright  COPYRIGHTNOTICE
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(dirname(dirname(dirname(__FILE__))).'/config.php');
require_once(dirname(__FILE__).'/lib.php');

global $DB;

$id = required_param('id', PARAM_INT);   // course id

$course = $DB->get_record('course', array('id' => $id), '*', MUST_EXIST);

require_course_login($course, true);

add_to_log($course->id, 'teacherassistant', 'view all', 'index.php?id='.$course->id, '');

$coursecontext = context_course::instance($course->id);

$PAGE->set_url('/mod/teacherassistant/index.php', array('id' => $id));
$PAGE->set_title(format_string($course->fullname));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($coursecontext);

echo $OUTPUT->header();

if (! $teacherassistants = get_all_instances_in_course('teacherassistant', $course)) {
    notice(get_string('noteacherassistants', 'teacherassistant'), new moodle_url('/course/view.php', array('id' => $course->id)));
}

$table = new html_table();
if ($course->format == 'weeks') {
    $table->head  = array(get_string('week'), get_string('name'));
    $table->align = array('center', 'left');
} else if ($course->format == 'topics') {
    $table->head  = array(get_string('topic'), get_string('name'));
    $table->align = array('center', 'left', 'left', 'left');
} else {
    $table->head  = array(get_string('name'));
    $table->align = array('left', 'left', 'left');
}

foreach ($teacherassistants as $teacherassistant) {
    if (!$teacherassistant->visible) {
        $link = html_writer::link(
            new moodle_url('/mod/teacherassistant/view.php', array('id' => $teacherassistant->coursemodule)),
            format_string($teacherassistant->name, true),
            array('class' => 'dimmed'));
    } else {
        $link = html_writer::link(
            new moodle_url('/mod/teacherassistant/view.php', array('id' => $teacherassistant->coursemodule)),
            format_string($teacherassistant->name, true));
    }
    
    if ($course->format == 'weeks' or $course->format == 'topics') {
        $table->data[] = array($teacherassistant->section, $link);
    } else {
        $table->data[] = array($link);
    }
}

echo $OUTPUT->heading(get_string('modulenameplural', 'teacherassistant'), 2);
echo html_writer::table($table);
echo $OUTPUT->footer();
// Non ci sono tag di chiusura php in questo file,
// è intenzionale perché previene problemi di spazi vuoti finali!