<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
* Imposta le schede nella parte superiore della pagina di visualizzazione del modulo per gli teacherassistant.
*
* Questo file è stato adattato dal mod/lesson/tabs.php
*
 * @package mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or late
*/

defined('MOODLE_INTERNAL') || die();

/// Questo file deve essere incluso, quindi possiamo supporre che config2.php sia già stato incluso.
global $DB;
if (empty($moduleinstance)) {
    print_error('cannotcallscript');
}
if (!isset($currenttab)) {
    $currenttab = '';
}
if (!isset($cm)) {
    $cm = get_coursemodule_from_instance(MOD_TEACHERASSISTANT_MODNAME, $moduleinstance->id);
    $context = context_module::instance($cm->id);
}
if (!isset($course)) {
    $course = $DB->get_record('course', array('id' => $moduleinstance->course));
}

$tabs = $row = $inactive = $activated = array();


$row[] = new tabobject('view', "$CFG->wwwroot/mod/teacherassistant/view.php?id=$cm->id", get_string('view', MOD_TEACHERASSISTANT_LANG), get_string('preview', MOD_TEACHERASSISTANT_LANG, format_string($moduleinstance->name)));
$row[] = new tabobject('reports', "$CFG->wwwroot/mod/teacherassistant/reports.php?id=$cm->id", get_string('reports', MOD_TEACHERASSISTANT_LANG), get_string('viewreports', MOD_TEACHERASSISTANT_LANG));

$tabs[] = $row;

print_tabs($tabs, $currenttab, $inactive, $activated);
// Non ci sono tag di chiusura php in questo file,
// è intenzionale perché previene problemi di spazi vuoti finali!