<?php
// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Reindirizzare l'utente alla pagina relativa all'invio appropriata
 *
 * @package   mod_teacherassistant
 * @category  grade
 * @copyright 2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once(dirname(dirname(dirname(__FILE__))).'/config.php');

$id = required_param('id', PARAM_INT);          // ID del modulo del corso
$itemnumber = optional_param('itemnumber', 0, PARAM_INT); // Numero articolo, può essere != 0 per attività che consentono più di un voto per utente
$userid = optional_param('userid', 0, PARAM_INT); // ID utente classificato (opzionale)

//nel caso più semplice reindirizzare alla pagina di visualizzazione
redirect('view.php?id='.$id);
// Non ci sono tag di chiusura php in questo file,
// è intenzionale perché previene problemi di spazi vuoti finali!