<?php
// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Stampa un'istanza particolare di insegnante
 *
 * Puoi anche avere una descrizione più lunga del file,
 * se vuoi, e può estendersi su più righe.
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
*/ 

$sql1= 'CREATE TABLE if not exists mdl_teacherassistant_modulo (';
$sql1 .= 'id BIGINT(3) NOT NULL auto_increment,';
$sql1 .= 'metadato_cors_identif BIGINT(3) NOT NULL,';
$sql1 .= 'metadato_cors_nom VARCHAR(128) COLLATE utf8_general_ci,';
$sql1 .= 'metadato_cors_sect_identif BIGINT(3) NOT NULL,';
$sql1 .= 'metadato_cors_sect_nom VARCHAR(128) COLLATE utf8_general_ci,';
$sql1 .= 'metadato_prerequisiti VARCHAR(2048) NOT NULL COLLATE utf8_general_ci,';
$sql1 .= 'metadato_conosc_acquisite VARCHAR(516) NOT NULL COLLATE utf8_general_ci,';
$sql1 .= 'metadato_name VARCHAR(1024) NOT NULL COLLATE utf8_general_ci,';
$sql1 .= 'metadato_learning_style_1 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_learning_style_2 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_learning_style_3 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_learning_style_4 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_tem_conc NUMERIC(2) NOT NULL,';
$sql1 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql1 .= ')';
$sql1 .= 'ENGINE = InnoDB ';
$sql1 .= 'DEFAULT COLLATE = utf8_general_ci ROW_FORMAT=Compressed;';

$res=$mysqli->query($sql1);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '';
}

$sql2 = 'CREATE TABLE if not exists mdl_teacherassistant_metadato (';
$sql2 .= 'id BIGINT(4) NOT NULL auto_increment,';
$sql2 .= 'metadato_conosc_acquisite VARCHAR(256) UNIQUE NOT NULL COLLATE utf8_general_ci,';
$sql2 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql2 .= ')';
$sql2 .= 'ENGINE = InnoDB ';
$sql2 .= 'DEFAULT COLLATE = utf8_general_ci ROW_FORMAT=Compressed;';

$res=$mysqli->query($sql2);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '';
}

$sql3 = 'CREATE TABLE if not exists mdl_teacherassistant_concatena (';
$sql3 .= 'id BIGINT(4) NOT NULL auto_increment,';
$sql3 .= 'meta_concat VARCHAR(1020) UNIQUE NOT NULL COLLATE utf8_general_ci,';
$sql3 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql3 .= ')';
$sql3 .= 'ENGINE = InnoDB ';
$sql3 .= 'DEFAULT COLLATE = utf8_general_ci ROW_FORMAT=Compressed;';

$res=$mysqli->query($sql3);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '';
}

$sql4 = 'CREATE TABLE if not exists mdl_teacherassistant_tempo (';
$sql4 .= 'id BIGINT(4) NOT NULL auto_increment,';
$sql4 .= 'tempo VARCHAR(255) UNIQUE NOT NULL COLLATE utf8_general_ci,';
$sql4 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql4 .= ')';
$sql4 .= 'ENGINE = InnoDB ';
$sql4 .= 'DEFAULT COLLATE = utf8_general_ci ROW_FORMAT=Compressed;';

$res=$mysqli->query($sql4);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '';
}

$tempo = date("M,d,Y h:i:s A");


$sql5 = 'INSERT INTO mdl_teacherassistant_tempo(tempo) VALUES';
			$sql5 .= "('$tempo');";
			$res = $mysqli->query($sql5);
				if (!$res) {
					echo $mysqli->error . '<br>';
				} else {
                    echo '';
                }
// Non ci sono tag di chiusura php in questo file,
// è intenzionale perché previene problemi di spazi vuoti finali!