<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Questo file tiene traccia degli aggiornamenti del modulo teacherassistant
 *
 * A volte, le modifiche tra le versioni comportano modifiche al database
 * strutture e altre cose importanti che potrebbero rompere le installazioni. L'aggiornamento
 * la funzione in questo file tenterà di eseguire tutte le azioni necessarie per
 * aggiorna la tua installazione precedente alla versione corrente. Se c'è qualcosa
 * non può fare se stesso, ti dirà cosa devi fare. I comandi in
 * qui saranno tutti neutrali rispetto al database, usando le funzioni definite nelle librerie DLL.
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Eseguire l'aggiornamento dell'assistente insegnante dalla versione precedente indicata
 *
 * @param int $oldversion
 * @return bool
 */
function xmldb_teacherassistant_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager(); // loads ddl manager and xmldb classes

    // E l'aggiornamento inizia qui. Per ognuno, ne avrai bisogno
    //     blocco di codice simile al successivo. Per piacere cancella
    //     questo commento appare una volta che questo file inizia a funzionare correttamente
    //      codice di aggiornamento.

    // if ($oldversion < YYYYMMDD00) { //Nuova versione in version.php
    //
    // }

    // Le righe sottostanti (incluse) devono essere eliminate una volta ottenuta la prima versione
    //      del tuo modulo pronto per essere installato. Sono solo qui
    //      a scopo dimostrativo e per mostrare come teacherassistant
    //     stesso è stato aggiornato.


    // Per ogni blocco di aggiornamento, il file insegnanteassistant / version.php
    //     deve essere aggiornato. Tale cambiamento consente a Moodle di saperlo
    //     che questo file deve essere elaborato.


    // Per saperne di più su come scrivere script di aggiornamento DB corretti è
    //      altamente raccomandato di leggere le informazioni disponibili su:
    //      http://docs.moodle.org/en/Development:XMLDB_Documentation
    //     e per giocare con XMLDB Editor (nel menu admin) e i suoi
    //    Possibilità di generazione di PHP.

    // Primo esempio, alcuni campi sono stati aggiunti a install.xml il 2007/04/01
    if ($oldversion < 2007040100) {

        // Definire il corso sul campo da aggiungere al teacherassistant
        $table = new xmldb_table('teacherassistant');
        $field = new xmldb_field('course', XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, '0', 'id');

        // Aggiungi campo corso
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Definire l'introduzione sul campo da aggiungere al teacherassistant
        $table = new xmldb_table('teacherassistant');
        $field = new xmldb_field('intro', XMLDB_TYPE_TEXT, 'medium', null, null, null, null,'name');

        // Aggiungi campo intro
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Definire il campo introformat da aggiungere a teacherassistant
        $table = new xmldb_table('teacherassistant');
        $field = new xmldb_field('introformat', XMLDB_TYPE_INTEGER, '4', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, '0',
            'intro');

        // Aggiungi campo introformat
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Una volta raggiunto questo punto, possiamo memorizzare la nuova versione e considerare il modulo
        //       aggiornato alla versione 2007040100 quindi la prossima volta questo blocco viene saltato
        upgrade_mod_savepoint(true, 2007040100, 'teacherassistant');
    }

    // Secondo esempio, alcune ore dopo, lo stesso giorno 2007/04/01
    //     altri due campi e un indice sono stati aggiunti a install.xml (notare il microincremento
    //      "01" nelle ultime due cifre della versione
    if ($oldversion < 2007040101) {

        // Definire il campo timecreated per essere aggiunto a teacherassistant
        $table = new xmldb_table('teacherassistant');
        $field = new xmldb_field('timecreated', XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, '0',
            'introformat');

        // Aggiungi campo timecreated
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Definire il campo timemodified per essere aggiunto a  teacherassistant
        $table = new xmldb_table('teacherassistant');
        $field = new xmldb_field('timemodified', XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, '0',
            'timecreated');

        // Aggiungi campo timemodified
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Definire  indice course (not unique) per essere aggiunto a  teacherassistant
        $table = new xmldb_table('teacherassistant');
        $index = new xmldb_index('courseindex', XMLDB_INDEX_NOTUNIQUE, array('course'));

        //Aggiungi indice a campo course
        if (!$dbman->index_exists($table, $index)) {
            $dbman->add_index($table, $index);
        }

        // È stato raggiunto un altro punto di salvataggio
        upgrade_mod_savepoint(true, 2007040101, 'teacherassistant');
    }

    // Terzo esempio, il giorno successivo, 2007/04/02 (con il trailing 00), sono state eseguite alcune azioni per install.php,
    //     in relazione con il modulo
    if ($oldversion < 2007040200) {

        // inserisci qui il codice per eseguire alcune azioni (come in install.php)

        upgrade_mod_savepoint(true, 2007040200, 'teacherassistant');
    }

    // E questo è tutto. Si prega di esaminare e comprendere i 3 blocchi di esempio sopra. Anche
    //     è interessante vedere come altri moduli utilizzano questo script. Ricordati che
    //    l'idea di base è di avere "blocchi" di codice (ognuno eseguito una sola volta,
    //    quando viene aggiornata la versione del modulo (version.php).

    // Le righe sopra (incluso) DEVONO ESSERE CANCELLATE una volta ottenuta la prima versione di
    //     il tuo modulo funziona. Ogni volta che è necessario modificare qualcosa nel modulo (DB
    //     correlati, aumenterai la versione e aggiungerai un blocco di aggiornamento qui.

    // Restituzione finale del risultato dell'aggiornamento (vero, tutto è andato bene) a Moodle.
    return true;
}

