<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Definizione degli eventi di registro
 *
 * NOTA: questo è un esempio di come inserire l'evento di registro durante l'installazione / l'aggiornamento.
 * Non è davvero essenziale conoscerlo, ma questi log sono stati creati come esempio
 * nella precedente versione 1.9.
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

global $DB;

$logs = array(
    array('module'=>'teacherassistant', 'action'=>'add', 'mtable'=>'teacherassistant', 'field'=>'name'),
    array('module'=>'teacherassistant', 'action'=>'update', 'mtable'=>'teacherassistant', 'field'=>'name'),
    array('module'=>'teacherassistant', 'action'=>'view', 'mtable'=>'teacherassistant', 'field'=>'name'),
    array('module'=>'teacherassistant', 'action'=>'view all', 'mtable'=>'teacherassistant', 'field'=>'name')
);

