<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Libreria di funzioni di interfaccia e costanti per il modulo teacherassistant
 *
 * Tutte le funzioni principali di Moodle, necessarie per consentire al modulo di funzionare
 * integrato in Moodle dovrebbe essere posizionato qui.
 * Tutte le funzioni specifiche dell'assistente insegnante, necessarie per implementare tutto il modulo
 * logica, dovrebbe andare su locallib.php. Ciò contribuirà a risparmiare un po 'di memoria quando
 * Moodle sta eseguendo azioni su tutti i moduli.
 *
 * @package    mod_teacherassistant
 * @copyright  COPYRIGHTNOTICE
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

define('MOD_TEACHERASSISTANT_FRANKY','mod_teacherassistant');
define('MOD_TEACHERASSISTANT_LANG','mod_teacherassistant');
define('MOD_TEACHERASSISTANT_TABLE','teacherassistant');
define('MOD_TEACHERASSISTANT_USERTABLE','teacherassistant_attempt');
define('MOD_TEACHERASSISTANT_MODNAME','teacherassistant');
define('MOD_TEACHERASSISTANT_URL','/mod/teacherassistant');
define('MOD_TEACHERASSISTANT_CLASS','mod_teacherassistant');

define('MOD_TEACHERASSISTANT_GRADEHIGHEST', 0);
define('MOD_TEACHERASSISTANT_GRADELOWEST', 1);
define('MOD_TEACHERASSISTANT_GRADELATEST', 2);
define('MOD_TEACHERASSISTANT_GRADEAVERAGE', 3);
define('MOD_TEACHERASSISTANT_GRADENONE', 4);


////////////////////////////////////////////////////////////////////////////////
// API core di Moodle                                                          //
////////////////////////////////////////////////////////////////////////////////

/**
 * Restituisce le informazioni su se il modulo supporta una funzione
 *
 * @see plugin_supports() in lib/moodlelib.php
 * @param string $feature FEATURE_xx costante per la funzione richiesta
 * @return mixed vero se la funzione è supportata, null se sconosciuto
 */
function teacherassistant_supports($feature) {
    switch($feature) {
        case FEATURE_MOD_INTRO:         return true;
        case FEATURE_SHOW_DESCRIPTION:  return true;
        case FEATURE_COMPLETION_HAS_RULES: return true;
        case FEATURE_COMPLETION_TRACKS_VIEWS: return true;
        case FEATURE_GRADE_HAS_GRADE:         return true;
        case FEATURE_GRADE_OUTCOMES:          return true;
        case FEATURE_BACKUP_MOODLE2:          return true;
        default:                        return null;
    }
}

/**
 * Implementazione della funzione per la stampa degli elementi del modulo che controllano
 * se la funzionalità di ripristino del corso influenza teacherassistant.
 *
 * @param $mform modulo passato per riferimento
 */
function teacherassistant_reset_course_form_definition(&$mform) {
    $mform->addElement('header', MOD_TEACHERASSISTANT_MODNAME . 'header', get_string('modulenameplural', MOD_TEACHERASSISTANT_LANG));
    $mform->addElement('advcheckbox', 'reset_' . MOD_TEACHERASSISTANT_MODNAME , get_string('deletealluserdata',MOD_TEACHERASSISTANT_LANG));
}

/**
 * Impostazioni predefinite modulo di ripristino corso.
 * @param object $course
 * @return array
 */
function teacherassistant_reset_course_form_defaults($course) {
    return array('reset_' . MOD_TEACHERASSISTANT_MODNAME =>1);
}

/**
 * Rimuove tutti i voti dal registro dei voti
 *
 * @global stdClass
 * @global object
 * @param int $courseid
 * @param string tipo opzionale
 */
function teacherassistant_reset_gradebook($courseid, $type='') {
    global $CFG, $DB;

    $sql = "SELECT l.*, cm.idnumber as cmidnumber, l.course as courseid
              FROM {" . MOD_TEACHERASSISTANT_TABLE . "} l, {course_modules} cm, {modules} m
             WHERE m.name='" . MOD_TEACHERASSISTANT_MODNAME . "' AND m.id=cm.module AND cm.instance=l.id AND l.course=:course";
    $params = array ("course" => $courseid);
    if ($moduleinstances = $DB->get_records_sql($sql,$params)) {
        foreach ($moduleinstances as $moduleinstance) {
            teacherassistant_grade_item_update($moduleinstance, 'reset');
        }
    }
}

/**
 * Implementazione effettiva della funzionalità di ripristino del corso, eliminare tutto

 * i tentativi del teacherassistant per il corso $ data-> courseid.
 *
 * @global stdClass
 * @global object
 * @param object $data i dati inviati dal ripristino del corso.
 * @return array matrice di stato
 */
function teacherassistant_reset_userdata($data) {
    global $CFG, $DB;

    $componentstr = get_string('modulenameplural', MOD_TEACHERASSISTANT_LANG);
    $status = array();

    if (!empty($data->{'reset_' . MOD_TEACHERASSISTANT_MODNAME})) {
        $sql = "SELECT l.id
                         FROM {".MOD_TEACHERASSISTANT_TABLE."} l
                        WHERE l.course=:course";

        $params = array ("course" => $data->courseid);
        $DB->delete_records_select(MOD_TEACHERASSISTANT_USERTABLE, MOD_TEACHERASSISTANT_MODNAME . "id IN ($sql)", $params);

        // rimuovere tutti i voti dal registro dei voti
        if (empty($data->reset_gradebook_grades)) {
            teacherassistant_reset_gradebook($data->courseid);
        }

        $status[] = array('component'=>$componentstr, 'item'=>get_string('deletealluserdata', MOD_TEACHERASSISTANT_LANG), 'error'=>false);
    }

    /// date di aggiornamento - anche il turno potrebbe essere negativo
    if ($data->timeshift) {
        shift_course_mod_dates(MOD_TEACHERASSISTANT_MODNAME, array('available', 'deadline'), $data->timeshift, $data->courseid);
        $status[] = array('component'=>$componentstr, 'item'=>get_string('datechanged'), 'error'=>false);
    }

    return $status;
}




/**
 * Crea un elemento di valutazione per l'istanza dell'attività
 *
 * @category grade
 * @uses GRADE_TYPE_VALUE
 * @uses GRADE_TYPE_NONE
 * @param object $moduleinstance oggetto con un numero di cmid aggiuntivo
 * @param array|object $grades optional array/object of grade(s); 'reset' significa ripristinare i voti nel registro dei voti
 * @return int 0 se ok, codice di errore altrimenti
 */
function teacherassistant_grade_item_update($moduleinstance, $grades=null) {
    global $CFG;
    if (!function_exists('grade_update')) { //soluzione alternativa per le versioni buggy di PHP
        require_once($CFG->libdir.'/gradelib.php');
    }

    if (array_key_exists('cmidnumber', $moduleinstance)) { //potrebbe non essere sempre presente
        $params = array('itemname'=>$moduleinstance->name, 'idnumber'=>$moduleinstance->cmidnumber);
    } else {
        $params = array('itemname'=>$moduleinstance->name);
    }

    if ($moduleinstance->grade > 0) {
        $params['gradetype']  = GRADE_TYPE_VALUE;
        $params['grademax']   = $moduleinstance->grade;
        $params['grademin']   = 0;
    } else if ($moduleinstance->grade < 0) {
        $params['gradetype']  = GRADE_TYPE_SCALE;
        $params['scaleid']   = -$moduleinstance->grade;

        // Assicurarsi che il voto corrente sia stato preso correttamente da $grades
        $currentgrade = null;
        if (!empty($grades)) {
            if (is_array($grades)) {
                $currentgrade = reset($grades);
            } else {
                $currentgrade = $grades;
            }
        }

        // Quando si converte un punteggio in una scala, utilizzare il punteggio massimo della scala per calcolarlo.
        if (!empty($currentgrade) && $currentgrade->rawgrade !== null) {
            $grade = grade_get_grades($moduleinstance->course, 'mod', MOD_TEACHERASSISTANT_MODNAME, $moduleinstance->id, $currentgrade->userid);
            $params['grademax']   = reset($grade->items)->grademax;
        }
    } else {
        $params['gradetype']  = GRADE_TYPE_NONE;
    }

    if ($grades  === 'reset') {
        $params['reset'] = true;
        $grades = null;
    } else if (!empty($grades)) {
        // È necessario calcolare il voto grezzo (Nota: i $grades hanno molte forme)
        if (is_object($grades)) {
            $grades = array($grades->userid => $grades);
        } else if (array_key_exists('userid', $grades)) {
            $grades = array($grades['userid'] => $grades);
        }
        foreach ($grades as $key => $grade) {
            if (!is_array($grade)) {
                $grades[$key] = $grade = (array) $grade;
            }
            //controlla che il voto grezzo non sia nullo altrimenti inseriamo un voto pari a 0
            if ($grade['rawgrade'] !== null) {
                $grades[$key]['rawgrade'] = ($grade['rawgrade'] * $params['grademax'] / 100);
            } else {
                //impostando rawgrade su null nel caso in cui l'utente stia eliminando un voto
                $grades[$key]['rawgrade'] = null;
            }
        }
    }


    return grade_update('mod/' . MOD_TEACHERASSISTANT_MODNAME, $moduleinstance->course, 'mod', MOD_TEACHERASSISTANT_MODNAME, $moduleinstance->id, 0, $grades, $params);
}

/**
 * Aggiornare i voti nel registro dei voti centrale
 *
 * @category grade
 * @param object $moduleinstance
 * @param int $userid solo utente specifico, 0 significa tutto
 * @param bool $nullifnone
 */
function teacherassistant_update_grades($moduleinstance, $userid=0, $nullifnone=true) {
    global $CFG, $DB;
    require_once($CFG->libdir.'/gradelib.php');

    if ($moduleinstance->grade == 0) {
        teacherassistant_grade_item_update($moduleinstance);

    } else if ($grades = teacherassistant_get_user_grades($moduleinstance, $userid)) {
        teacherassistant_grade_item_update($moduleinstance, $grades);

    } else if ($userid and $nullifnone) {
        $grade = new stdClass();
        $grade->userid   = $userid;
        $grade->rawgrade = null;
        teacherassistant_grade_item_update($moduleinstance, $grade);

    } else {
        teacherassistant_grade_item_update($moduleinstance);
    }
    
    //echo "updategrades" . $userid;
}

/**
 * Valutazione di ritorno per un determinato utente o tutti gli utenti.
 *
 * @global stdClass
 * @global object
 * @param int $moduleinstance
 * @param int $userid ID utente opzionale, 0 indica tutti gli utenti
 * @return array matrice di voti, falsa se nessuna
 */
function teacherassistant_get_user_grades($moduleinstance, $userid=0) {
    global $CFG, $DB;

    $params = array("moduleid" => $moduleinstance->id);

    if (!empty($userid)) {
        $params["userid"] = $userid;
        $user = "AND u.id = :userid";
    }
    else {
        $user="";

    }

    $idfield = 'a.' . MOD_TEACHERASSISTANT_MODNAME . 'id';
    if ($moduleinstance->maxattempts==1 || $moduleinstance->gradeoptions == MOD_TEACHERASSISTANT_GRADELATEST) {

        $sql = "SELECT u.id, u.id AS userid, a.sessionscore AS rawgrade
                  FROM {user} u,  {". MOD_TEACHERASSISTANT_USERTABLE ."} a
                 WHERE u.id = a.userid AND $idfield = :moduleid
                       AND a.status = 1
                       $user";
    
    }else{
        switch($moduleinstance->gradeoptions){
            case MOD_TEACHERASSISTANT_GRADEHIGHEST:
                $sql = "SELECT u.id, u.id AS userid, MAX( a.sessionscore  ) AS rawgrade
                      FROM {user} u, {". MOD_TEACHERASSISTANT_USERTABLE ."} a
                     WHERE u.id = a.userid AND $idfield = :moduleid
                           $user
                  GROUP BY u.id";
                  break;
            case MOD_TEACHERASSISTANT_GRADELOWEST:
                $sql = "SELECT u.id, u.id AS userid, MIN(  a.sessionscore  ) AS rawgrade
                      FROM {user} u, {". MOD_TEACHERASSISTANT_USERTABLE ."} a
                     WHERE u.id = a.userid AND $idfield = :moduleid
                           $user
                  GROUP BY u.id";
                  break;
            case MOD_TEACHERASSISTANT_GRADEAVERAGE:
            $sql = "SELECT u.id, u.id AS userid, AVG( a.sessionscore  ) AS rawgrade
                      FROM {user} u, {". MOD_TEACHERASSISTANT_USERTABLE ."} a
                     WHERE u.id = a.userid AND $idfield = :moduleid
                           $user
                  GROUP BY u.id";
                  break;

        }

    } 

    return $DB->get_records_sql($sql, $params);
}


function teacherassistant_get_completion_state($course,$cm,$userid,$type) {
    return teacherassistant_is_complete($course,$cm,$userid,$type);
}


//questo è chiamato solo internamente
function teacherassistant_is_complete($course,$cm,$userid,$type) {
     global $CFG,$DB;


    // Ottieni oggetto modulo
    if(!($moduleinstance=$DB->get_record(MOD_TEACHERASSISTANT_TABLE,array('id'=>$cm->instance)))) {
        throw new Exception("Impossibile trovare il modulo con cmid: {$cm->instance}");
    }
    $idfield = 'a.' . MOD_TEACHERASSISTANT_MODNAME . 'id';
    $params = array('moduleid'=>$moduleinstance->id, 'userid'=>$userid);
    $sql = "SELECT  MAX( sessionscore  ) AS grade
                      FROM {". MOD_TEACHERASSISTANT_USERTABLE ."}
                     WHERE userid = :userid AND " . MOD_TEACHERASSISTANT_MODNAME . "id = :moduleid";
    $result = $DB->get_field_sql($sql, $params);
    if($result===false){return false;}
     
    //controllare le richieste di completamento a condizioni soddisfatte
    switch ($type){
        case COMPLETION_AND:
            $success = $result >= $moduleinstance->mingrade;
            break;
        case COMPLETION_OR:
            $success = $result >= $moduleinstance->mingrade;
    }
    //restituire la nostra bandiera di successo
    return $success;
}


/**
 * A task called from scheduled or adhoc
 *
 * @param progress_trace trace object
 *
 */
function teacherassistant_dotask(progress_trace $trace) {
    $trace->output('executing dotask');
}

/**
 * Salva una nuova istanza del teacherassistant nel database
 *
 * Dato un oggetto contenente tutti i dati necessari,
 * (definita dal modulo in mod_form.php) questa funzione
 * creerà una nuova istanza e restituirà il numero ID
 * della nuova istanza.
 *
 * @param object $teacherassistant Un oggetto dal modulo in mod_form.php
 * @param mod_teacherassistant_mod_form $mform
 * @return int L'ID del record di teacherassistant appena inserito
 */
function teacherassistant_add_instance(stdClass $teacherassistant, mod_teacherassistant_mod_form $mform = null) {
    global $DB;

    $teacherassistant->timecreated = time();

    # Potrebbe essere necessario aggiungere altro materiale qui #

    return $DB->insert_record(MOD_TEACHERASSISTANT_TABLE, $teacherassistant);
}

/**
 * Aggiorna un'istanza del teacherassistant nel database
 *
 * Dato un oggetto contenente tutti i dati necessari,
 * (definita dal modulo in mod_form.php) questa funzione
 * aggiornerà un'istanza esistente con nuovi dati.
 *
 * @param object $teacherassistant Un oggetto dal modulo in mod_form.php
 * @param mod_teacherassistant_mod_form $mform
 * @return boolean Success/Fail
 */
function teacherassistant_update_instance(stdClass $teacherassistant, mod_teacherassistant_mod_form $mform = null) {
    global $DB;

    $teacherassistant->timemodified = time();
    $teacherassistant->id = $teacherassistant->instance;

    # Potrebbe essere necessario aggiungere altro materiale qui #

    return $DB->update_record(MOD_TEACHERASSISTANT_TABLE, $teacherassistant);
}

/**
 * Rimuove un'istanza del teacherassistant dal database
 *
 * Dato un ID di un'istanza di questo modulo,
 * questa funzione eliminerà definitivamente l'istanza
 * e tutti i dati che dipendono da esso.
 *
 * @param int $id ID dell'istanza del modulo
 * @return boolean Success/Failure
 */
function teacherassistant_delete_instance($id) {
    global $DB;

    if (! $teacherassistant = $DB->get_record(MOD_TEACHERASSISTANT_TABLE, array('id' => $id))) {
        return false;
    }

    # Elimina qui tutti i record dipendenti #

    $DB->delete_records(MOD_TEACHERASSISTANT_TABLE, array('id' => $teacherassistant->id));

    return true;
}

/**
 * Restituisce un piccolo oggetto con informazioni di riepilogo su cosa: a
 * l'utente ha fatto con una determinata istanza particolare di questo modulo
 * Utilizzato per i rapporti sulle attività degli utenti.
 * $return->time = l'ora in cui l'hanno fatto
 * $return->info = una breve descrizione testuale
 *
 * @return stdClass|null
 */
function teacherassistant_user_outline($course, $user, $mod, $teacherassistant) {

    $return = new stdClass();
    $return->time = 0;
    $return->info = '';
    return $return;
}

/**
 * Stampa una rappresentazione dettagliata di ciò che un utente ha fatto
 * una determinata istanza particolare di questo modulo, per i rapporti sulle attività degli utenti.
 *
 * @param stdClass $course il record del corso corrente
 * @param stdClass $user il record dell'utente per il quale stiamo generando report
 * @param cm_info $mod informazioni sul modulo del corso
 * @param stdClass $teacherassistant il record dell'istanza del modulo
 * @return void, dovrebbe chiudere direttamente
 */
function teacherassistant_user_complete($course, $user, $mod, $teacherassistant) {
}

/**
 * Dato un corso e un tempo, questo modulo dovrebbe trovare attività recenti
che si è verificato nelle attività di assistenza degli insegnanti e stamparlo.
Restituisce vero se c'è stato un output, o falso non ce n'è uno.
 * che si è verificato nelle attività di assistenza degli insegnanti e stamparlo.
 * Restituisce vero se c'è stato un output, o falso non ce n'è uno.
 *
 * @return boolean
 */
function teacherassistant_print_recent_activity($course, $viewfullnames, $timestart) {
    return false;  //  True if anything was printed, otherwise false
}

/**
 * Prepara i dati di attività recenti
 *
 * Questa funzione di callback dovrebbe popolare l'array passato con
 * record di attività personalizzati. Questi record vengono quindi resi in HTML tramite
 * {@link teacherassistant_print_recent_mod_activity()}.
 *
 * @param array $activities array di oggetti indicizzato sequenzialmente con la proprietà 'cmid'
 * @param int $index l'indice nelle $activities da utilizzare per il record successivo
 * @param int $timestart aggiungere attività da questo momento
 * @param int $courseid l'id del corso per cui produciamo il rapporto
 * @param int $cmid ID modulo corso
 * @param int $userid verifica solo l'attività di un determinato utente, il valore predefinito è 0 (tutti gli utenti)
 * @param int $groupid controlla solo l'attività di un determinato gruppo, il valore predefinito è 0 (tutti i gruppi)
 * @return void aggiunge elementi in $activities e aumenta $index
 */
function teacherassistant_get_recent_mod_activity(&$activities, &$index, $timestart, $courseid, $cmid, $userid=0, $groupid=0) {
}

/**
 * Stampa l'elemento di singola attività preparato da {@see teacherassistant_get_recent_mod_activity()}

 * @return void
 */
function teacherassistant_print_recent_mod_activity($activity, $courseid, $detail, $modnames, $viewfullnames) {
}

/**
 * Funzione da eseguire periodicamente secondo il cron di moodle
 * Questa funzione cerca cose che devono essere fatte, ad esempio
 * come invio di posta, attivazione / disattivazione di bandiere ecc ...
 *
 * @return boolean
 * @todo Termina la documentazione di questa funzione
 **/
function teacherassistant_cron () {
    return true;
}

/**
 * Restituisce tutti gli altri tappi utilizzati nel modulo
 *
 * @example return array('moodle/site:accessallgroups');
 * @return array
 */
function teacherassistant_get_extra_capabilities() {
    return array();
}

////////////////////////////////////////////////////////////////////////////////
// API Registro dei voti                                                          //
////////////////////////////////////////////////////////////////////////////////

/**
 * È una data scala utilizzata dall'istanza di teacherassistant?
 *
 * Questa funzione ritorna se una bilancia viene utilizzata da un insegnante
 * se ha il supporto per la classificazione e le scale. Il codice commentato dovrebbe essere
 * modificato se necessario. Vedi forum, glossario o moduli journal
 * come riferimento.
 *
 * @param int $teacherassistantid ID di un'istanza di questo modulo
 * @return bool vero se la scala viene utilizzata dall'istanza di teacherassistant  fornita
 */
function teacherassistant_scale_used($teacherassistantid, $scaleid) {
    global $DB;

    /** @example */
    if ($scaleid and $DB->record_exists(MOD_TEACHERASSISTANT_TABLE, array('id' => $teacherassistantid, 'grade' => -$scaleid))) {
        return true;
    } else {
        return false;
    }
}

/**
 * Verifica se la scala viene utilizzata da qualsiasi istanza di teacherassistant.
 *
 * Questo è usato per scoprire se la scala è usata ovunque.
 *
 * @param $scaleid int
 * @return boolean vero se la scala viene utilizzata da qualsiasi istanza di teacherassistant
 */
function teacherassistant_scale_used_anywhere($scaleid) {
    global $DB;

    /** @example */
    if ($scaleid and $DB->record_exists(MOD_TEACHERASSISTANT_TABLE, array('grade' => -$scaleid))) {
        return true;
    } else {
        return false;
    }
}



////////////////////////////////////////////////////////////////////////////////
// API file                                                               //
////////////////////////////////////////////////////////////////////////////////

/**
 * Restituisce gli elenchi di tutte le aree dei file sfogliabili nel contesto del modulo specificato
 *
 * L'area del file "introduzione" per il campo di introduzione dell'attività viene aggiunta automaticamente
 * di {@link file_browser::get_file_info_context_module()}
 *
 * @param stdClass $course
 * @param stdClass $cm
 * @param stdClass $context
 * @return array of [(string)filearea] => (string)description
 */
function teacherassistant_get_file_areas($course, $cm, $context) {
    return array();
}

/**
 * Supporto per la ricerca di file per aree di file di supporto degli teacherassistant
 *
 * @package mod_teacherassistant
 * @category files
 *
 * @param file_browser $browser
 * @param array $areas
 * @param stdClass $course
 * @param stdClass $cm
 * @param stdClass $context
 * @param string $filearea
 * @param int $itemid
 * @param string $filepath
 * @param string $filename
 * @return file_info istanza o null se non trovato
 */
function teacherassistant_get_file_info($browser, $areas, $course, $cm, $context, $filearea, $itemid, $filepath, $filename) {
    return null;
}

/**
 * Fornisce i file dalle aree dei file del teacherassistant
 *
 * @package mod_teacherassistant
 * @category files
 *
 * @param stdClass $course l'oggetto del corso
 * @param stdClass $cm l'oggetto del modulo del corso
 * @param stdClass $context il contesto del teacherassistant
 * @param string $filearea il nome dell'area del file
 * @param array $args argomenti extra (itemid, percorso)
 * @param bool $forcedownload forzare o meno il download
 * @param array $options opzioni aggiuntive che incidono sulla pubblicazione dei file
 */
function teacherassistant_pluginfile($course, $cm, $context, $filearea, array $args, $forcedownload, array $options=array()) {
    global $DB, $CFG;

    if ($context->contextlevel != CONTEXT_MODULE) {
        send_file_not_found();
    }

    require_login($course, true, $cm);

    send_file_not_found();
}

////////////////////////////////////////////////////////////////////////////////
// API di navigazione                                                       //
////////////////////////////////////////////////////////////////////////////////

/**
 * Estende l'albero di navigazione globale aggiungendo nodi di teacherassistant se è presente un contenuto pertinente
 *
 * Questo può essere chiamato da una richiesta AJAX, quindi non fare affidamento su $ PAGE in quanto potrebbe non essere impostato correttamente.
 *
 * @param navigation_node $navref Un oggetto che rappresenta il nodo dell'albero di navigazione dell'istanza del modulo teacherassistant
 * @param stdClass $course
 * @param stdClass $module
 * @param cm_info $cm
 */
function teacherassistant_extend_navigation(navigation_node $teacherassistantnode, stdclass $course, stdclass $module, cm_info $cm) {
}

/**
 * Estende la navigazione delle impostazioni con le impostazioni del teacherassistant
 *
 * Questa funzione viene chiamata quando il contesto per la pagina è un modulo di supporto insegnante. Questo non viene chiamato da AJAX
quindi è sicuro fare affidamento su $ PAGE.
 * quindi è sicuro fare affidamento su $PAGE.
 *
 * @param settings_navigation $settingsnav {@link settings_navigation}
 * @param navigation_node $teacherassistantnode {@link navigation_node}
 */
function teacherassistant_extend_settings_navigation(settings_navigation $settingsnav, navigation_node $teacherassistantnode=null) {
}
// Non ci sono tag di chiusura php in questo file,
// è intenzionale perché previene problemi di spazi vuoti finali!