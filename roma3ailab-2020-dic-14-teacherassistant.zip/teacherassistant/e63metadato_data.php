<?php
class metadato_data
{
private $metadatos_array = array(); //defined as an empty array initially
private $metadato_data_xml = "";

private $change_log_file = "change.log";
function __construct() {
	libxml_use_internal_errors(true);
	$xmlDoc = new DOMDocument(); 
	if ( file_exists("e61metadato_applications.xml") )
	{
	$xmlDoc->load( 'e61metadato_applications.xml' );
	$searchNode = $xmlDoc->getElementsByTagName( "type" ); 

		foreach( $searchNode as $searchNode ) 
		{ 
			$valueID = $searchNode->getAttribute('ID'); 
    
			if($valueID == "datastorage")
			{

				$xmlLocation = $searchNode->getElementsByTagName( "location" ); 
				$this->metadato_data_xml = $xmlLocation->item(0)->nodeValue;
				
				break;
			}

		}
	}
	else 
	{
		throw new Exception("metadato applications xml file missing or corrupt");
	}
	$xmlfile = file_get_contents($this->metadato_data_xml);
	$xmlstring = simplexml_load_string($xmlfile);
	
	if ($xmlstring === false) {
		$errorString = "Failed loading XML: ";
		foreach(libxml_get_errors() as $error) {
			$errorString .= $error->message . " " ;  }
		throw new Exception($errorString); }
	$json = json_encode($xmlstring);	
	$this->metadatos_array = json_decode($json,TRUE);
	
}

function __destruct()
{

	$xmlstring = '<?xml version="1.0" encoding="UTF-8"?>';
   	 $xmlstring .= "\n<metadatos>\n";
   	 foreach ($this->metadatos_array as $metadatos=>$metadatos_value) {
		foreach ($metadatos_value as $metadato => $metadato_value)
		{		
			$xmlstring .="<$metadatos>\n";
				foreach ($metadato_value as $column => $column_value)
				{
				$xmlstring .= "<$column>" . $metadato_value[$column] . "</$column>\n";
				}
			$xmlstring .= "</$metadatos>\n";
		}		
    } 
	$xmlstring .= "</metadatos>\n";
	
$new_valid_data_file = preg_replace('/[0-9]+/', '', $this->metadato_data_xml);
// remove the previous date and time if it exists
$oldxmldata = date('mdYhis') . $new_valid_data_file;
if (!rename($this->metadato_data_xml, $oldxmldata))
	{
	   throw new Exception("Backup file $oldxmldata could not be created.");
	}
file_put_contents($new_valid_data_file,$xmlstring);

}


private function deleteRecord($recordNumber) 
{
	foreach ($this->metadatos_array as $metadatos=>&$metadatos_value) {
		for($J=$recordNumber; $J < count($metadatos_value) -1; $J++) {
            				
			foreach ($metadatos_value[$J] as $column => $column_value)
			{
		
				$metadatos_value[$J][$column] = $metadatos_value[$J + 1][$column];
			}				
		
}
	unset ($metadatos_value[count($metadatos_value) -1]);
	}
	
	$change_string = date('mdYhis') . " | Delete | " . $recordNumber . "\n";
	$chge_log_file = date('mdYhis') . $this->change_log_file;
	error_log($change_string,3,$chge_log_file); // might exceed 120 chars
 }

private function readRecords($recordNumber) 
 {
	if($recordNumber === "ALL") {
		return $this->metadatos_array["metadato"];
	}
	else 
	{
		return $this->metadatos_array["metadato"][$recordNumber];
	} 
}

private function insertRecords($records_array)
{
	$metadatos_array_size = count($this->metadatos_array["metadato"]);

	for($I=0;$I< count($records_array);$I++)
	{
		$this->metadatos_array["metadato"][$metadatos_array_size + $I] = $records_array[$I];
	
	} 
	
	$change_string = date('mdYhis') . " | Insert | " . serialize($records_array) . "\n";
	$chge_log_file = date('mdYhis') . $this->change_log_file;
	error_log($change_string,3,$chge_log_file); // might exceed 120 chars

}

private function updateRecords($records_array)
{

$chge_string = "";
	foreach ($records_array as $records=>$records_value) 
	{
       
		
            $this->metadatos_array["metadato"][$records] = $records_array[$records];

	}

	$change_string = date('mdYhis') . " | Update | " . serialize($records_array) . "\n";
	$chge_log_file = date('mdYhis') . $this->change_log_file;
	error_log($change_string,3,$chge_log_file); // might exceed 120 chars


}
function setChangeLogFile($value)
{

	$this->metadato_data_xml = $value;
	
}
function processRecords($change_Type, $records_array)
{

switch($change_Type)
{
    
	case "Delete":
	   
		$this->deleteRecord($records_array);
		break;
	case "Insert":
		$this->insertRecords($records_array);
		break;
	case "Update":
		$this->updateRecords($records_array);
		break;
	case "Display":
		$this->readRecords($records_array);
		break;
	default:
		throw new Exception("Invalid XML file change type: $change_Type");
}

}
}
// Non ci sono tag di chiusura php in questo file,
// è intenzionale perché previene problemi di spazi vuoti finali!