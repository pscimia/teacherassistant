<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Definisce tutti i passaggi di backup che verranno utilizzati da {@link backup_teacherassistant_activity_task}
 *
 * @package     mod_teacherassistant
 * @category    backup
 * @copyright   2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/teacherassistant/lib.php');

/**
 * Definisce la struttura webquest completa per il backup, con annotazioni di file e ID
 *
 */
class backup_teacherassistant_activity_structure_step extends backup_activity_structure_step {

    /**
     * Definisce la struttura dell'elemento teacherassistant all'interno del file webquest.xml
     *
     * @return backup_nested_element
     */
    protected function define_structure() {

        //stiamo includendo userinfo?
        $userinfo = $this->get_setting_value('userinfo');

        ////////////////////////////////////////////////////////////////////////
        // Dichiarazione di nodi XML - dati non utente
        ////////////////////////////////////////////////////////////////////////

        // descrizione dell'elemento radice teacherassistant
        $oneactivity = new backup_nested_element(MOD_TEACHERASSISTANT_MODNAME, array('id'), array(
            'course','name','intro','introformat','someinstancesetting','grade','gradeoptions','maxattempts','mingrade',
            'timecreated','timemodified'
            ));
        
        //tentativi
        $attempts = new backup_nested_element('attempts');
        $attempt = new backup_nested_element('attempt', array('id'),array(
            MOD_TEACHERASSISTANT_MODNAME ."id","course","userid","status","sessionscore","timecreated","timemodified"
        ));

        
        // Costruisci l'albero.
        $oneactivity->add_child($attempts);
        $attempts->add_child($attempt);
        


        // Definisci le fonti.
        $oneactivity->set_source_table(MOD_TEACHERASSISTANT_TABLE, array('id' => backup::VAR_ACTIVITYID));

        //fonti di inclusione delle informazioni utente
        if ($userinfo) {
            $attempt->set_source_table(MOD_TEACHERASSISTANT_USERTABLE,
                                            array(MOD_TEACHERASSISTANT_MODNAME . 'id' => backup::VAR_PARENTID));
        }

        // Definire le annotazioni ID.
        $attempt->annotate_ids('user', 'userid');


        // Definire le annotazioni dei file.
        //          l'area del file di intro ha 0 itemid.
        $oneactivity->annotate_files(MOD_TEACHERASSISTANT_FRANKY, 'intro', null);

        // Restituisce l'elemento radice (scelta), racchiuso in una struttura di attività standard.
        return $this->prepare_activity_structure($oneactivity);
        

    }
}

