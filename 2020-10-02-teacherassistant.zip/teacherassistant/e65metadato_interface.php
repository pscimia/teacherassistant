<?php
const USER_ERROR_LOG = "../User_Errors.log";
const ERROR_LOG = "../Errors.log";
require 'config2.php';
//var_dump($config2);
$mysqli = new mysqli(
	$config2['mysql_host'],
	$config2['mysql_user'],
	$config2['mysql_password'],
	$config2['mysql_db']
);
global $DB;
$corso_id=1;
if($mysqli->connect_error){
	die($mysqli->connect_error);
}else{
	echo '';
	//var_dump($mysqli);
}
function clean_input($value)
{


	$value = htmlentities($value);
	// Removes any html from the string and turns it into &lt; format
	$value = strip_tags($value);


	if (get_magic_quotes_gpc())
	{
		$value = stripslashes($value);

		// Gets rid of unwanted slashes
	}
	$value = htmlentities($value);

	// Removes any html from the string and turns it into &lt; format

	$bad_chars = array( "{", "}", "(", ")", ";", ":", "<", ">", "/", "$" );
	$value = str_ireplace($bad_chars,"",$value);
	return $value;

}


class setException extends Exception {
	public function errorMessage() {

		list($prerequisiti_error,$conosc_acquisite_error,$learning_style_1_error,$learning_style_2_error,$learning_style_3_error,$learning_style_4_error) = explode(',', $this->getMessage());

		$prerequisiti_error == 'TRUE' ? $eMessage = '' : $eMessage = 'prerequisiti update not successful<br/>';
		$conosc_acquisite_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'conosc_acquisite update not successful<br/>';
		$learning_style_1_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Learning_style_1 update not successful<br/>';
		$learning_style_2_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Learning_style_2 update not successful<br/>';
		$learning_style_3_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Learning_style_3 update not successful<br/>';
		$learning_style_4_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Learning_style_4 update not successful<br/>';

		return $eMessage;
	}
}

function get_metadato_app_properties($lab)
{

	print "Il metadato prerequisiti : " . $lab->get_metadato_prerequisiti() . "<br />";
	print "Il metadato conoscenze acquisite : " . $lab->get_metadato_conosc_acquisite() . "<br />";
	print "Il metadato learning_style_1 : " . $lab->get_metadato_learning_style_1() . " . <br />";
	print "Il metadato learning_style_2 : " . $lab->get_metadato_learning_style_2() . " . <br />";
	print "Il metadato learning_style_3 : " . $lab->get_metadato_learning_style_3() . " . <br />";
	print "Il metadato learning_style_4 : " . $lab->get_metadato_learning_style_4() . " . <br />";

}
//----------------Main Section-------------------------------------
try {
	if ( file_exists("e65metadato_container.php"))
	{
		Require_once("e65metadato_container.php");
	}
	else
	{
		throw new Exception("metadato container file missing or corrupt");
	}

	if (isset($_POST['metadato_app']))
	{

		if ((isset($_POST['cors_identif'])) && (isset($_POST['cors_nom'])) && (isset($_POST['metadato_prerequisiti'])) && (isset($_POST['metadato_conosc_acquisite'])) && (isset($_POST['metadato_learning_style_1'])) && (isset($_POST['metadato_learning_style_2'])) && (isset($_POST['metadato_learning_style_3'])) && (isset($_POST['metadato_learning_style_4'])))
		{

			$container = new metadato_container(clean_input($_POST['metadato_app']));

			$cors_identif = clean_input($_POST['cors_identif']);
			$cors_nom = clean_input($_POST['cors_nom']);
			$metadato_prerequisiti = clean_input($_POST['metadato_prerequisiti']);
			$metadato_conosc_acquisite = clean_input($_POST['metadato_conosc_acquisite']);
			$metadato_learning_style_1 = clean_input($_POST['metadato_learning_style_1']);
			$metadato_learning_style_2 = clean_input($_POST['metadato_learning_style_2']);
			$metadato_learning_style_3 = clean_input($_POST['metadato_learning_style_3']);
			$metadato_learning_style_4 = clean_input($_POST['metadato_learning_style_4']);
			$sql = 'INSERT INTO mdl_teacherassistant_save_datai(cors_identif,cors_nom,metadato_prerequisiti,metadato_conosc_acquisite,metadato_learning_style_1,metadato_learning_style_2,metadato_learning_style_3,metadato_learning_style_4) VALUES';
			$sql .= "($cors_identif,'$cors_nom','$metadato_prerequisiti','$metadato_conosc_acquisite',$metadato_learning_style_1,$metadato_learning_style_2,$metadato_learning_style_3,$metadato_learning_style_4);";
			//echo '<br>'.$sql.'<br>';
			echo '<br>';
			$res=$mysqli->query($sql);
			if(!$res){
				echo $mysqli->error.'<br>';
			}else{
				echo 'riga save_data inserita';
			}

			$prerequisitixml = $container->get_metadato_application("prerequisitis");

			$properties_array = array($metadato_prerequisiti,$metadato_conosc_acquisite,$metadato_learning_style_1,$metadato_learning_style_2,$metadato_learning_style_3,$metadato_learning_style_4,$prerequisitixml);
			$lab = $container->create_object($properties_array);

			print "Updates successful<br />";
			get_metadato_app_properties($lab);
		}

		else
		{

			print "<p>Missing or invalid parameters. Please go back to the metadato.html page to enter valid information.<br />";

			print "<a href='e65lab.html'>metadato Creation Page</a>";

		}
	}
	else // select box
	{

		$container = new metadato_container("selectbox");

		$properties_array = array("selectbox");

		$lab = $container->create_object($properties_array);
		$container->set_app("prerequisitis");
		$metadato_app = $container->get_metadato_application("prerequisitis");
		$method_array = get_class_methods($lab);
		$last_position = count($method_array) - 1;
		$method_name = $method_array[$last_position];
		$result = $lab->$method_name($metadato_app);

		print $result;
	}
}
catch(setException $e)
{
	echo $e->errorMessage(); // displays to the user

	$date = date('m.d.Y h:i:s');
	$errormessage = $e->errorMessage();
	$eMessage =  $date . " | User Error | " . $errormessage . "\n";
	error_log($eMessage,3,USER_ERROR_LOG); // writes message to user error log file

}
catch(Exception $e)
{

	echo "The system is currently unavailable. Please try again later."; // displays message to the user

	$date = date('m.d.Y h:i:s');
	$eMessage =  $date . " | System Error | " . $e->getMessage() . " | " . $e->getFile() . " | ". $e->getLine() . "\n";
	error_log($eMessage,3,ERROR_LOG); // writes message to error log file

	error_log("Date/Time: $date - Serious System Problems with metadato Application. Check error log for details", 1, "p.scimia@gmail.com", "Subject: metadato Application Error \nFrom: System Log <systemlog@helpme.com>". "\r\n");
	// e-mails personnel to alert them of a system problem

}
?>
