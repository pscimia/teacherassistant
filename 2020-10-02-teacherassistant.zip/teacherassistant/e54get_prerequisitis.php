<?php

class  GetPrerequisitis {

function __construct($properties_array)
{
if (!(method_exists('metadato_container', 'create_object')))
{
exit;
}
}

     private $result = "??";
public function get_select($metadato_app)
{
     
	 
	 if (($metadato_app != FALSE) && ( file_exists($metadato_app)))
	 {
     $prerequisiti_file = simplexml_load_file($metadato_app);

     $xmlText = $prerequisiti_file->asXML();
	
     $this->result = "<select name='metadato_prerequisiti' id='metadato_prerequisiti' multiple>";
	 
     $this->result = $this->result . "<option value='-1' selected>Seleziona un prerequisito</option>";
     
    foreach ($prerequisiti_file->children() as $name => $value)
    {
      $this->result = $this->result . "<option value='$value'>$value</option>";
    }
      $this->result = $this->result . "</select>";
	  
	  return $this->result;
    }
	else
	{
	  throw new Exception("prerequisiti xml file missing or corrupt");
	 // return FALSE;
    }
  

}
}
?>
