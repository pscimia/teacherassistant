<?php
// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Stampa un'istanza particolare di insegnante
 *
 * Puoi anche avere una descrizione più lunga del file,
 * se vuoi, e può estendersi su più righe.
 *
 * @package    mod_teacherassistant
 * @copyright  COPYRIGHTNOTICE
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require('../../config.php');
global $DB, $CFG, $USERS, $USER, $PAGE, $COURSE, $GLOBALS, $SECTION;

//moodleform è definito in formslib.php
require_once("$CFG->libdir/formslib.php");

require_once("$CFG->dirroot/mod/teacherassistant/lib.php");

require_once($CFG->dirroot.'/course/moodleform_mod.php');
//È necessario aggiungere quanto segue a tutti i file che accedono alle funzioni profilo_:
require_once("$CFG->dirroot/user/profile/lib.php");
require_once 'e65metadato.php';

require_once 'config2.php';
//var_dump($config2);
$mysqli = new mysqli(
    $config2['mysql_host'],
    $config2['mysql_user'],
    $config2['mysql_password'],
    $config2['mysql_db']
);
if($mysqli->connect_error){
    die($mysqli->connect_error);
}else{
    echo 'connessione riuscita';
    //var_dump($mysqli);
}
$sql1= 'CREATE TABLE if not exists mdl_teacherassistant_save_datai (';
$sql1 .= 'id BIGINT(10) NOT NULL auto_increment,';
$sql1 .= 'cors_identif BIGINT(10) NOT NULL,';
$sql1 .= 'cors_nom VARCHAR(128) COLLATE utf8mb4_unicode_ci,';
$sql1 .= 'metadato_prerequisiti VARCHAR(128) COLLATE utf8mb4_unicode_ci,';
$sql1 .= 'metadato_conosc_acquisite VARCHAR(128) COLLATE utf8mb4_unicode_ci,';
$sql1 .= 'metadato_learning_style_1 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_learning_style_2 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_learning_style_3 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_learning_style_4 NUMERIC(2) NOT NULL,';
$sql1 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql1 .= ')';
$sql1 .= 'ENGINE = InnoDB ';
$sql1 .= 'DEFAULT COLLATE = utf8mb4_unicode_ci ROW_FORMAT=Compressed;';
//echo '<br>'.$sql1.'<br>';
$res=$mysqli->query($sql1);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '1';
}
$id = optional_param('id', 0, PARAM_INT); // course_module ID, or

//echo '$id optional param';
//var_dump($id);
$n  = optional_param('n', 0, PARAM_INT);  // teacherassistant ID istanza: dovrebbe essere nominato come primo carattere del modulo

if ($id) {
    $cm         = get_coursemodule_from_id('teacherassistant', $id, 0, false, MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $moduleinstance  = $DB->get_record('teacherassistant', array('id' => $cm->instance), '*', MUST_EXIST);
} elseif ($n) {
    $moduleinstance  = $DB->get_record('teacherassistant', array('id' => $n), '*', MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $moduleinstance->course), '*', MUST_EXIST);
    $cm         = get_coursemodule_from_instance('teacherassistant', $moduleinstance->id, $course->id, false, MUST_EXIST);
} else {
    print_error(get_string('missingidandcmid',MOD_TEACHERASSISTANT_LANG));
}

$cors_nom=$GLOBALS[course]->fullname;
echo '<br>'.'course= ';
var_dump($cors_nom);
$cors_identif=$GLOBALS[course]->id;
echo '<br>'.'id_course= ';
var_dump($cors_identif);
echo '<br>';
$sql5 = 'CREATE TABLE if not exists mdl_teacherassistant_informa (';
$sql5 .= 'id BIGINT(10) NOT NULL auto_increment,';
$sql5 .= 'cors_identif BIGINT(10) NOT NULL,';
$sql5 .= 'cors_nom VARCHAR(128) COLLATE utf8mb4_unicode_ci,';
$sql5 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql5 .= ')';
$sql5 .= 'ENGINE = InnoDB ';
$sql5 .= 'DEFAULT COLLATE = utf8mb4_unicode_ci ROW_FORMAT=Compressed;';
//echo '<br>'.$sql5.'<br>';
$res=$mysqli->query($sql5);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    //echo 'table info creata';
    echo '5';
}
$sql6 = 'INSERT INTO mdl_teacherassistant_informa(cors_identif,cors_nom) VALUES';
$sql6 .= "($cors_identif,'$cors_nom');";
//echo '<br>'.$sql6.'<br>';
$res=$mysqli->query($sql6);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    //echo 'insert informa';
    echo '6';
}

$PAGE->set_url('/mod/teacherassistant/view.php', array('id' => $cm->id));
require_login($course, true, $cm);
$modulecontext = context_module::instance($cm->id);

//Deviare la logica di registrazione a Moodle 2.7
if($CFG->version<2014051200){
    add_to_log($course->id, 'teacherassistant', 'view', "view.php?id={$cm->id}", $moduleinstance->name, $cm->id);
}else{
    // Evento visualizzato modulo trigger..
    $event = \mod_teacherassistant\event\course_module_viewed::create(array(
        'objectid' => $moduleinstance->id,
        'context' => $modulecontext
    ));
    $event->add_record_snapshot('course_modules', $cm);
    $event->add_record_snapshot('course', $course);
    $event->add_record_snapshot('teacherassistant', $moduleinstance);
    $event->trigger();
}

// se siamo arrivati così lontano, possiamo considerare l'attività "vista"
$completion = new completion_info($course);
$completion->set_module_viewed($cm);

//siamo un insegnante o uno studente?
$mode= "view";

// Imposta l'intestazione della pagina
$PAGE->set_title(format_string($moduleinstance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($modulecontext);
$PAGE->set_pagelayout('course');

//Ottieni le impostazioni di amministrazione
$config = get_config(MOD_TEACHERASSISTANT_FRANKY);
$someadminsetting = $config->someadminsetting;

//Ottieni un'impostazione dell'istanza
$someinstancesetting = $moduleinstance->someinstancesetting;


// Prepara il nostro JavaScript pronto per partire
// Possiamo omettere il modulo $ js, ma è bello averlo qui,
// se per esempio dobbiamo includere alcune cose YUI funky
$jsmodule = array(
    'name'     => 'mod_teacherassistant',
    'fullpath' => '/mod/teacherassistant/module.js',
    'requires' => array()
);
//qui impostiamo tutte le informazioni necessarie per passare a JavaScript
$opts =Array();
$opts['someinstancesetting'] = $someinstancesetting;


//questo entra nel M.mod_teacherassistant cosa, dopo che la pagina è stata caricata.
$PAGE->requires->js_init_call('M.mod_teacherassistant.helper.init', array($opts),false,$jsmodule);

//questo carica tutte le librerie JS esterne che dobbiamo chiamare
//$PAGE->requires->js("/mod/teacherassistant/js/somejs.js");
//$PAGE->requires->js(new moodle_url('http://www.somewhere.com/some.js'),true);

//Questo mette tutta la nostra logica di visualizzazione nel file renderer.php in questo plugin
//gli sviluppatori di temi possono sovrascrivere le classi lì, quindi lo rendono personalizzabile per gli altri
//per farlo in questo modo.
$renderer = $PAGE->get_renderer('mod_teacherassistant');

//Da qui visualizziamo effettivamente la pagina.
// questa è roba di rendering di base


//se siamo insegnanti vediamo le schede. Se studente vediamo solo il quiz
if(has_capability('mod/teacherassistant:preview',$modulecontext)){
    echo $renderer->header($moduleinstance, $cm, $mode, null, get_string('view', MOD_TEACHERASSISTANT_LANG));
}else{
    echo $renderer->notabsheader();
}

echo $renderer->show_intro($moduleinstance,$cm);

?>
    <html lan="it">
    <head>
        <title>Teacherassistant</title>
        <script src="e5get_prerequisitis.js"></script>
        <script src="e5validator.js"></script>
        <style type="text/css">

            #JS { display:none; }

        </style>

        <script>
            function checkJS() {

                document.getElementById('JS').style.display = "inline";

            }
        </script>

    </head>

<body onload="checkJS();">

<h1>Teacherassistant</h1>

<div id="JS">
    <form method="post" action="e65metadato_interface.php" onSubmit="return validate_input(this)">
<br /><b>Mappa didattica</b><br />
mostra la mappa didattica del corso
        <br /><br /><br /><b>Prerequisiti</b><br />
        <p>
            Seleziona uno o piu' prerequisiti: <div id="AjaxResponse"></div><br />
        </p>
<br /><b>Conoscenze acquisite</b>
        <br />Scegli una conoscenza acquisita presente:<br />
        <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="rome_in_the_neorealism">rome_in_the_neorealism<br />
        <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="rossellini">rossellini<br />
        <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="war">war<br />
        <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="roma_citta_aperta">roma_citta_aperta<br />
        <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="paisa" checked >paisa<br /><br />

        <br /><br /><b>Learning styles</b><br />
        attivo-riflessivo  <input type="number" min="-11" max="11" name="metadato_learning_style_1" id="metadato_learning_style_1" required /><br />
        rilevamento-intuitivo  <input type="number" min="-11" max="11" name="metadato_learning_style_2" id="metadato_learning_style_2" required /><br />
        visivo-verbale  <input type="number" min="-11" max="11" name="metadato_learning_style_3" id="metadato_learning_style_3" required /><br />
        sequenziale-globale  <input type="number" min="-11" max="11" name="metadato_learning_style_4" id="metadato_learning_style_4" required /><br /><br />
        <br /><br />
        <input type="hidden" name="metadato_app" id="metadato_app" value="metadato" /><br />
        <input type="hidden" name="cors_identif" id="cors_identif" value="<?=$cors_identif?>" /><br />
        <input type="hidden" name="cors_nom" id="cors_nom" value="<?=$cors_nom?>" /><br />
        <script>
            AjaxRequest('e65metadato_interface.php');
        </script>
        <input type="submit" value="Salva il metadato" />
    </form>
</div>

<noscript>
    <div id="noJS">
        <form method="post" action="e65metadato_interface.php">
            <h2>Please complete ALL fields. Please note the required format of information.</h2>
            Enter Your Metadato's Name (max 20 characters, alphabetic) <input type="text" pattern="[a-zA-Z ]*"  title="Up to 20 Alphabetic Characters" maxlength="20" name="metadato_name" id="metadato_name" required/><br /><br />
            <br /><b>Prerequisiti</b><br />
            <p>
                paisa <input type="checkbox" id="metadato_ckbox" name="metadato_ckbox" value="paisa"><br />
            </p>
            <br /><b>Conoscenze acquisite</b><br />
            <br />Scegli una conoscenza acquisita presente:<br />
            <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="rome_in_the_neorealism">rome_in_the_neorealism<br />
            <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="rossellini">rossellini<br />
            <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="war">war<br />
            <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="roma_citta_aperta">roma_citta_aperta<br />
            <input type="radio" name="metadato_conosc_acquisite" id="metadato_conosc_acquisite" value="paisa" checked >paisa<br /><br />
            <b>Learning styles</b><br /><br />
            attivo-riflessivo  <input type="number" min="-11" max="11" name="metadato_learning_style_1" id="metadato_learning_style_1" required /><br />
            rilevamento-intuitivo  <input type="number" min="-11" max="11" name="metadato_learning_style_2" id="metadato_learning_style_2" required /><br />
            visivo-verbale  <input type="number" min="-11" max="11" name="metadato_learning_style_3" id="metadato_learning_style_3" required /><br />
            sequenziale-globale  <input type="number" min="-11" max="11" name="metadato_learning_style_4" id="metadato_learning_style_4" required /><br /><br />
            <br /><br />
            <input type="hidden" name="metadato_app" id="metadato_app" value="metadato" />
            <input type="hidden" name="cors_identif" id="cors_identif" value="<?=$cors_identif?>" /><br />
            <input type="hidden" name="cors_nom" id="cors_nom" value="<?=$cors_nom?>" /><br />
            <input type="submit" value="Salva il metadato" />
        </form>
    </div>
</noscript>    
<?php

//se abbiamo troppi tentativi, segnaliamolo.
if($moduleinstance->maxattempts > 0){
    $attempts =  $DB->get_records(MOD_TEACHERASSISTANT_USERTABLE,array('userid'=>$USER->id, MOD_TEACHERASSISTANT_MODNAME.'id'=>$moduleinstance->id));
    if($attempts && count($attempts)<$moduleinstance->maxattempts){
        echo get_string("exceededattempts",MOD_TEACHERASSISTANT_LANG,$moduleinstance->maxattempts);
    }
}

//Questo è specifico per il nostro renderer
//echo $renderer->show_something($someadminsetting);
//echo $renderer->show_something($someinstancesetting);

// Termina la pagina
echo $renderer->footer();

?>