<?php
class Metadato
{
// ----------------------------------------- Properties -----------------------------------------
private $metadato_prerequisiti = "no prerequisiti";
private $metadato_conosc_acquisite = "no conosc_acquisite";
private $metadato_learning_style_1 = 0;
private $metadato_learning_style_2 = 0;
private $metadato_learning_style_3 = 0;
private $metadato_learning_style_4 = 0;
private $error_message = "??";
private $prerequisitixml = "";
// ---------------------------------- Constructor ----------------------------------------------
function __construct($properties_array)
{
if (method_exists('metadato_container', 'create_object')) {
$this->prerequisitixml = $properties_array[6];

$prerequisiti_error = $this->set_metadato_prerequisiti($properties_array[0]) == TRUE ? 'TRUE,' : 'FALSE,';
$conosc_acquisite_error = $this->set_metadato_conosc_acquisite($properties_array[1]) == TRUE ? 'TRUE,' : 'FALSE,';
$learning_style_1_error= $this->set_metadato_learning_style_1($properties_array[2]) == TRUE ? 'TRUE' : 'FALSE';
$learning_style_2_error= $this->set_metadato_learning_style_2($properties_array[3]) == TRUE ? 'TRUE' : 'FALSE';
$learning_style_3_error= $this->set_metadato_learning_style_3($properties_array[4]) == TRUE ? 'TRUE' : 'FALSE';
$learning_style_4_error= $this->set_metadato_learning_style_4($properties_array[5]) == TRUE ? 'TRUE' : 'FALSE';


$this->error_message = $prerequisiti_error . $conosc_acquisite_error . $learning_style_1_error . $learning_style_2_error . $learning_style_3_error . $learning_style_4_error;
$this->save_metadato_data();
if(stristr($this->error_message, 'FALSE'))
{
	throw new setException($this->error_message);
}
}
else
{
exit;
}
}
function clean_input() { }
private function save_metadato_data()
{
if ( file_exists("e65metadato_container.php")) {
		require_once("e65metadato_container.php"); // use chapter 5 container w exception handling
	} else {
		throw new Exception("metadato container file missing or corrupt");
	}
	
	$container = new metadato_container("metadatodata"); // sets the tag name to look for in XML file
	$properties_array = array("metadatodata"); // not used but must be passed into create_object
	$metadato_data = $container->create_object($properties_array); // creates metadato_data object
	$method_array = get_class_methods($metadato_data);
	$last_position = count($method_array) - 1;
	$method_name = $method_array[$last_position]; 
	$record_Array = array(array('metadato_prerequisiti'=>"$this->metadato_prerequisiti", 'metadato_conosc_acquisite'=>"$this->metadato_conosc_acquisite", 'metadato_learning_style_1'=>"$this->metadato_learning_style_1", 'metadato_learning_style_2'=>"$this->metadato_learning_style_2", 'metadato_learning_style_3'=>"$this->metadato_learning_style_3", 'metadato_learning_style_4'=>"$this->metadato_learning_style_4"));
	$metadato_data->$method_name("Insert",$record_Array);
	$metadato_data = NULL;
	
}
function set_metadato_prerequisiti($value)
{
$error_message = TRUE;
($this->validator_prerequisiti($value) === TRUE) ? $this->metadato_prerequisiti = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_conosc_acquisite($value)
{
$error_message = TRUE;
(ctype_alpha($value) && strlen($value) <= 60) ? $this->metadato_conosc_acquisite = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_learning_style_1($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > -12 && $value <= 11)) ? $this->metadato_learning_style_1 = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_learning_style_2($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > -12 && $value <= 11)) ? $this->metadato_learning_style_2 = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_learning_style_3($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > -12 && $value <= 11)) ? $this->metadato_learning_style_3 = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_learning_style_4($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > -12 && $value <= 11)) ? $this->metadato_learning_style_4 = $value : $this->error_message = FALSE;
return $this->error_message;
}
// ----------------------------------------- Get Methods ------------------------------------------------------------
function get_metadato_prerequisiti()
{
return $this->metadato_prerequisiti;
}
function get_metadato_conosc_acquisite()
{
return $this->metadato_conosc_acquisite;
}
function get_metadato_learning_style_1()
{
return $this->metadato_learning_style_1;
}
function get_metadato_learning_style_2()
{
return $this->metadato_learning_style_2;
}
function get_metadato_learning_style_3()
{
return $this->metadato_learning_style_3;
}
function get_metadato_learning_style_4()
{
return $this->metadato_learning_style_4;
}
function get_properties()
{
return "$this->metadato_prerequisiti,$this->metadato_conosc_acquisite,$this->metadato_learning_style_1,$this->metadato_learning_style_2,$this->metadato_learning_style_3,$this->metadato_learning_style_4.";
}
// ----------------------------------General Method---------------------------------------------

private function validator_prerequisiti($value)
{

$prerequisiti_file = simplexml_load_file($this->prerequisitixml);
$xmlText = $prerequisiti_file->asXML();

if(stristr($xmlText, $value) === FALSE)
{
return FALSE;
}
else
{
return TRUE;
}
}

}
?>