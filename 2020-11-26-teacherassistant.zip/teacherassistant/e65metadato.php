<?php
class Metadato
{
// ----------------------------------------- Properties -----------------------------------------
private $metadato_cors_identif = 0;
private $metadato_cors_nom = "no cors_nom";
private $metadato_cors_sect_identif = 0;
private $metadato_cors_sect_nom = "no cors_sect_nom";
private $metadato_prerequisiti = "no prerequi";
private $metadato_conosc_acquisite = "no conosc_acquisite";
private $metadato_name = "no name";
private $metadato_learning_style_1 = 0;
private $metadato_learning_style_2 = 0;
private $metadato_learning_style_3 = 0;
private $metadato_learning_style_4 = 0;
private $metadato_tem_conc = 0;
private $error_message = "??";
// ---------------------------------- Constructor ----------------------------------------------
function __construct($properties_array)
{
if (method_exists('metadato_container', 'create_object')) {

$cors_identif_error = $this->set_metadato_cors_identif($properties_array[0]) == TRUE ? 'TRUE,' : 'FALSE,';
$cors_nom_error = $this->set_metadato_cors_nom($properties_array[1]) == TRUE ? 'TRUE,' : 'FALSE,';
$cors_sect_identif_error = $this->set_metadato_cors_sect_identif($properties_array[2]) == TRUE ? 'TRUE,' : 'FALSE,';
$cors_sect_nom_error = $this->set_metadato_cors_sect_nom($properties_array[3]) == TRUE ? 'TRUE,' : 'FALSE,';
$prerequisiti_error = $this->set_metadato_prerequisiti($properties_array[4]) == TRUE ? 'TRUE,' : 'FALSE,';
$conosc_acquisite_error = $this->set_metadato_conosc_acquisite($properties_array[5]) == TRUE ? 'TRUE,' : 'FALSE,';
$name_error = $this->set_metadato_name($properties_array[6]) == TRUE ? 'TRUE,' : 'FALSE,';
$learning_style_1_error = $this->set_metadato_learning_style_1($properties_array[7]) == TRUE ? 'TRUE' : 'FALSE';
$learning_style_2_error = $this->set_metadato_learning_style_2($properties_array[8]) == TRUE ? 'TRUE' : 'FALSE';
$learning_style_3_error = $this->set_metadato_learning_style_3($properties_array[9]) == TRUE ? 'TRUE' : 'FALSE';
$learning_style_4_error = $this->set_metadato_learning_style_4($properties_array[10]) == TRUE ? 'TRUE' : 'FALSE';
$tem_conc_error = $this->set_metadato_tem_conc($properties_array[11]) == TRUE ? 'TRUE' : 'FALSE';


$this->error_message = $cors_identif_error . $cors_nom_error . $cors_sect_identif_error . $cors_sect_nom_error . $prerequisiti_error . $conosc_acquisite_error . $name_error . $learning_style_1_error . $learning_style_2_error . $learning_style_3_error . $learning_style_4_error . $tem_conc_error;
$this->save_metadato_data();
if(stristr($this->error_message, 'FALSE'))
{
	throw new setException($this->error_message);
}
}
else
{
exit;
}
}
function clean_input() { }
private function save_metadato_data()
{
if ( file_exists("e65metadato_container.php")) {
		require_once("e65metadato_container.php"); // use chapter 5 container w exception handling
	} else {
		throw new Exception("metadato container file missing or corrupt");
	}
	
	$container = new metadato_container("metadatodata"); // sets the tag name to look for in XML file
	$properties_array = array("metadatodata"); // not used but must be passed into create_object
	$metadato_data = $container->create_object($properties_array); // creates metadato_data object
	$method_array = get_class_methods($metadato_data);
	$last_position = count($method_array) - 1;
	$method_name = $method_array[$last_position]; 
	$record_Array = array(array('metadato_cors_identif'=>"$this->metadato_cors_identif",'metadato_cors_nom'=>"$this->metadato_cors_nom",'metadato_cors_sect_identif'=>"$this->metadato_cors_sect_identif",'metadato_cors_sect_nom'=>"$this->metadato_cors_sect_nom",'metadato_prerequisiti'=>"$this->metadato_prerequisiti", 'metadato_conosc_acquisite'=>"$this->metadato_conosc_acquisite", 'metadato_name'=>"$this->metadato_name", 'metadato_learning_style_1'=>"$this->metadato_learning_style_1", 'metadato_learning_style_2'=>"$this->metadato_learning_style_2", 'metadato_learning_style_3'=>"$this->metadato_learning_style_3", 'metadato_learning_style_4'=>"$this->metadato_learning_style_4", 'metadato_tem_conc'=>"$this->metadato_tem_conc"));
	$metadato_data->$method_name("Insert",$record_Array);
	$metadato_data = NULL;
	
}
function set_metadato_cors_identif($value)
{
$error_message = FALSE;
$this->metadato_cors_identif = $value;
return $this->error_message;
}
function set_metadato_cors_nom($value)
{
$error_message = FALSE;
$this->metadato_cors_nom = $value;
return $this->error_message;
}
function set_metadato_cors_sect_identif($value)
{
$error_message = FALSE;
$this->metadato_cors_sect_identif = $value;
return $this->error_message;
}
function set_metadato_cors_sect_nom($value)
{
$error_message = FALSE;
$this->metadato_cors_sect_nom = $value;
return $this->error_message;
}
function set_metadato_prerequisiti($value)
{
$error_message = FALSE;
$this->metadato_prerequisiti = $value;
return $this->error_message;
}
function set_metadato_conosc_acquisite($value)
{
$error_message = FALSE;
$this->metadato_conosc_acquisite = $value;
return $this->error_message;
}
function set_metadato_name($value)
{
$error_message = FALSE;
$this->metadato_name = $value;
return $this->error_message;
}
function set_metadato_learning_style_1($value)
{
$error_message = FALSE;
$this->metadato_learning_style_1 = $value;
return $this->error_message;
}
function set_metadato_learning_style_2($value)
{
$error_message = FALSE;
$this->metadato_learning_style_2 = $value;
return $this->error_message;
}
function set_metadato_learning_style_3($value)
{
$error_message = FALSE;
$this->metadato_learning_style_3 = $value;
return $this->error_message;
}
function set_metadato_learning_style_4($value)
{
$error_message = FALSE;
$this->metadato_learning_style_4 = $value;
return $this->error_message;
}
function set_metadato_tem_conc($value)
{
$error_message = FALSE;
$this->metadato_tem_conc = $value;
return $this->error_message;
}
// ----------------------------------------- Get Methods ------------------------------------------------------------
function get_metadato_cors_identif()
{
return $this->metadato_cors_identif;
}
function get_metadato_cors_nom()
{
return $this->metadato_cors_nom;
}
function get_metadato_cors_sect_identif()
{
return $this->metadato_cors_sect_identif;
}
function get_metadato_cors_sect_nom()
{
return $this->metadato_cors_sect_nom;
}
function get_metadato_prerequisiti()
{
return $this->metadato_prerequisiti;
}
function get_metadato_conosc_acquisite()
{
return $this->metadato_conosc_acquisite;
}
function get_metadato_name()
{
return $this->metadato_name;
}
function get_metadato_learning_style_1()
{
return $this->metadato_learning_style_1;
}
function get_metadato_learning_style_2()
{
return $this->metadato_learning_style_2;
}
function get_metadato_learning_style_3()
{
return $this->metadato_learning_style_3;
}
function get_metadato_learning_style_4()
{
return $this->metadato_learning_style_4;
}
function get_metadato_tem_conc()
{
return $this->metadato_tem_conc;
}
function get_properties()
{
return "$this->metadato_cors_identif,$this->metadato_cors_nom,$this->metadato_cors_sect_identif,$this->metadato_cors_sect_nom,$this->metadato_prerequisiti,$this->metadato_conosc_acquisite,$this->metadato_name,$this->metadato_learning_style_1,$this->metadato_learning_style_2,$this->metadato_learning_style_3,$this->metadato_learning_style_4,$this->metadato_tem_conc.";
}
// ----------------------------------General Method---------------------------------------------

}
?>