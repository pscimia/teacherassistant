<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * @package   mod_teacherassistant
 * @copyright 2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/teacherassistant/backup/moodle2/restore_teacherassistant_stepslib.php'); // Perché esiste (deve)

/**
 * attività di ripristino teacherassistant che fornisce tutte le impostazioni e i passaggi per eseguirne una
 * ripristino completo dell'attività
 */
class restore_teacherassistant_activity_task extends restore_activity_task {

    /**
     * Definire (aggiungere) impostazioni particolari che questa attività può avere
     */
    protected function define_my_settings() {
        // Nessuna impostazione particolare per questa attività
    }

    /**
     * Definire (aggiungere) passaggi particolari che questa attività può avere
     */
    protected function define_my_steps() {
        // La scelta ha solo un passaggio di struttura
        $this->add_step(new restore_teacherassistant_activity_structure_step('teacherassistant_structure', 'teacherassistant.xml'));
    }

    /**
     * Definire i contenuti nell'attività che deve essere
     * elaborato dal decodificatore del collegamento
     */
    static public function define_decode_contents() {
        $contents = array();

        $contents[] = new restore_decode_content(MOD_TEACHERASSISTANT_MODNAME,
                          array('intro'), MOD_TEACHERASSISTANT_MODNAME);

        return $contents;
    }

    /**
     * Definire le regole di decodifica per i collegamenti appartenenti
     * all'attività che deve essere eseguita dal decodificatore del collegamento
     */
    static public function define_decode_rules() {
        $rules = array();

        $rules[] = new restore_decode_rule('TEACHERASSISTANTVIEWBYID', '/mod/teacherassistant/view.php?id=$1', 'course_module');
        $rules[] = new restore_decode_rule('TEACHERASSISTANTINDEX', '/mod/teacherassistant/index.php?id=$1', 'course');

        return $rules;

    }

    /**
     * Definire le regole del registro di ripristino che verranno applicate
     * dal {@link restore_logs_processor} durante il ripristino
     * registri inglesi. Deve restituire un array
     * di {@link restore_log_rule} oggetti
     */
    static public function define_restore_log_rules() {
        $rules = array();

        $rules[] = new restore_log_rule(MOD_TEACHERASSISTANT_MODNAME, 'add', 'view.php?id={course_module}', '{'. MOD_TEACHERASSISTANT_TABLE .'}');
        $rules[] = new restore_log_rule(MOD_TEACHERASSISTANT_MODNAME, 'update', 'view.php?id={course_module}', '{'. MOD_TEACHERASSISTANT_TABLE .'}');
        $rules[] = new restore_log_rule(MOD_TEACHERASSISTANT_MODNAME, 'view', 'view.php?id={course_module}', '{'. MOD_TEACHERASSISTANT_TABLE .'}');

        return $rules;
    }

    /**
     * Definire le regole del registro di ripristino che verranno applicate
     * dal {@link restore_logs_processor} durante il ripristino
     * registri del corso. Deve restituire un array
     * di {@link restore_log_rule} oggetti
     *
     * Nota che queste regole vengono applicate durante il ripristino dei registri del corso
     * dall'attività finale di ripristino, ma sono definiti qui in
     * livello di attività. Tutte sono regole non collegate a nessuna istanza del modulo (cmid = 0)
     */
    static public function define_restore_log_rules_for_course() {
        $rules = array();

        $rules[] = new restore_log_rule(MOD_TEACHERASSISTANT_MODNAME, 'view all', 'index.php?id={course}', null);

        return $rules;
    }
}

