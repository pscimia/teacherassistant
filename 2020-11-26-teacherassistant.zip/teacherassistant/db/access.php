<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Definizioni di capacità per il modulo di teacherassistant
 *
 * Le capacità vengono caricate nella tabella del database quando il modulo è
 * installato o aggiornato. Ogni volta che le definizioni di capacità vengono aggiornate,
 * il numero di versione del modulo dovrebbe essere aumentato.
 *
 * Il sistema ha quattro possibili valori per una capacità:
 * CAP_ALLOW, CAP_PREVENT, CAP_PROHIBIT ed eredita (non impostato).
 *
 * È importante che i nomi delle funzionalità siano univoci. La convenzione di denominazione
 * per le funzionalità specifiche di moduli e blocchi è il seguente:
 *   [Mod / blocco] / <PLUGIN_NAME>: <capabilityname>
 *
 * nome_componente dovrebbe essere uguale al nome della directory della mod o del blocco.
 *
 * Le capacità di core moodle sono così definite:
 *    moodle/<capabilityclass>:<capabilityname>
 *
 * Esempi: mod/forum:viewpost
 *           block/recent_activity:view
 *           moodle/site:deleteuser
 *
 * Il nome della variabile per l'array delle definizioni delle funzionalità è $capabilities
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$capabilities = array(

        'mod/teacherassistant:myaddinstance' => array(
            'captype' => 'write',
            'contextlevel' => CONTEXT_SYSTEM,
            'archetypes' => array(
                'user' => CAP_ALLOW
            ),

            'clonepermissionsfrom' => 'moodle/my:manageblocks'
        ),

    'mod/teacherassistant:addinstance' => array(
            'riskbitmask' => RISK_SPAM | RISK_XSS,
            'captype' => 'write',
            'contextlevel' => CONTEXT_COURSE,
            'archetypes' => array(
                    'editingteacher' => CAP_ALLOW,
                    'manager' => CAP_ALLOW
            ),
            'clonepermissionsfrom' => 'moodle/course:manageactivities'
    ),

    'mod/teacherassistant:accessquerypractice' => array(
        'riskbitmask'  => RISK_CONFIG | RISK_DATALOSS,
        'captype'      => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => array(
            'admin'    => CAP_ALLOW
        ),
    ),
    
    'mod/teacherassistant:manage' => array(
            'riskbitmask' => RISK_XSS,
            'captype' => 'write',
            'contextlevel' => CONTEXT_COURSE,
            'archetypes' => array(
                    'editingteacher' => CAP_ALLOW,
                    'manager' => CAP_ALLOW
            ),
            'clonepermissionsfrom' => 'moodle/course:manageactivities'
    ),
    
    'mod/teacherassistant:itemedit' => array(
            'riskbitmask' => RISK_XSS,
            'captype' => 'write',
            'contextlevel' => CONTEXT_COURSE,
            'archetypes' => array(
                    'editingteacher' => CAP_ALLOW,
                    'manager' => CAP_ALLOW
            ),
            'clonepermissionsfrom' => 'moodle/course:manageactivities'
    ),
    
    'mod/teacherassistant:itemview' => array(
            'riskbitmask' => RISK_XSS,
            'captype' => 'write',
            'contextlevel' => CONTEXT_COURSE,
            'archetypes' => array(
                    'editingteacher' => CAP_ALLOW,
                    'teacher' => CAP_ALLOW,
                    'manager' => CAP_ALLOW
            ),
            'clonepermissionsfrom' => 'moodle/course:manageactivities'
    ),
    
    'mod/teacherassistant:preview' => array(
            'captype' => 'write',
            'contextlevel' => CONTEXT_COURSE,
            'archetypes' => array(
                    'teacher' => CAP_ALLOW,
                    'editingteacher' => CAP_ALLOW,
                    'manager' => CAP_ALLOW
            ),
            'clonepermissionsfrom' => 'moodle/course:manageactivities'
    ),

    'mod/teacherassistant:view' => array(
        'captype' => 'read',
        'contextlevel' => CONTEXT_MODULE,
        'legacy' => array(
            'guest' => CAP_ALLOW,
            'student' => CAP_ALLOW,
            'teacher' => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        )
    ),

    'mod/teacherassistant:submit' => array(
        'riskbitmask' => RISK_SPAM,
        'captype' => 'write',
        'contextlevel' => CONTEXT_MODULE,
        'legacy' => array(
            'student' => CAP_ALLOW
        )
    ),
);

