<?php
// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Stampa un'istanza particolare di insegnante
 *
 * Puoi anche avere una descrizione più lunga del file,
 * se vuoi, e può estendersi su più righe.
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require('../../config.php');
global $DB, $CFG, $USERS, $USER, $PAGE, $COURSE, $GLOBALS, $SECTION;

//moodleform è definito in formslib.php
require_once("$CFG->libdir/formslib.php");

require_once("$CFG->dirroot/mod/teacherassistant/lib.php");

require_once($CFG->dirroot.'/course/moodleform_mod.php');
//È necessario aggiungere quanto segue a tutti i file che accedono alle funzioni profilo_:
require_once("$CFG->dirroot/user/profile/lib.php");
require_once 'e65metadato.php';

require_once 'config2.php';
//var_dump($config2);
$mysqli = new mysqli(
    $config2['mysql_host'],
    $config2['mysql_user'],
    $config2['mysql_password'],
    $config2['mysql_db']
);
if($mysqli->connect_error){
    die($mysqli->connect_error);
}else{
    echo 'connessione riuscita';
    //var_dump($mysqli);
}
$sql1= 'CREATE TABLE if not exists mdl_teacherassistant_modulo (';
$sql1 .= 'id BIGINT(10) NOT NULL auto_increment,';
$sql1 .= 'metadato_cors_identif BIGINT(10) NOT NULL,';
$sql1 .= 'metadato_cors_nom VARCHAR(128) COLLATE utf8mb4_unicode_ci,';
$sql1 .= 'metadato_cors_sect_identif VARCHAR(128) COLLATE utf8mb4_unicode_ci,';
$sql1 .= 'metadato_cors_sect_nom VARCHAR(128) COLLATE utf8mb4_unicode_ci,';
$sql1 .= 'metadato_prerequisiti VARCHAR(2048) COLLATE utf8mb4_unicode_ci,';
$sql1 .= 'metadato_conosc_acquisite VARCHAR(516) NOT NULL COLLATE utf8mb4_unicode_ci,';
$sql1 .= 'metadato_name VARCHAR(1024) COLLATE utf8mb4_unicode_ci,';
$sql1 .= 'metadato_learning_style_1 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_learning_style_2 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_learning_style_3 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_learning_style_4 NUMERIC(2) NOT NULL,';
$sql1 .= 'metadato_tem_conc NUMERIC(2) NOT NULL,';
$sql1 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql1 .= ')';
$sql1 .= 'ENGINE = InnoDB ';
$sql1 .= 'DEFAULT COLLATE = utf8mb4_unicode_ci ROW_FORMAT=Compressed;';
//echo '<br>'.$sql1.'<br>';
$res=$mysqli->query($sql1);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '1';
}

$sql2= 'CREATE TABLE if not exists mdl_teacherassistant_metadato (';
$sql2 .= 'id BIGINT(10) NOT NULL auto_increment,';
$sql2 .= 'metadato_conosc_acquisite VARCHAR(256) UNIQUE NOT NULL COLLATE utf8mb4_unicode_ci,';
$sql2 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql2 .= ')';
$sql2 .= 'ENGINE = InnoDB ';
$sql2 .= 'DEFAULT COLLATE = utf8mb4_unicode_ci ROW_FORMAT=Compressed;';
//echo '<br>'.$sql1.'<br>';
$res=$mysqli->query($sql2);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '2';
}
$sql3 = 'CREATE TABLE if not exists mdl_teacherassistant_checkbox (';
$sql3 .= 'id BIGINT(10) NOT NULL auto_increment,';
$sql3 .= 'metadato_prerequisiti VARCHAR(2048) NOT NULL COLLATE utf8mb4_unicode_ci,';
$sql3 .= 'CONSTRAINT  PRIMARY KEY (id)';
$sql3 .= ')';
$sql3 .= 'ENGINE = InnoDB ';
$sql3 .= 'DEFAULT COLLATE = utf8mb4_unicode_ci ROW_FORMAT=Compressed;';
//echo '<br>'.$sql3.'<br>';
$res=$mysqli->query($sql3);
if(!$res){
    echo $mysqli->error.'<br>';
}else{
    echo '3';
}
$id = optional_param('id', 0, PARAM_INT); // course_module ID, or

//echo '$id optional param';
//var_dump($id);
$n  = optional_param('n', 0, PARAM_INT);  // teacherassistant ID istanza: dovrebbe essere nominato come primo carattere del modulo

if ($id) {
    $cm         = get_coursemodule_from_id('teacherassistant', $id, 0, false, MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $moduleinstance  = $DB->get_record('teacherassistant', array('id' => $cm->instance), '*', MUST_EXIST);
} elseif ($n) {
    $moduleinstance  = $DB->get_record('teacherassistant', array('id' => $n), '*', MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $moduleinstance->course), '*', MUST_EXIST);
    $cm         = get_coursemodule_from_instance('teacherassistant', $moduleinstance->id, $course->id, false, MUST_EXIST);
} else {
    print_error(get_string('missingidandcmid',MOD_TEACHERASSISTANT_LANG));
}

$metadato_cors_nom=$GLOBALS[course]->fullname;

$metadato_cors_identif=$GLOBALS[course]->id;

$globalscm_nomcmid=$GLOBALS[cm]->instance;

//send the query to the get_field_sql() function
$metadato_cors_sect_identif = $DB->get_field_sql("Select cs.section from mdl_course_modules cm LEFT Join mdl_course_sections cs on cm.section=cs.id WHERE cm.instance = $globalscm_nomcmid");

$metadato_cors_sect_nom = $DB->get_field_sql("Select cs.name from mdl_course_modules cm LEFT Join mdl_course_sections cs on cm.section=cs.id WHERE cm.instance = $globalscm_nomcmid");

$PAGE->set_url('/mod/teacherassistant/view.php', array('id' => $cm->id));
require_login($course, true, $cm);
$modulecontext = context_module::instance($cm->id);

//Deviare la logica di registrazione a Moodle 2.7
if($CFG->version<2014051200){
    add_to_log($course->id, 'teacherassistant', 'view', "view.php?id={$cm->id}", $moduleinstance->name, $cm->id);
}else{
    // Evento visualizzato modulo trigger..
    $event = \mod_teacherassistant\event\course_module_viewed::create(array(
        'objectid' => $moduleinstance->id,
        'context' => $modulecontext
    ));
    $event->add_record_snapshot('course_modules', $cm);
    $event->add_record_snapshot('course', $course);
    $event->add_record_snapshot('teacherassistant', $moduleinstance);
    $event->trigger();
}

// se siamo arrivati così lontano, possiamo considerare l'attività "vista"
$completion = new completion_info($course);
$completion->set_module_viewed($cm);

//siamo un insegnante o uno studente?
$mode= "view";

// Imposta l'intestazione della pagina
$PAGE->set_title(format_string($moduleinstance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($modulecontext);
$PAGE->set_pagelayout('course');

//Ottieni le impostazioni di amministrazione
$config = get_config(MOD_TEACHERASSISTANT_FRANKY);
$someadminsetting = $config->someadminsetting;

//Ottieni un'impostazione dell'istanza
$someinstancesetting = $moduleinstance->someinstancesetting;


// Prepara il nostro JavaScript pronto per partire
// Possiamo omettere il modulo $ js, ma è bello averlo qui,
// se per esempio dobbiamo includere alcune cose YUI funky
$jsmodule = array(
    'name'     => 'mod_teacherassistant',
    'fullpath' => '/mod/teacherassistant/module.js',
    'requires' => array()
);
//qui impostiamo tutte le informazioni necessarie per passare a JavaScript
$opts =Array();
$opts['someinstancesetting'] = $someinstancesetting;


//questo entra nel M.mod_teacherassistant cosa, dopo che la pagina è stata caricata.
$PAGE->requires->js_init_call('M.mod_teacherassistant.helper.init', array($opts),false,$jsmodule);

//questo carica tutte le librerie JS esterne che dobbiamo chiamare
//$PAGE->requires->js("/mod/teacherassistant/js/somejs.js");
//$PAGE->requires->js(new moodle_url('http://www.somewhere.com/some.js'),true);

//Questo mette tutta la nostra logica di visualizzazione nel file renderer.php in questo plugin
//gli sviluppatori di temi possono sovrascrivere le classi lì, quindi lo rendono personalizzabile per gli altri
//per farlo in questo modo.
$renderer = $PAGE->get_renderer('mod_teacherassistant');

//Da qui visualizziamo effettivamente la pagina.
// questa è roba di rendering di base


//se siamo insegnanti vediamo le schede. Se studente vediamo solo il quiz
if(has_capability('mod/teacherassistant:preview',$modulecontext)){
    echo $renderer->header($moduleinstance, $cm, $mode, null, get_string('view', MOD_TEACHERASSISTANT_LANG));
}else{
    echo $renderer->notabsheader();
}

echo $renderer->show_intro($moduleinstance,$cm);

?>
    <html lan="it">
    <head>
        <title>Teacherassistant</title>
        <style type="text/css">

            #JS { display:none; }

        </style><!-- // e21Ajax_My_JavaScript.js   --->

        <script>
            function checkJS() {

                document.getElementById('JS').style.display = "inline";

            }
        </script>
<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/main.js"></script>
<script src="bootstrap/css/bootstrap.min.css"></script>
    </head>

<body onload="checkJS();">

<h1>Teacherassistant</h1>

<div id="JS">
    <form method="post" name="invio" action="e65metadato_interface.php">
    <script>
    jQuery(function($){
        $('#demo_div').text('Hello, World!');
    });
</script>
<script>
    jQuery(function($){
        $("selector").css("color", "red");
    });
</script>
<script>
    jQuery(function($){
        $('.parent').children().css("color", "green");
    });
</script>
<div id="demo_div" class="demo">hello</div>
        <br /><h5><b>Mappa didattica</b></h5><br />
        <p>mostra la mappa didattica del corso</p>
        <br /><br /><h5><b>Prerequisiti</b></h5><br />
    <div class="checkbox">
        <div class="parent">
            <p>Seleziona uno o piu' prerequisiti :</p>
        <?php
        $conoscen_acquisit_1= $DB->get_records_select('teacherassistant_metadato','metadato_conosc_acquisite!=?',array(0));
        if(empty($conoscen_acquisit_1)){
         echo 'empty'.'<br>';     // empty
               $a = "nessun metadato presente";
         ?>
        <input type="hidden" class="checkbox1_value1" id="metadato_prerequisiti" name="metadato_prerequisiti" value="<?=$a?>" />
        <?php
        }
        else {
            ?>
            <!-- <input type="checkbox" class="checkbox1_value1" id="metadato_prerequisiti" name="metadato_prerequisiti[]" value="nessuna scelta" checked/>
                            <label class="form-check-label" for="metadato_prerequisiti[]">nessuna scelta</label><br> -->
            <?php
        foreach($conoscen_acquisit_1 as $show_prerequisiti_1) {
            $a = $show_prerequisiti_1->metadato_conosc_acquisite;
        ?>
            <div>

                             <input type="checkbox" class="checkbox1_value1" id="metadato_prerequisiti" name="metadato_prerequisiti[]" value="<?=$a?>" />
                            <label class="form-check-label" for="metadato_prerequisiti"><?=$a?></label><br>
            </div>
            
        <?php
        }
        }
        ?>
        </div>
        </div>
        
        <br /><h5><b>Conoscenze acquisite </b></h5>
        <br /><p>Scegli una conoscenza acquisita presente:</p>
        <input type="radio" id="metadato_conosc_acquisite" name="metadato_conosc_acquisite[]" value="nessuna scelta" checked>
        <label for="metadato_conosc_acquisite[]">nessuna scelta</label><br>

        <?php
        $conoscen_acquisit3 = $DB->get_records_select('teacherassistant_metadato','metadato_conosc_acquisite!=?',array(0));

        foreach($conoscen_acquisit3 as $show_conoscen_acquisit3) {
            $b = $show_conoscen_acquisit3->metadato_conosc_acquisite;
            ?>
            <input type="radio" id="metadato_conosc_acquisite" name="metadato_conosc_acquisite[]" value="<?=$b?>">
             <label for="metadato_conosc_acquisite[]"><?=$b?></label><br>
        <?php
        }
        ?>

        <br /><p>Aggiungi una nuova conoscenza acquisita :</p>
        <input type="text" title="Up to 60 Alphabetic Characters" name="metadato_name" id="metadato_name" />

        <br />

        <br /><br /><h5><b>Learning styles </b></h5><br />
        <label for="metadato_learning_style_1">attivo-riflessivo   &emsp;&emsp; &emsp; </label><input type="number" value="0" min="-11" max="11" name="metadato_learning_style_1" id="metadato_learning_style_1" required /><br />
        <label for="metadato_learning_style_2">rilevamento-intuitivo  &ensp;&ensp;</label><input type="number" value="0" min="-11" max="11" name="metadato_learning_style_2" id="metadato_learning_style_2" required /><br />
        <label for="metadato_learning_style_3">visivo-verbale    &emsp; &ensp;&emsp; &ensp;&emsp; </label><input type="number" value="0" min="-11" max="11" name="metadato_learning_style_3" id="metadato_learning_style_3" required /><br />
        <label for="metadato_learning_style_4">sequenziale-globale &ensp;&emsp;</label><input type="number" value="0" min="-11" max="11" name="metadato_learning_style_4" id="metadato_learning_style_4" required /><br /><br />
        <br />
        <label for="metadato_tem_conc"><h5>tempo  concesso &ensp; </h5></label><input type="number" value="0" min="1" max="60" name="metadato_tem_conc" id="metadato_tem_conc" required />
        <br />
        <input type="hidden" name="metadato_app" id="metadato_app" value="metadato" />
        <input type="hidden" name="metadato_cors_identif" id="metadato_cors_identif" value="<?=$metadato_cors_identif?>" />
        <input type="hidden" name="metadato_cors_nom" id="metadato_cors_nom" value="<?=$metadato_cors_nom?>" />
        <input type="hidden" name="metadato_cors_sect_identif" id="metadato_cors_sect_identif" value="<?=$metadato_cors_sect_identif?>" />
        <input type="hidden" name="metadato_cors_sect_nom" id="metadato_cors_sect_nom" value="<?=$metadato_cors_sect_nom?>" />
        <script>
            AjaxRequest('e65metadato_interface.php');
        </script>
        <input type="submit" id="submit" class="btn btn-info" name="submit" value="Salva il metadato" />
        

       <!-- <script>
        var check;
$("#submit").on("click", function(){
    var metadato_prerequisiti = new Array();
    var contenuto = $("#metadato_prerequisiti").val();
    check = $("#metadato_prerequisiti").is(":checked");
    if(check) {
        alert("Checkbox is checked." + contenuto + " " + check +"prova");
        document.getElementById("result").innerHTML = "Check Box checked !!!";
    } else {
        alert("Checkbox is unchecked.");
    }

}); 
</script>  -->
            <div id="result" class="demo"></div>
           
    </form>
    
</div>

<noscript>
    <div id="noJS">
        <form method="post" action="e65metadato_interface.php">
            <h2>Please complete ALL fields. Please note the required format of information.</h2>
            <br /><br /><h5><b>Prerequisiti</b></h5><br />
        <p>Seleziona uno o piu' prerequisiti :</p>
        <?php
        $conoscen_acquisit_1= $DB->get_records_select('teacherassistant_metadato','metadato_conosc_acquisite!=?',array(0));
        if(empty($conoscen_acquisit_1)){
         echo 'empty'.'<br>';     // empty
               $a = "nessun metadato presente";
         ?>
        <input type="hidden" id="metadato_prerequisiti" name="metadato_prerequisiti" value="<?=$a?>" />
        <?php
        }
        else {
            ?>
             <input type="checkbox" id="metadato_prerequisiti" name="metadato_prerequisiti[]" value="nessuna scelta" checked/>
                            <label class="form-check-label" for="metadato_prerequisiti[]">nessuna scelta</label><br>
            <?php
        foreach($conoscen_acquisit_1 as $show_prerequisiti_1) {
            $a = $show_prerequisiti_1->metadato_conosc_acquisite;
        ?>
            <div>

                             <input type="checkbox" id="metadato_prerequisiti" name="metadato_prerequisiti[]" value="<?=$a?>" />
                            <label class="form-check-label" for="metadato_prerequisiti"><?=$a?></label><br>
            </div>
        <?php
        }
        }
        ?>
        <br /><h5><b>Conoscenze acquisite </b></h5>
        <br /><p>Scegli una conoscenza acquisita presente:</p>
        <input type="radio" id="metadato_conosc_acquisite" name="metadato_conosc_acquisite[]" value="nessuna scelta" checked>
        <label for="metadato_conosc_acquisite[]">nessuna scelta</label><br>

        <?php
        $conoscen_acquisit3 = $DB->get_records_select('teacherassistant_metadato','metadato_conosc_acquisite!=?',array(0));

        foreach($conoscen_acquisit3 as $show_conoscen_acquisit3) {
            $b = $show_conoscen_acquisit3->metadato_conosc_acquisite;
            ?>
            <input type="radio" id="metadato_conosc_acquisite" name="metadato_conosc_acquisite[]" value="<?=$b?>">
             <label for="metadato_conosc_acquisite[]"><?=$b?></label><br>
        <?php
        }
        ?>

        <br /><p>Aggiungi una nuova conoscenza acquisita :</p>
        <input type="text" title="Up to 60 Alphabetic Characters" name="metadato_name" id="metadato_name" />

            <b>Learning styles</b><br /><br />
            attivo-riflessivo  <input type="number" min="-11" max="11" name="metadato_learning_style_1" id="metadato_learning_style_1" required /><br />
            rilevamento-intuitivo  <input type="number" min="-11" max="11" name="metadato_learning_style_2" id="metadato_learning_style_2" required /><br />
            visivo-verbale  <input type="number" min="-11" max="11" name="metadato_learning_style_3" id="metadato_learning_style_3" required /><br />
            sequenziale-globale  <input type="number" min="-11" max="11" name="metadato_learning_style_4" id="metadato_learning_style_4" required /><br /><br />
            <br />
            tempo  concesso  <input type="number" value="0" min="1" max="60" name="metadato_tem_conc" id="metadato_tem_conc" required /><br /><br />
            <br />
            <input type="hidden" name="metadato_app" id="metadato_app" value="metadato" />
            <input type="hidden" name="metadato_cors_identif" id="metadato_cors_identif" value="<?=$metadato_cors_identif?>" /><br />
            <input type="hidden" name="metadato_cors_nom" id="metadato_cors_nom" value="<?=$metadato_cors_nom?>" /><br />
            <input type="hidden" name="metadato_cors_sect_identif" id="metadato_cors_sect_identif" value="<?=$metadato_cors_sect_identif?>" /><br />
            <input type="hidden" name="metadato_cors_sect_nom" id="metadato_cors_sect_nom" value="<?=$metadato_cors_sect_nom?>" /><br />
            <input type="submit" id="btn_2" value="Salva il metadato" />
        </form>
    </div>
</noscript>    
<?php

//se abbiamo troppi tentativi, segnaliamolo.
if($moduleinstance->maxattempts > 0){
    $attempts =  $DB->get_records(MOD_TEACHERASSISTANT_USERTABLE,array('userid'=>$USER->id, MOD_TEACHERASSISTANT_MODNAME.'id'=>$moduleinstance->id));
    if($attempts && count($attempts)<$moduleinstance->maxattempts){
        echo get_string("exceededattempts",MOD_TEACHERASSISTANT_LANG,$moduleinstance->maxattempts);
    }
}

//Questo è specifico per il nostro renderer
//echo $renderer->show_something($someadminsetting);
//echo $renderer->show_something($someinstancesetting);

// Termina la pagina
echo $renderer->footer();

?>