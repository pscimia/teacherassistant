<?php
class Metadato
{
// ----------------------------------------- Properties -----------------------------------------
private $metadato_cors_identif = 0;
private $metadato_cors_nom = "no cors_nom";
private $metadato_cors_sect_identif = 0;
private $metadato_cors_sect_nom = "no cors_sect_nom";
private $metadato_prerequisiti_rome_in_the_neorealism = "no prerequisiti_rome_in_the_neorealism";
private $metadato_prerequisiti_rossellini = "no prerequisiti_rossellini";
private $metadato_prerequisiti_roma_citta_aperta = "no prerequisiti_roma_citta_aperta";
private $metadato_conosc_acquisite = "no conosc_acquisite";
private $metadato_learning_style_1 = 0;
private $metadato_learning_style_2 = 0;
private $metadato_learning_style_3 = 0;
private $metadato_learning_style_4 = 0;
private $metadato_tem_conc = 0;
private $error_message = "??";
// ---------------------------------- Constructor ----------------------------------------------
function __construct($properties_array)
{
if (method_exists('metadato_container', 'create_object')) {

$cors_identif_error = $this->set_metadato_cors_identif($properties_array[0]) == TRUE ? 'TRUE,' : 'FALSE,';
$cors_nom_error = $this->set_metadato_cors_nom($properties_array[1]) == TRUE ? 'TRUE,' : 'FALSE,';
$cors_sect_identif_error = $this->set_metadato_cors_sect_identif($properties_array[2]) == TRUE ? 'TRUE,' : 'FALSE,';
$cors_sect_nom_error = $this->set_metadato_cors_sect_nom($properties_array[3]) == TRUE ? 'TRUE,' : 'FALSE,';
$prerequisiti_rome_in_the_neorealism_error = $this->set_metadato_prerequisiti_rome_in_the_neorealism($properties_array[4]) == TRUE ? 'TRUE,' : 'FALSE,';
$prerequisiti_rossellini_error = $this->set_metadato_prerequisiti_rossellini($properties_array[5]) == TRUE ? 'TRUE,' : 'FALSE,';
$prerequisiti_roma_citta_aperta_error = $this->set_metadato_prerequisiti_roma_citta_aperta($properties_array[6]) == TRUE ? 'TRUE,' : 'FALSE,';
$conosc_acquisite_error = $this->set_metadato_conosc_acquisite($properties_array[7]) == TRUE ? 'TRUE,' : 'FALSE,';
$learning_style_1_error= $this->set_metadato_learning_style_1($properties_array[8]) == TRUE ? 'TRUE' : 'FALSE';
$learning_style_2_error= $this->set_metadato_learning_style_2($properties_array[9]) == TRUE ? 'TRUE' : 'FALSE';
$learning_style_3_error= $this->set_metadato_learning_style_3($properties_array[10]) == TRUE ? 'TRUE' : 'FALSE';
$learning_style_4_error= $this->set_metadato_learning_style_4($properties_array[11]) == TRUE ? 'TRUE' : 'FALSE';
$metadato_tem_conc_error= $this->set_metadato_tem_conc($properties_array[12]) == TRUE ? 'TRUE' : 'FALSE';


$this->error_message = $cors_identif_error . $cors_nom_error . $cors_sect_identif_error . $cors_sect_nom_error . $prerequisiti_rome_in_the_neorealism_error . $prerequisiti_rossellini_error . $prerequisiti_roma_citta_aperta_error . $conosc_acquisite_error . $learning_style_1_error . $learning_style_2_error . $learning_style_3_error . $learning_style_4_error . $metadato_tem_conc_error;
$this->save_metadato_data();
if(stristr($this->error_message, 'FALSE'))
{
	throw new setException($this->error_message);
}
}
else
{
exit;
}
}
function clean_input() { }
private function save_metadato_data()
{
if ( file_exists("e65metadato_container.php")) {
		require_once("e65metadato_container.php"); // use chapter 5 container w exception handling
	} else {
		throw new Exception("metadato container file missing or corrupt");
	}
	
	$container = new metadato_container("metadatodata"); // sets the tag name to look for in XML file
	$properties_array = array("metadatodata"); // not used but must be passed into create_object
	$metadato_data = $container->create_object($properties_array); // creates metadato_data object
	$method_array = get_class_methods($metadato_data);
	$last_position = count($method_array) - 1;
	$method_name = $method_array[$last_position]; 
	$record_Array = array(array('metadato_cors_identif'=>"$this->metadato_cors_identif",'metadato_cors_nom'=>"$this->metadato_cors_nom",'metadato_cors_sect_identif'=>"$this->metadato_cors_sect_identif",'metadato_cors_sect_nom'=>"$this->metadato_cors_sect_nom",'metadato_prerequisiti_rome_in_the_neorealism'=>"$this->metadato_prerequisiti_rome_in_the_neorealism", 'metadato_prerequisiti_rossellini'=>"$this->metadato_prerequisiti_rossellini", 'metadato_prerequisiti_roma_citta_aperta'=>"$this->metadato_prerequisiti_roma_citta_aperta", 'metadato_conosc_acquisite'=>"$this->metadato_conosc_acquisite", 'metadato_learning_style_1'=>"$this->metadato_learning_style_1", 'metadato_learning_style_2'=>"$this->metadato_learning_style_2", 'metadato_learning_style_3'=>"$this->metadato_learning_style_3", 'metadato_learning_style_4'=>"$this->metadato_learning_style_4", 'metadato_tem_conc'=>"$this->metadato_tem_conc"));
	$metadato_data->$method_name("Insert",$record_Array);
	$metadato_data = NULL;
	
}
function set_metadato_cors_identif($value)
{
$error_message = TRUE;
(($value > -1) === TRUE) ? $this->metadato_cors_identif = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_cors_nom($value)
{
$error_message = TRUE;
(ctype_alpha($value) === TRUE) ? $this->metadato_cors_nom = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_cors_sect_identif($value)
{
$error_message = TRUE;
(($value > -1) === TRUE) ? $this->metadato_cors_sect_identif = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_cors_sect_nom($value)
{
$error_message = TRUE;
(ctype_alpha($value) === TRUE) ? $this->metadato_cors_sect_nom = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_prerequisiti_rome_in_the_neorealism($value)
{
$error_message = TRUE;
(ctype_alpha($value) === TRUE) ? $this->metadato_prerequisiti_rome_in_the_neorealism = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_prerequisiti_rossellini($value)
{
$error_message = TRUE;
(ctype_alpha($value) === TRUE) ? $this->metadato_prerequisiti_rossellini = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_prerequisiti_roma_citta_aperta($value)
{
$error_message = TRUE;
(ctype_alpha($value) === TRUE) ? $this->metadato_prerequisiti_roma_citta_aperta = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_conosc_acquisite($value)
{
$error_message = TRUE;
(ctype_alpha($value) && strlen($value) <= 60) ? $this->metadato_conosc_acquisite = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_learning_style_1($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > -12 && $value <= 11)) ? $this->metadato_learning_style_1 = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_learning_style_2($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > -12 && $value <= 11)) ? $this->metadato_learning_style_2 = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_learning_style_3($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > -12 && $value <= 11)) ? $this->metadato_learning_style_3 = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_learning_style_4($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > -12 && $value <= 11)) ? $this->metadato_learning_style_4 = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_tem_conc($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > 0 && $value <= 60)) ? $this->metadato_tem_conc = $value : $this->error_message = FALSE;
return $this->error_message;
}
// ----------------------------------------- Get Methods ------------------------------------------------------------
function get_metadato_cors_identif()
{
return $this->metadato_cors_identif;
}
function get_metadato_cors_nom()
{
return $this->metadato_cors_nom;
}
function get_metadato_cors_sect_identif()
{
return $this->metadato_cors_sect_identif;
}
function get_metadato_cors_sect_nom()
{
return $this->metadato_cors_sect_nom;
}
function get_metadato_prerequisiti_rome_in_the_neorealism()
{
return $this->metadato_prerequisiti_rome_in_the_neorealism;
}
function get_metadato_prerequisiti_rossellini()
{
return $this->metadato_prerequisiti_rossellini;
}
function get_metadato_prerequisiti_roma_citta_aperta()
{
return $this->metadato_prerequisiti_roma_citta_aperta;
}
function get_metadato_conosc_acquisite()
{
return $this->metadato_conosc_acquisite;
}
function get_metadato_learning_style_1()
{
return $this->metadato_learning_style_1;
}
function get_metadato_learning_style_2()
{
return $this->metadato_learning_style_2;
}
function get_metadato_learning_style_3()
{
return $this->metadato_learning_style_3;
}
function get_metadato_learning_style_4()
{
return $this->metadato_learning_style_4;
}
function get_metadato_tem_conc()
{
return $this->metadato_tem_conc;
}
function get_properties()
{
return "$this->metadato_cors_identif,$this->metadato_cors_nom,$this->metadato_cors_sect_identif,$this->metadato_cors_sect_nom,$this->metadato_prerequisiti_rome_in_the_neorealism,$this->metadato_prerequisiti_rossellini,$this->metadato_prerequisiti_roma_citta_aperta,$this->metadato_conosc_acquisite,$this->metadato_learning_style_1,$this->metadato_learning_style_2,$this->metadato_learning_style_3,$this->metadato_learning_style_4,$this->metadato_tem_conc.";
}
// ----------------------------------General Method---------------------------------------------

}
?>