﻿<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.


/**
 * Definisce la versione di teacherassistant
 *
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

global $plugin;

$plugin->version   = 2020102300;               // Se la versione == 0, il modulo non verrà installato
$plugin->requires  = 2014051200;      // Richiede questa versione di Moodle
$plugin->cron      = 0;               //Periodo per cron per controllare questo modulo (sec)
$plugin->component = 'mod_teacherassistant'; // Per verificare l'aggiornamento, quel modulo si trova nella posizione corretta; Dichiara il tipo e il nome di questo plugin.
//$plugin->maturity = MATURITY_STABLE;
$plugin->release = 'v2.7-r1'; // Questa è la nostra prima revisione per il ramo Moodle 2.7.x.

