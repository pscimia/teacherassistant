// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

copyright 2020 Scimia Pierluigi <p.scimia@gmail.com>
license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later


TEACHERASSISTANT modulo
=============

Il TEACHERASSISTANT  modulo è uno dei successori del plugin di tipo "file" originale del modulo Resource.


TODO:
 * implementare il supporto del portafoglio (MDL-20084)
 * nuova trasformazione di backup / ripristino e ripristino precedente (MDL-20085)
