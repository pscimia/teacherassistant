<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * @package   mod_teacherassistant
 * @copyright 2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
 
 require_once($CFG->dirroot . '/mod/teacherassistant/lib.php');

/**
 * Definire tutti i passaggi di ripristino che verranno utilizzati da restore_teacherassistant_activity_task
 */

/**
 * Strutturare il passaggio per ripristinare un'attività di supporto del teacherassistant
 */
class restore_teacherassistant_activity_structure_step extends restore_activity_structure_step {

    protected function define_structure() {

        $paths = array();

        $userinfo = $this->get_setting_value('userinfo'); // stiamo includendo userinfo?

        ////////////////////////////////////////////////////////////////////////
        // Percorsi XML interessanti - dati non utente
        ////////////////////////////////////////////////////////////////////////

        // elemento radice che descrive l'istanza del teacherassistant
        $oneactivity = new restore_path_element(MOD_TEACHERASSISTANT_MODNAME, '/activity/teacherassistant');
        $paths[] = $oneactivity;

        

        // Termina qui se non sono stati selezionati dati utente
        if (!$userinfo) {
            return $this->prepare_activity_structure($paths);
        }

        ////////////////////////////////////////////////////////////////////////
        // Percorsi interessanti XML: dati utente
        ////////////////////////////////////////////////////////////////////////
        //tentativi
         $attempts= new restore_path_element(MOD_TEACHERASSISTANT_USERTABLE,
                                            '/activity/teacherassistant/attempts/attempt');
        $paths[] = $attempts;
         


        // Restituisce i percorsi inclusi nella struttura delle attività standard
        return $this->prepare_activity_structure($paths);
    }

    protected function process_teacherassistant($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->course = $this->get_courseid();

        $data->timemodified = $this->apply_date_offset($data->timemodified);
        $data->timecreated = $this->apply_date_offset($data->timecreated);


        // inserire il record dell'attività
        $newitemid = $DB->insert_record(MOD_TEACHERASSISTANT_TABLE, $data);
        // subito dopo aver inserito il record "attività", chiamare questo
        $this->apply_activity_instance($newitemid);
    }

    
    protected function process_teacherassistant_attempt($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        $data->timecreated = $this->apply_date_offset($data->timecreated);

        
        $data->{MOD_TEACHERASSISTANT_MODNAME . 'id'} = $this->get_new_parentid(MOD_TEACHERASSISTANT_MODNAME);
        $newitemid = $DB->insert_record(MOD_TEACHERASSISTANT_USERTABLE, $data);
        
        // Mappatura senza file
        //        qui impostiamo il nome della tabella come "chiave" per la mappatura, ma in realtà è arbitrario
        //        'avremmo bisogno di usare la "chiave" più tardi quando chiamiamo add_related_files per il itemid nell'area dei file di moodle
        //         Se avessimo file per questo set di dati.)
       $this->set_mapping(MOD_TEACHERASSISTANT_USERTABLE, $oldid, $newitemid, false); 
    }
    
    protected function after_execute() {
        // Aggiungi file correlati al modulo, non è necessario abbinarli per nome elemento (solo contesto gestito internamente)
        $this->add_related_files(MOD_TEACHERASSISTANT_FRANKY, 'intro', null);
    }
}

