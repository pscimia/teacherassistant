<?php

class metadato_container
{

private $app;
private $metadato_location;

function __construct($value)
{
if (function_exists('clean_input'))
{
$this->app = $value;
}
else
{
exit;
}
}

public function set_app($value)
{
$this->app = $value;
}

public function get_metadato_application($search_value)
{

$xmlDoc = new DOMDocument(); 

if ( file_exists("e61metadato_applications.xml") )

{
$xmlDoc->load( 'e61metadato_applications.xml' );

$searchNode = $xmlDoc->getElementsByTagName( "type" ); 

foreach( $searchNode as $searchNode ) 
{ 
    $valueID = $searchNode->getAttribute('ID'); 
    
    if($valueID == $search_value)
    {

    $xmlLocation = $searchNode->getElementsByTagName( "location" ); 
    return $xmlLocation->item(0)->nodeValue;
    break;

    }

}
}
    throw new Exception("Metadato applications xml file missing or corrupt");
  //  return FALSE;
}
function create_object($properties_array)
{

  $metadato_loc = $this->get_metadato_application($this->app);
  if(($metadato_loc == FALSE) || (!file_exists($metadato_loc)))
  {
  
    throw new Exception("File $metadato_loc missing or corrupt.");
  //  return FALSE;
  }
  else
  {

    require_once($metadato_loc);
    $class_array = get_declared_classes();
	$last_position = count($class_array) - 1;
	$class_name = $class_array[$last_position];	
	$metadato_object = new $class_name($properties_array);
	
	return $metadato_object;
	}

}

}

?>