<table>
    <caption>
        USER LIST
    </caption>
<thead>
<tr>
<th>Course Module Id</th>
<th>Course Id</th>
<th>Id</th>
<th>Username</th>
<th>Firstname</th>
<th>Lastname</th>
<th>Email</th>
<th>City</th>




</tr>

</thead>
<tbody>
<?php
global $USER,$cm,$COURSE; //global $DB, $CFG, $USERS, $USER, $PAGE, $COURSE, $GLOBALS, $SECTION;
    //if($GLOBALS['users']){
    if($USER){
        foreach($USER as $showuser){?>
    <tr>
            <td><?= $cm->id ?></td>
            <td><?= $COURSE->id ?></td>
            <td><?=$showuser->id?></td>
            <td><?=$showuser->username?></td>
            <td><?=$showuser->firstname?></td>
            <td><?=$showuser->lastname?></td>
            <td><a href="mailto:<?=$showuser->email?>"><?=$showuser->email?></td>
            <td><?=$showuser->city?></td>
    </tr>
       <?php }
    }else{
        echo '<tr><td colspan="8"><h2>No Records found</h2></td></tr>';
    }
?>
</tbody>

    <tfoot>
    <tr>
        <td colspan="8" class="text-center">
            Footer
        </td>
    </tr>
    </tfoot>


</table>