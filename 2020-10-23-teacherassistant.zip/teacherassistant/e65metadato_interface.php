<?php
const USER_ERROR_LOG = "../User_Errors.log";
const ERROR_LOG = "../Errors.log";
require 'config2.php';
//var_dump($config2);
$mysqli = new mysqli(
	$config2['mysql_host'],
	$config2['mysql_user'],
	$config2['mysql_password'],
	$config2['mysql_db']
);
global $DB;
$corso_id=NULL;
if($mysqli->connect_error){
	die($mysqli->connect_error);
}else{
	echo '';
	//var_dump($mysqli);
}
function clean_input($value)
{


	$value = htmlentities($value);
	// Removes any html from the string and turns it into &lt; format
	$value = strip_tags($value);


	if (get_magic_quotes_gpc())
	{
		$value = stripslashes($value);

		// Gets rid of unwanted slashes
	}
	$value = htmlentities($value);

	// Removes any html from the string and turns it into &lt; format

	$bad_chars = array( "{", "}", "(", ")", ";", ":", "<", ">", "/", "$" );
	$value = str_ireplace($bad_chars,"",$value);
	return $value;

}


class setException extends Exception {
	public function errorMessage() {

		list($cors_identif_error,$cors_nom_error,$cors_sect_identif_error,$cors_sect_nom_error,$prerequisiti_rome_in_the_neorealism_error,$prerequisiti_rossellini_error,$prerequisiti_roma_citta_aperta_error,$conosc_acquisite_error,$learning_style_1_error,$learning_style_2_error,$learning_style_3_error,$learning_style_4_error,$tem_conc_error) = explode(',', $this->getMessage());

		$cors_identif_error == 'TRUE' ? $eMessage = '' : $eMessage = 'Identificatore del corso non aggiornato<br/>';
		$cors_nom_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Nome del corso non aggiornato<br/>';
		$cors_sect_identif_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Identificatore della sezione del corso  non aggiornato<br/>';
		$cors_sect_nom_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Nome della sezione del corso non aggiornato<br/>';
		$prerequisiti_rome_in_the_neorealism_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'prerequisiti_rome_in_the_neorealism non aggiornato<br/>';
		$prerequisiti_rossellini_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'prerequisiti_rossellini non aggiornato<br/>';
        $prerequisiti_roma_citta_aperta_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'prerequisiti_roma_citta_aperta non aggiornato<br/>';
		$conosc_acquisite_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'conosc_acquisite non aggiornato<br/>';
		$learning_style_1_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Learning_style_1 non aggiornato<br/>';
		$learning_style_2_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Learning_style_2 non aggiornato<br/>';
		$learning_style_3_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Learning_style_3 non aggiornato<br/>';
		$learning_style_4_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Learning_style_4 non aggiornato<br/>';
		$tem_conc_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Tempo concesso non aggiornato<br/>';

		return $eMessage;
	}
}

function get_metadato_app_properties($lab)
{

	print "Identificatore del corso  : " . $lab->get_metadato_cors_identif() . "<br />";
	print "Il nome del corso : " . $lab->get_metadato_cors_nom() . "<br />";
	print "Identificatore della sezione del corso  : " . $lab->get_metadato_cors_sect_identif() . "<br />";
	print "Nome della sezione del corso : " . $lab->get_metadato_cors_sect_nom() . "<br />";
	print "Il metadato prerequisiti_rome_in_the_neorealism : " . $lab->get_metadato_prerequisiti_rome_in_the_neorealism() . "<br />";
	print "Il metadato prerequisiti_rossellini : " . $lab->get_metadato_prerequisiti_rossellini() . "<br />";
    print "Il metadato prerequisiti_roma_citta_aperta : " . $lab->get_metadato_prerequisiti_roma_citta_aperta() . "<br />";
	print "Il metadato conoscenze acquisite : " . $lab->get_metadato_conosc_acquisite() . "<br />";
	print "Il metadato learning_style_1 : " . $lab->get_metadato_learning_style_1() . " . <br />";
	print "Il metadato learning_style_2 : " . $lab->get_metadato_learning_style_2() . " . <br />";
	print "Il metadato learning_style_3 : " . $lab->get_metadato_learning_style_3() . " . <br />";
	print "Il metadato learning_style_4 : " . $lab->get_metadato_learning_style_4() . " . <br />";
	print "Il tempo concesso risulta di minuti : " . $lab->get_metadato_tem_conc() . " . <br />";

}
//----------------Main Section-------------------------------------
try {
	if ( file_exists("e65metadato_container.php"))
	{
		Require_once("e65metadato_container.php");
	}
	else
	{
		throw new Exception("metadato container file missing or corrupt");
	}

	if (isset($_POST['metadato_app']))
	{

		if ((isset($_POST['metadato_cors_identif'])) && (isset($_POST['metadato_cors_nom'])) && (isset($_POST['metadato_cors_sect_identif'])) && (isset($_POST['metadato_cors_sect_nom'])) && (isset($_POST['metadato_prerequisiti_rome_in_the_neorealism'])) && (isset($_POST['metadato_prerequisiti_rossellini'])) && (isset($_POST['metadato_prerequisiti_roma_citta_aperta'])) && (isset($_POST['metadato_conosc_acquisite'])) && (isset($_POST['metadato_learning_style_1'])) && (isset($_POST['metadato_learning_style_2'])) && (isset($_POST['metadato_learning_style_3'])) && (isset($_POST['metadato_learning_style_4'])) && (isset($_POST['metadato_tem_conc'])))
		{

			$container = new metadato_container(clean_input($_POST['metadato_app']));

			$metadato_cors_identif = clean_input($_POST['metadato_cors_identif']);
			$metadato_cors_nom = clean_input($_POST['metadato_cors_nom']);
            $metadato_cors_sect_identif = clean_input($_POST['metadato_cors_sect_identif']);
			$metadato_cors_sect_nom = clean_input($_POST['metadato_cors_sect_nom']);
			$metadato_prerequisiti_rome_in_the_neorealism = clean_input($_POST['metadato_prerequisiti_rome_in_the_neorealism']);
			$metadato_prerequisiti_rossellini = clean_input($_POST['metadato_prerequisiti_rossellini']);
            $metadato_prerequisiti_roma_citta_aperta = clean_input($_POST['metadato_prerequisiti_roma_citta_aperta']);
			$metadato_conosc_acquisite = clean_input($_POST['metadato_conosc_acquisite']);
			$metadato_learning_style_1 = clean_input($_POST['metadato_learning_style_1']);
			$metadato_learning_style_2 = clean_input($_POST['metadato_learning_style_2']);
			$metadato_learning_style_3 = clean_input($_POST['metadato_learning_style_3']);
			$metadato_learning_style_4 = clean_input($_POST['metadato_learning_style_4']);
			$metadato_tem_conc = clean_input($_POST['metadato_tem_conc']);
			$sql = 'INSERT INTO mdl_teacherassistant_save_data6(metadato_cors_identif,metadato_cors_nom,metadato_cors_sect_identif,metadato_cors_sect_nom,metadato_prerequisiti_rome_in_the_neorealism,metadato_prerequisiti_rossellini,metadato_prerequisiti_roma_citta_aperta,metadato_conosc_acquisite,metadato_learning_style_1,metadato_learning_style_2,metadato_learning_style_3,metadato_learning_style_4,metadato_tem_conc) VALUES';
			$sql .= "($metadato_cors_identif,'$metadato_cors_nom',$metadato_cors_sect_identif,'$metadato_cors_sect_nom','$metadato_prerequisiti_rome_in_the_neorealism','$metadato_prerequisiti_rossellini','$metadato_prerequisiti_roma_citta_aperta','$metadato_conosc_acquisite',$metadato_learning_style_1,$metadato_learning_style_2,$metadato_learning_style_3,$metadato_learning_style_4,$metadato_tem_conc);";
			//echo '<br>'.$sql.'<br>';
			echo '<br>';
			$res=$mysqli->query($sql);
			if(!$res){
				echo $mysqli->error.'<br>';
			}else{
				echo 'Metadato salvato con successo! '.'<br>';
			}

			$properties_array = array($metadato_cors_identif,$metadato_cors_nom,$metadato_cors_sect_identif,$metadato_cors_sect_nom,$metadato_prerequisiti_rome_in_the_neorealism,$metadato_prerequisiti_rossellini,$metadato_prerequisiti_roma_citta_aperta,$metadato_conosc_acquisite,$metadato_learning_style_1,$metadato_learning_style_2,$metadato_learning_style_3,$metadato_learning_style_4,$metadato_tem_conc);
			$lab = $container->create_object($properties_array);

			print "Updates successful<br />";
			get_metadato_app_properties($lab);
		}

		else
		{

			print "<p>Missing or invalid parameters. Please go back to the metadato.html page to enter valid information.<br />";

			print "<a href='view.php'>metadato Creation Page</a>";

		}
	}//selectbox
}
catch(setException $e)
{
	echo $e->errorMessage(); // displays to the user

	$date = date('m.d.Y h:i:s');
	$errormessage = $e->errorMessage();
	$eMessage =  $date . " | User Error | " . $errormessage . "\n";
	error_log($eMessage,3,USER_ERROR_LOG); // writes message to user error log file

}
catch(Exception $e)
{

	echo "The system is currently unavailable. Please try again later."; // displays message to the user

	$date = date('m.d.Y h:i:s');
	$eMessage =  $date . " | System Error | " . $e->getMessage() . " | " . $e->getFile() . " | ". $e->getLine() . "\n";
	error_log($eMessage,3,ERROR_LOG); // writes message to error log file

	error_log("Date/Time: $date - Serious System Problems with metadato Application. Check error log for details", 1, "p.scimia@gmail.com", "Subject: metadato Application Error \nFrom: System Log <systemlog@helpme.com>". "\r\n");
	// e-mails personnel to alert them of a system problem

}
?>
