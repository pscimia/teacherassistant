<?php
require_once("$CFG->libdir/formslib.php");
 
class simplehtml_form extends moodleform {
 
    function definition() {
        global $CFG;
 
        $mform = $this->_form; // Don't forget the underscore! 

        $mform->addElement('button', 'intro', get_string("buttonlabel"));
 
       /* $searchareas = \core_search\manager::get_search_areas_list(true);                                                           
$areanames = array();                                                                                                       
foreach ($searchareas as $areaid => $searcharea) {                                                                          
    $areanames[$areaid] = $searcharea->get_visible_name();                                                                  
}                                                                                                                           
$options = array(                                                                                                           
    'multiple' => true,                                                  
 
 
    'noselectionstring' => get_string('allareas', 'search'),                                                                
);         
$mform->addElement('autocomplete', 'areaids', get_string('searcharea', 'search'), $areanames, $options);

$mform->addElement('checkbox', 'ratingtime', get_string('ratingtime', 'forum'));
*/
       // $mform->addElement()... // Add elements to your form
            }                           // Close the function
}                               // Close the class
