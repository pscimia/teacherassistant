<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Il modulo di configurazione del teacherassistant principale
 *
 * Utilizza il formlib standard Moodle core. Per maggiori informazioni su di loro, per favore
 * vvisitare: http://docs.moodle.org/en/Development:lib/formslib.php
 *
 * @package    mod_teacherassistant
 * @copyright  2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

global $CFG;

require_once($CFG->dirroot.'/course/moodleform_mod.php');
require_once($CFG->dirroot.'/mod/teacherassistant/lib.php');

/**
 * Modulo impostazioni dell'istanza del modulo
 */
class mod_teacherassistant_mod_form extends moodleform_mod {

    /**
     * Definisce gli elementi dei moduli
     */
    public function definition() {
        global $CFG;

        $mform = $this->_form;

        //-------------------------------------------------------------------------------
        // Aggiunta del set di campi "general", in cui sono mostrate tutte le impostazioni comuni
        $mform->addElement('header', 'general', get_string('general', 'form'));

        // Aggiunta del campo "nome" standard
        $mform->addElement('text', 'name', get_string('teacherassistantname', MOD_TEACHERASSISTANT_LANG), array('size'=>'64'));
        if (!empty($CFG->formatstringstriptags)) {
            $mform->setType('name', PARAM_TEXT);
        } else {
            $mform->setType('name', PARAM_CLEAN);
        }
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', get_string('maximumchars', '', 255), 'maxlength', 255, 'client');
        $mform->addHelpButton('name', 'teacherassistantname', MOD_TEACHERASSISTANT_LANG);

        // Aggiunta dei campi standard "intro" e "introformat"
        if($CFG->version < 2015051100){
            $this->add_intro_editor();
        }else{
            $this->standard_intro_elements();
        }

        //-------------------------------------------------------------------------------
        // Aggiungendo il resto delle impostazioni del teacherassistant, spandendole tutte in questo set di campi
        // o aggiungendo più set di campi (elementi 'header') se necessario per una migliore logica
        $mform->addElement('static', 'label1', 'teacherassistantsettings', get_string('teacherassistantsettings', MOD_TEACHERASSISTANT_LANG));
        $mform->addElement('text', 'someinstancesetting', get_string('someinstancesetting', MOD_TEACHERASSISTANT_LANG), array('size'=>'64'));
        $mform->addRule('someinstancesetting', null, 'required', null, 'client');
        $mform->setType('someinstancesetting', PARAM_TEXT);

        //tentativi
        $attemptoptions = array(0 => get_string('unlimited', MOD_TEACHERASSISTANT_LANG),
            1 => '1',2 => '2',3 => '3',4 => '4',5 => '5',);
        $mform->addElement('select', 'maxattempts', get_string('maxattempts', MOD_TEACHERASSISTANT_LANG), $attemptoptions);

        // Grado.
        $this->standard_grading_coursemodule_elements();

        //opzioni di grado
        $gradeoptions = array(MOD_TEACHERASSISTANT_GRADEHIGHEST => get_string('gradehighest',MOD_TEACHERASSISTANT_LANG),
            MOD_TEACHERASSISTANT_GRADELOWEST => get_string('gradelowest', MOD_TEACHERASSISTANT_LANG),
            MOD_TEACHERASSISTANT_GRADELATEST => get_string('gradelatest', MOD_TEACHERASSISTANT_LANG),
            MOD_TEACHERASSISTANT_GRADEAVERAGE => get_string('gradeaverage', MOD_TEACHERASSISTANT_LANG),
            MOD_TEACHERASSISTANT_GRADENONE => get_string('gradenone', MOD_TEACHERASSISTANT_LANG));
        $mform->addElement('select', 'gradeoptions', get_string('gradeoptions', MOD_TEACHERASSISTANT_LANG), $gradeoptions);



        //-------------------------------------------------------------------------------
        // aggiungere elementi standard, comuni a tutti i moduli
        $this->standard_coursemodule_elements();
        //-------------------------------------------------------------------------------
        // aggiungere pulsanti standard, comuni a tutti i moduli
        $this->add_action_buttons();
    }


    /**
     * Questo aggiunge regole di completamento
     * I valori qui sono solo di esempio. Non funzionano in questo progetto fino a quando non si implementa una sorta di valutazione
     * Vedi lib.php teacherassistant_get_completion_state()
     */
    function add_completion_rules() {
        $mform =& $this->_form;
        $config = get_config(MOD_TEACHERASSISTANT_FRANKY);

        //opzioni timer
        //Aggiungi un luogo per impostare un tempo minimo dopo il quale l'attività viene registrata completata
        $mform->addElement('static', 'mingradedetails', '',get_string('mingradedetails', MOD_TEACHERASSISTANT_LANG));
        $options= array(0=>get_string('none'),20=>'20%',30=>'30%',40=>'40%',50=>'50%',60=>'60%',70=>'70%',80=>'80%',90=>'90%',100=>'40%');
        $mform->addElement('select', 'mingrade', get_string('mingrade', MOD_TEACHERASSISTANT_LANG), $options);

        return array('mingrade');
    }

    function completion_rule_enabled($data) {
        return ($data['mingrade']>0);
    }
}
