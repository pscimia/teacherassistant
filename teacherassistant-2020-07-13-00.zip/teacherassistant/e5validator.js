function allalphabetic(the_string)  
{  

   var letters = /^[a-zA-Z ]+$/;  
   
   if (the_string.match(letters))  
    {  
	  
     return true;  
	 
    }  
   else  
    {   
 
    return false;  
   }  
}  

function validate_metadato_name(the_string)
{
  
	if ((the_string.length > 0) && (allalphabetic(the_string)) && (the_string.length <= 20))
	{
	
	  
	  return true;
	}
	else
	{
	
	  return false;
	}
}

function validate_metadato_con_acqui(the_string)
{

    if (the_string == "Select a metadato con_acqui")
	{

	   return false;
	}
	else
	{ 
	 	 
	   return true;
	}
}

function validate_metadato_learning_style_1(the_string)
{
    if ((the_string > 0 && the_string <=120) && (!isNaN(the_string)))
	{

	   return true;
	}
	else
	{
	
	   return false;
	}
}

function validate_input(form)
{
    var error_message = "";
	
	
    if (!validate_metadato_name(form.metadato_name.value))
	{ 
	   
        error_message += "Invalid metadato name. ";
		
	}
	

	if (!validate_metadato_con_acqui(form.metadato_con_acqui.value))
	{
	
	    error_message += "Invalid metadato con_acqui. ";
	}

	
	if (!validate_metadato_learning_style_1(form.metadato_learning_style_1.value))
	{
	
	    error_message += "Invalid metadato learning_style_1. ";
	}
	
	if (error_message.length > 0)
	{
	    
	alert(error_message);
	return false;
	
	}
	else
	{
	return true;
	}

}
