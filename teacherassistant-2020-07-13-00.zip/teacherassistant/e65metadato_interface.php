<?php
const USER_ERROR_LOG = "../Logs/User_Errors.log";
const ERROR_LOG = "../Logs/Errors.log";
function clean_input($value)
{

 
 $value = htmlentities($value);
		// Removes any html from the string and turns it into &lt; format
		$value = strip_tags($value);
		
 
	if (get_magic_quotes_gpc())
	{
		$value = stripslashes($value);
		
		// Gets rid of unwanted slashes
	}
		$value = htmlentities($value);
		
		// Removes any html from the string and turns it into &lt; format
		
       $bad_chars = array( "{", "}", "(", ")", ";", ":", "<", ">", "/", "$" );
       $value = str_ireplace($bad_chars,"",$value);			
		return $value;
	
}


class setException extends Exception {
   public function errorMessage() {
   
        list($name_error, $con_acqui_error, $prerequi_error, $learning_style_1_error) = explode(',', $this->getMessage());
		
		$name_error == 'TRUE' ? $eMessage = '' : $eMessage = 'Name update not successful<br/>';
        $con_acqui_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Con_acqui update not successful<br/>';
        $prerequi_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Prerequi update not successful<br/>';
        $learning_style_1_error == 'TRUE' ? $eMessage .= '' : $eMessage .= 'Learning_style_1 update not successful<br/>';
   
     	return $eMessage;
   	}
 }

function get_metadato_app_properties($lab)
{

print "Your metadato's name is " . $lab->get_metadato_name() . "<br/>";
print "Your metadato learning_style_1s " . $lab->get_metadato_learning_style_1() . " lbs. <br />";
print "Your metadato's con_acqui is " . $lab->get_metadato_con_acqui() . "<br />";
print "Your metadato's prerequi is " . $lab->get_metadato_prerequi() . "<br />";

}
//----------------Main Section-------------------------------------
try {
	if ( file_exists("e65metadato_container.php"))
	{
		Require_once("e65metadato_container.php");
	}
	else
	{
		throw new Exception("metadato container file missing or corrupt");
	}

	if (isset($_POST['metadato_app']))
	{

		if ((isset($_POST['metadato_name'])) && (isset($_POST['metadato_con_acqui'])) && (isset($_POST['metadato_prerequi'])) && (isset($_POST['metadato_learning_style_1'])))
		{
  
			$container = new metadato_container(clean_input($_POST['metadato_app']));

			$metadato_name = clean_input(filter_input(INPUT_POST, "metadato_name"));
			$metadato_con_acqui = clean_input($_POST['metadato_con_acqui']);
			$metadato_prerequi = clean_input($_POST['metadato_prerequi']);
			$metadato_learning_style_1 = clean_input($_POST['metadato_learning_style_1']);
			$con_acquixml = $container->get_metadato_application("con_acquis");
	
			$properties_array = array($metadato_name,$metadato_con_acqui,$metadato_prerequi,$metadato_learning_style_1,$con_acquixml);
			$lab = $container->create_object($properties_array);
			
			print "Updates successful<br />";
			get_metadato_app_properties($lab);
		}

		else
		{
    
		print "<p>Missing or invalid parameters. Please go back to the metadato.html page to enter valid information.<br />";

		print "<a href='e65lab.html'>metadato Creation Page</a>";

		}
	}
	else // select box
	{
     
		$container = new metadato_container("selectbox");
     
		$properties_array = array("selectbox");
	 
		$lab = $container->create_object($properties_array);	
        $container->set_app("con_acquis");
        $metadato_app = $container->get_metadato_application("con_acquis");
		$method_array = get_class_methods($lab);
		$last_position = count($method_array) - 1;
		$method_name = $method_array[$last_position]; 
		$result = $lab->$method_name($metadato_app);

	    print $result;
	}
   }
   catch(setException $e)
   {
		echo $e->errorMessage(); // displays to the user
		
		$date = date('m.d.Y h:i:s'); 
		$errormessage = $e->errorMessage();
		$eMessage =  $date . " | User Error | " . $errormessage . "\n";
		error_log($eMessage,3,USER_ERROR_LOG); // writes message to user error log file

   }
   catch(Exception $e)
   {
        
		echo "The system is currently unavailable. Please try again later."; // displays message to the user
		
		$date = date('m.d.Y h:i:s'); 
		$eMessage =  $date . " | System Error | " . $e->getMessage() . " | " . $e->getFile() . " | ". $e->getLine() . "\n";
		error_log($eMessage,3,ERROR_LOG); // writes message to error log file
		
		error_log("Date/Time: $date - Serious System Problems with metadato Application. Check error log for details", 1, "p.scimia@gmail.com", "Subject: metadato Application Error \nFrom: System Log <systemlog@helpme.com>". "\r\n");
        // e-mails personnel to alert them of a system problem

   }
?>
