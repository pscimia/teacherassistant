<?php
class Metadato
{
// ----------------------------------------- Properties -----------------------------------------
private $metadato_learning_style_1 = 0;
private $metadato_con_acqui = "no con_acqui";
private $metadato_prerequi = "no prerequi";
private $metadato_name = "no name";
private $error_message = "??";
private $con_acquixml = "";
// ---------------------------------- Constructor ----------------------------------------------
function __construct($properties_array)
{
if (method_exists('metadato_container', 'create_object')) {
$this->con_acquixml = $properties_array[4];

$name_error = $this->set_metadato_name($properties_array[0]) == TRUE ? 'TRUE,' : 'FALSE,';
$prerequi_error = $this->set_metadato_prerequi($properties_array[2]) == TRUE ? 'TRUE,' : 'FALSE,';
$learning_style_1_error= $this->set_metadato_learning_style_1($properties_array[3]) == TRUE ? 'TRUE' : 'FALSE';
$con_acqui_error = $this->set_metadato_con_acqui($properties_array[1]) == TRUE ? 'TRUE,' : 'FALSE,';

$this->error_message = $name_error . $con_acqui_error . $prerequi_error . $learning_style_1_error;
$this->save_metadato_data();
if(stristr($this->error_message, 'FALSE'))
{
	throw new setException($this->error_message);
}

}
else
{
exit;
}
}
function clean_input() { }
private function save_metadato_data()
{
if ( file_exists("e65metadato_container.php")) {
		require_once("e65metadato_container.php"); // use chapter 5 container w exception handling
	} else {
		throw new Exception("metadato container file missing or corrupt");
	}
	
	$container = new metadato_container("metadatodata"); // sets the tag name to look for in XML file
	$properties_array = array("metadatodata"); // not used but must be passed into create_object
	$metadato_data = $container->create_object($properties_array); // creates metadato_data object
	$method_array = get_class_methods($metadato_data);
	$last_position = count($method_array) - 1;
	$method_name = $method_array[$last_position]; 
	$record_Array = array(array('metadato_name'=>"$this->metadato_name", 'metadato_learning_style_1'=>"$this->metadato_learning_style_1", 'metadato_prerequi'=>"$this->metadato_prerequi", 'metadato_con_acqui'=>"$this->metadato_con_acqui"));
	$metadato_data->$method_name("Insert",$record_Array);
	$metadato_data = NULL;
	
}

function set_metadato_name($value)
{
$error_message = TRUE;
(ctype_alpha($value) && strlen($value) <= 20) ? $this->metadato_name = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_learning_style_1($value)
{
$error_message = TRUE;
(ctype_digit($value) && ($value > 0 && $value <= 120)) ? $this->metadato_learning_style_1 = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_con_acqui($value)
{
$error_message = TRUE;
($this->validator_con_acqui($value) === TRUE) ? $this->metadato_con_acqui = $value : $this->error_message = FALSE;
return $this->error_message;
}
function set_metadato_prerequi($value)
{
$error_message = TRUE;
(ctype_alpha($value) && strlen($value) <= 15) ? $this->metadato_prerequi = $value : $this->error_message = FALSE;
return $this->error_message;
}
// ----------------------------------------- Get Methods ------------------------------------------------------------
function get_metadato_name()
{
return $this->metadato_name;
}
function get_metadato_learning_style_1()
{
return $this->metadato_learning_style_1;
}
function get_metadato_con_acqui()
{
return $this->metadato_con_acqui;
}
function get_metadato_prerequi()
{
return $this->metadato_prerequi;
}
function get_properties()
{
return "$this->metadato_name,$this->metadato_learning_style_1,$this->metadato_con_acqui,$this->metadato_prerequi.";
}
// ----------------------------------General Method---------------------------------------------

private function validator_con_acqui($value)
{

$con_acqui_file = simplexml_load_file($this->con_acquixml);
$xmlText = $con_acqui_file->asXML();

if(stristr($xmlText, $value) === FALSE)
{
return FALSE;
}
else
{
return TRUE;
}
}

}
?>