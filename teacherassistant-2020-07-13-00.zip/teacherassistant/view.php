<?php
// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Stampa un'istanza particolare di insegnante
 *
 * Puoi anche avere una descrizione più lunga del file,
 * se vuoi, e può estendersi su più righe.
 *
 * @package    mod_teacherassistant
 * @copyright  COPYRIGHTNOTICE
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');
global $DB, $CFG, $USERS, $USER, $PAGE, $COURSE, $GLOBALS;

//moodleform è definito in formslib.php
require_once("$CFG->libdir/formslib.php");

require_once("$CFG->dirroot/mod/teacherassistant/lib.php");

require_once($CFG->dirroot.'/course/moodleform_mod.php');
//È necessario aggiungere quanto segue a tutti i file che accedono alle funzioni profilo_:
require_once("$CFG->dirroot/user/profile/lib.php");



$id = optional_param('id', 0, PARAM_INT); // course_module ID, or

//echo '$id optional param';
//var_dump($id);
$n  = optional_param('n', 0, PARAM_INT);  // teacherassistant ID istanza: dovrebbe essere nominato come primo carattere del modulo

if ($id) {
    $cm         = get_coursemodule_from_id('teacherassistant', $id, 0, false, MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $moduleinstance  = $DB->get_record('teacherassistant', array('id' => $cm->instance), '*', MUST_EXIST);
} elseif ($n) {
    $moduleinstance  = $DB->get_record('teacherassistant', array('id' => $n), '*', MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $moduleinstance->course), '*', MUST_EXIST);
    $cm         = get_coursemodule_from_instance('teacherassistant', $moduleinstance->id, $course->id, false, MUST_EXIST);
} else {
    print_error(get_string('missingidandcmid',MOD_TEACHERASSISTANT_LANG));
}

$PAGE->set_url('/mod/teacherassistant/view.php', array('id' => $cm->id));
require_login($course, true, $cm);
$modulecontext = context_module::instance($cm->id);

//Deviare la logica di registrazione a Moodle 2.7
if($CFG->version<2014051200){
    add_to_log($course->id, 'teacherassistant', 'view', "view.php?id={$cm->id}", $moduleinstance->name, $cm->id);
}else{
    // Evento visualizzato modulo trigger..
    $event = \mod_teacherassistant\event\course_module_viewed::create(array(
        'objectid' => $moduleinstance->id,
        'context' => $modulecontext
    ));
    $event->add_record_snapshot('course_modules', $cm);
    $event->add_record_snapshot('course', $course);
    $event->add_record_snapshot('teacherassistant', $moduleinstance);
    $event->trigger();
}

// se siamo arrivati così lontano, possiamo considerare l'attività "vista"
$completion = new completion_info($course);
$completion->set_module_viewed($cm);

//siamo un insegnante o uno studente?
$mode= "view";

// Imposta l'intestazione della pagina
$PAGE->set_title(format_string($moduleinstance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($modulecontext);
$PAGE->set_pagelayout('course');

//Ottieni le impostazioni di amministrazione
$config = get_config(MOD_TEACHERASSISTANT_FRANKY);
$someadminsetting = $config->someadminsetting;

//Ottieni un'impostazione dell'istanza
$someinstancesetting = $moduleinstance->someinstancesetting;


// Prepara il nostro JavaScript pronto per partire
// Possiamo omettere il modulo $ js, ma è bello averlo qui,
// se per esempio dobbiamo includere alcune cose YUI funky
$jsmodule = array(
    'name'     => 'mod_teacherassistant',
    'fullpath' => '/mod/teacherassistant/module.js',
    'requires' => array()
);
//qui impostiamo tutte le informazioni necessarie per passare a JavaScript
$opts =Array();
$opts['someinstancesetting'] = $someinstancesetting;


//questo entra nel M.mod_teacherassistant cosa, dopo che la pagina è stata caricata.
$PAGE->requires->js_init_call('M.mod_teacherassistant.helper.init', array($opts),false,$jsmodule);

//questo carica tutte le librerie JS esterne che dobbiamo chiamare
//$PAGE->requires->js("/mod/teacherassistant/js/somejs.js");
//$PAGE->requires->js(new moodle_url('http://www.somewhere.com/some.js'),true);

//Questo mette tutta la nostra logica di visualizzazione nel file renderer.php in questo plugin
//gli sviluppatori di temi possono sovrascrivere le classi lì, quindi lo rendono personalizzabile per gli altri
//per farlo in questo modo.
$renderer = $PAGE->get_renderer('mod_teacherassistant');

//Da qui visualizziamo effettivamente la pagina.
// questa è roba di rendering di base


//se siamo insegnanti vediamo le schede. Se studente vediamo solo il quiz
if(has_capability('mod/teacherassistant:preview',$modulecontext)){
    echo $renderer->header($moduleinstance, $cm, $mode, null, get_string('view', MOD_TEACHERASSISTANT_LANG));
}else{
    echo $renderer->notabsheader();
}

echo $renderer->show_intro($moduleinstance,$cm);

echo '$cm->id'.'<br>';
var_dump($cm->id);

echo '$course->id'.'<br>';
var_dump($course->id);


?>
    <html lan="en">
    <head>
        <title>Metadato Object</title>
        <script src="e5get_con_acquis.js"></script>
        <script src="e5validator.js"></script>
        <style type="text/css">

            #JS { display:none; }

        </style>

        <script>
            function checkJS() {

                document.getElementById('JS').style.display = "inline";

            }
        </script>

    </head>

<body onload="checkJS();">
<h1>Metadato Object Creater</h1>
<div id="JS">
    <form method="post" action="e65metadato_interface.php" onSubmit="return validate_input(this)">
        <h2>Please complete ALL fields. Please note the required format of information.</h2>
        Enter Your Metadato's Name (max 20 characters, alphabetic) <input type="text" pattern="[a-zA-Z]*"  title="Up to 20 Alphabetic Characters" maxlength="20" name="metadato_name" id="metadato_name" required/><br /><br />
        Select Your Metadato's Learning Styles 1:<br />
        <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="rome_in_the_neorealism">rome_in_the_neorealism<br />
        <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="rossellini">rossellini<br />
        <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="war">war<br />
        <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="roma_citta_aperta">roma_citta_aperta<br />
        <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="paisa" checked >paisa<br /><br />

        Enter Your Metadato's Learning Styles 1 (numeric only) <input type="number" min="-11" max="11" name="metadato_learning_style_1" id="metadato_learning_style_1" required /><br /><br />
        <script>
            AjaxRequest('e65metadato_interface.php');
        </script>
        <input type="hidden" name="metadato_app" id="metadato_app" value="metadato" />
        Select Your Metadato's Con_acqui <div id="AjaxResponse"></div><br />
        <input type="submit" value="Click to save your metadato" />
    </form>
</div>
<noscript>
    <div id="noJS">
        <form method="post" action="e65metadato_interface.php">
            <h2>Please complete ALL fields. Please note the required format of information.</h2>
            Enter Your Metadato's Name (max 20 characters, alphabetic) <input type="text" pattern="[a-zA-Z ]*"  title="Up to 20 Alphabetic Characters" maxlength="20" name="metadato_name" id="metadato_name" required/><br /><br />
            Select Your metadato's Prerequi:<br />
            <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="rome_in_the_neorealism">rome_in_the_neorealism<br />
            <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="rossellini">rossellini<br />
            <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="war">war<br />
            <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="roma_citta_aperta">roma_citta_aperta<br />
            <input type="radio" name="metadato_prerequi" id="metadato_prerequi" value="paisa" checked >paisa<br /><br />
            Enter Your Metadato's learning_style_1 (numeric only) <input type="number" min="1" max="120" name="metadato_learning_style_1" id="metadato_learning_style_1" required /><br /><br />
            Enter Your Metadato's Con_acqui (max 35 characters, alphabetic) <input type="text" pattern="[a-zA-Z ]*" title="Up to 15 Alphabetic Characters" maxlength="35" name="metadato_con_acqui" id="metadato_con_acqui" required /><br />
            <input type="hidden" name="metadato_app" id="metadato_app" value="metadato" />
            <input type="submit" value="Click to create your metadato" />
        </form>
    </div>
</noscript>
    <table border="1">
        <caption> INSERIMENTO DATI</caption>
        <tr>
            <th colspan="10" class="text-center">TOTAL DATA
            </th>
        </tr>
        <tr>
            <th>
                ID
            </th>
            <th>
                NOME
            </th>
            <th>
                COURSE_ID
            </th>
            <th>
                SECTION_ID
            </th>
            <th>
                CON_ACQ
            </th>
            <th>
                CON_PRE
            </th>
            <th>
                LEARNINGSTYLE1
            </th>
            <th>
                LEARNINGSTYLE2
            </th>
            <th>
                LEARNINGSTYLE3
            </th>
            <th>
                LEARNINGSTYLE4
            </th>
        </tr>
        </thead>
        <tbody>
        <?php
        if ($USERS) {

        foreach ($USERS as $user) { ?>
            <tr>
                <td><?= $cm->id ?></td>
                <td><?= $user->id ?></td>
                <td><?= $course->id ?></td>
                <td><?= $user['email'] ?></td>
                <td><?= $user[''] ?></td>
                <td><?= $cm->id  ?></td>
                <td><?= $user['username'] ?></td>
                <td><?= $user[''] ?></td>
                <td> <?= $user['email'] ?></td>
                <td><?= $user['id'] ?></td>
            </tr>
            <?php
        }
        ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="5" class="text-center">
                Footer
            </td>
        </tr>
        </tfoot>

        <?php
        } else {

            echo '<tr><td colspan="5" class="text-center"> <h2>No Records found</h2></td></tr>';
        }
        ?>

    </table>
<?php
// $sql = "SELECT * FROM mdl_role WHERE 1";

//moodleform è definito in formslib.php
//require_once("$CFG->libdir/formslib.php");
// array da scorrere

// array con tutti i prerequisiti
$prerequi = array('rome_in_the_neorealism', 'rossellini', 'war', 'roma_citta_aperta', 'paisa', 'sciuscia', 'thematics', 'neorealism_growth', 'de_sica', 'children', 'movie_children', 'neorealism_origin');


// notare la prima espressione che inizializza sia $i che $n
for ($i = 0, $n = count($prerequi) ; $i < $n ; $i++)
{
    echo $prerequi[$i] , '<br>';
}
 /*
echo '<br>';
class simplehtml_form extends moodleform {

    //Aggiungi elementi al modulo
    public function definition() {
        global $CFG;
        $attributes = '';
        $mform = $this->_form; // Don't forget the underscore!

        $id = $this->_custom['id'];

        $mform->addElement('hidden', 'id', $id);
        $mform->addElement('html', '<fieldset><legend>Mappa didattica</legend>');
        $mform->addElement('html', '<label>mostra la mappa didattica del corso</label></fieldset>');
        $mform->addElement('html', '<fieldset><legend>Prerequisiti</legend>');

        $mform->addElement('html', '<table><tr><td>');


        $mform->addElement('advcheckbox', 'rome_in_the_neorealism', get_string('rome_in_the_neorealism', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('advcheckbox', 'rossellini', get_string('rossellini', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('advcheckbox', 'war', get_string('war', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('advcheckbox', 'roma_citta_aperta', get_string('roma_citta_aperta', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('html', '</td>');
        $mform->addElement('html', '<td>');

        $mform->addElement('advcheckbox', 'paisa', get_string('paisa', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('advcheckbox', 'sciuscia', get_string('sciuscia', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('advcheckbox', 'thematics', get_string('thematics', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('advcheckbox', 'neorealism_growth', get_string('neorealism_growth', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('html', '</td>');
        $mform->addElement('html', '<td>');

        $mform->addElement('advcheckbox', 'de_sica', get_string('de_sica', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('advcheckbox', 'children', get_string('children', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('advcheckbox', 'movie_children', get_string('movie_children', 'forum'), '', array('group' => 1), array(0, 1));

        $mform->addElement('advcheckbox', 'neorealism_origin', get_string('neorealism_origin', 'forum'), '', array('group' => 1), array(0, 1));


        $mform->addElement('html', '</td></tr></table>');

        $mform->addElement('html', '<hr>');

        $mform->addElement('button', 'intro', get_string("Crea un nuovo prerequisito"));

        $mform->addElement('html', '</fieldset>');

        $mform->addElement('html', '<fieldset><legend>Conoscenza acquisita</legend>');

        $mform->addElement('html', '<label>Conoscenza acquisita attuale:</label>');

        $mform->addElement('html', '<hr>');

        $mform->addElement('html', '<label>Seleziona le conoscenze acquisite</label>');

        $select = $mform->addElement('select', 'acquired_knowledge', get_string('conoscenza acquisita'), array('rome_in_the_neorealism', 'rossellini', 'war', 'roma_citta_aperta'), $attributes);

        $mform->addElement('text', 'name', get_string('Aggiungi una nuova voce di conoscenza', 'forum'), $attributes);

        $mform->addElement('html', '</fieldset>');

        $mform->addElement('html', '<fieldset><legend>Stili di apprendimento</legend>');

        $mform->addElement('html', '<label>attivo-riflessivo</label>');
        $mform->addElement('html', '<input type="number" id="active-reflective" name="active-reflective" min="-11" max="11">');

        $mform->addElement('html', '<br>');

        $mform->addElement('html', '<label>percepito-intuitivo</label>');

        $mform->addElement('html', '<input type="number" id="sensing-intuitive" name="sensing-intuitive" min="-11" max="11">');

        $mform->addElement('html', '<br>');

        $mform->addElement('html', '<label>visivo-verbale</label>');

        $mform->addElement('html', '<input type="number" id="visual-verbal" name="visual-verbal" min="-11" max="11">');

        $mform->addElement('html', '<br>');

        $mform->addElement('html', '<label>sequenziale-globale</label>');

        $mform->addElement('html', '<input type="number" id="sequential-global" name="sequential-global" min="-11" max="11">');

        $mform->addElement('html', '</fieldset>');

        $radioarray=array();

        $radioarray[] = $mform->createElement('radio', 'knowledge', '', get_string('conoscenza 1'), 1, $attributes);
        $radioarray[] = $mform->createElement('radio', 'knowledge', '', get_string('conoscenza 2'), 2, $attributes);
        $radioarray[] = $mform->createElement('radio', 'knowledge', '', get_string('conoscenza 3'), 3, $attributes);
        $mform->addGroup($radioarray, 'radioar', '', array(' '), false);


        //$mform->addElement('html', '<div class="qheader">');

        $mform->addElement('html', '<div class="">');
        $mform->addElement('html', '<button onclick="salvaDati()">Salva i dati</button>');
        $mform->addElement('html', '</div>');
        //$this->add_action_buttons();

        //normalmente usi add_action_buttons invece di questo codice
        $buttonarray=array();
        $buttonarray[] = $mform->createElement('submit', 'submitbutton', get_string('savechanges'));
        $buttonarray[] = $mform->createElement('reset', 'resetbutton', get_string('revert'));
        //$buttonarray[] = $mform->createElement('cancel');
        $mform->addGroup($buttonarray, 'buttonar', '', ' ', false);
    }
    //Salva i dati
    function salvaDati($data, $files) {
        $filename = 'salva-dati';
        $handle = fopen($filename, "w+");
        if (false === $handle) {
            throw new Exception(
                sprintf("Errore durante apertura del file %s", $filename)
            );
        }
        if (flock($handle, LOCK_EX)) {
            $num = fwrite($handle, "Scrivere alcune cose!");
            if (false === $num) {
                throw new Exception(
                    sprintf("Errore durante la scrittura di  %s", $filename)
                );
            }
            fflush($handle); // assicurarsi di scaricare il contenuto del file
            flock($handle, LOCK_UN); // sbloccare
        } else {
            printf ("Impossibile ottenere il lucchetto!\n");
        }
        fclose($handle);
        //var_dump($content);
        //return array();
    }

    //La convalida personalizzata deve essere aggiunta qui
    function validation($data, $files) {
        return array();
    }
}

//Crea un'istanza simplehtml_form
//$mform = new mod_teacherassistant_simplehtml_form(null, array('id' => $id));
$mform = new simplehtml_form(null, array('id' => $id));
//$mform = new mod_teacherassistant_simplehtml_form($course->id, array('id' => $id), null, null);

//L'elaborazione e la visualizzazione dei moduli vengono eseguite qui
if ($mform->is_cancelled()) {
    echo "case 1";
    //Gestire l'operazione di annullamento modulo, se sul modulo è presente il pulsante Annulla
} else if ($fromform = $mform->get_data()) {
    //In questo caso si elaborano dati convalidati. $ mform-> get_data () restituisce i dati pubblicati nel modulo.
    echo "case 2";
    $mform->display();
} else {
    // questo ramo viene eseguito se il modulo viene inviato ma i dati non vengono convalidati e il modulo deve essere visualizzato di nuovo
    // o sulla prima visualizzazione del modulo.
    echo "case 3";

    //visualizza il modulo
    $mform->display();
}
 */
//se abbiamo troppi tentativi, segnaliamolo.
if($moduleinstance->maxattempts > 0){
    $attempts =  $DB->get_records(MOD_TEACHERASSISTANT_USERTABLE,array('userid'=>$USER->id, MOD_TEACHERASSISTANT_MODNAME.'id'=>$moduleinstance->id));
    if($attempts && count($attempts)<$moduleinstance->maxattempts){
        echo get_string("exceededattempts",MOD_TEACHERASSISTANT_LANG,$moduleinstance->maxattempts);
    }
}

//Questo è specifico per il nostro renderer
//echo $renderer->show_something($someadminsetting);
//echo $renderer->show_something($someinstancesetting);

// Termina la pagina
echo $renderer->footer();

?>