<?php

class  GetConAcquis {

function __construct($properties_array)
{
if (!(method_exists('metadato_container', 'create_object')))
{
exit;
}
}

     private $result = "??";
public function get_select($metadato_app)
{
     
	 
	 if (($metadato_app != FALSE) && ( file_exists($metadato_app)))
	 {
     $con_acqui_file = simplexml_load_file($metadato_app);

     $xmlText = $con_acqui_file->asXML();
	
     $this->result = "<select name='metadato_con_acqui' id='metadato_con_acqui'>";
	 
     $this->result = $this->result . "<option value='-1' selected>Select a metadato con_acqui</option>";
     
    foreach ($con_acqui_file->children() as $name => $value)
    {
      $this->result = $this->result . "<option value='$value'>$value</option>";
    }
      $this->result = $this->result . "</select>";
	  
	  return $this->result;
    }
	else
	{
	  throw new Exception("con_acqui xml file missing or corrupt");
	 // return FALSE;
    }
  

}
}
?>
