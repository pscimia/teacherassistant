<?php

// Questo file fa parte di Moodle - http://moodle.org/
//
// Moodle è un software gratuito: puoi ridistribuirlo e / o modificarlo
// secondo i termini della GNU General Public License come pubblicato da
// la Free Software Foundation, versione 3 della Licenza, oppure
// (a tua scelta) qualsiasi versione successiva.
//
// Moodle è distribuito nella speranza che possa essere utile,
// ma SENZA ALCUNA GARANZIA; senza nemmeno la garanzia implicita di
// COMMERCIABILITÀ o IDONEITÀ A UNO SCOPO PARTICOLARE. Vedi la
// Licenza GNU General Public per maggiori dettagli.
//
// Dovresti aver ricevuto una copia della GNU General Public License
// insieme a Moodle. In caso contrario, consultare <http://www.gnu.org/licenses/>.

/**
 * Definisce la classe {@link backup_teacherassistant_activity_task}
 *
 * @package     mod_teacherassistant
 * @category    backup
 * @copyright   2020 Scimia Pierluigi <p.scimia@gmail.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/teacherassistant/backup/moodle2/backup_teacherassistant_stepslib.php');

/**
 * Fornisce tutte le impostazioni e i passaggi per eseguire un backup completo dell'attività dell'assistente del teacherassistant
 */
class backup_teacherassistant_activity_task extends backup_activity_task {

    /**
     * Nessuna impostazione specifica per questa attività
     */
    protected function define_my_settings() {
    }

    /**
     * Definisce un passaggio di backup per memorizzare i dati dell'istanza nel file englishcentral.xml
     */
    protected function define_my_steps() {
        $this->add_step(new backup_teacherassistant_activity_structure_step('teacherassistant_structure', 'teacherassistant.xml'));
    }

    /**
     * Codifica gli URL negli script index.php e view.php
     *
     * @param string $content del testo HTML che alla fine contiene URL per gli script dell'istanza dell'attività
     * @return string il contenuto con gli URL codificati
     */
    static public function encode_content_links($content) {
        global $CFG;

        $base = preg_quote($CFG->wwwroot,"/");

        // Link all'elenco dei moduli
        $search = "/(" . $base . "\/mod\/teacherassistant\/index.php\?id\=)([0-9]+)/";
        $content = preg_replace($search, '$@TEACHERASSISTANTINDEX*$2@$', $content);

        //Link a view.php di moduleid
        $search = "/(" . $base . "\/mod\/teacherassistant\/view.php\?id\=)([0-9]+)/";
        $content= preg_replace($search, '$@TEACHERASSISTANTVIEWBYID*$2@$', $content);

        return $content;
    }
}

